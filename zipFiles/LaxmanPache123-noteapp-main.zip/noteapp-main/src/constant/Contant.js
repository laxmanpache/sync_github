export const logo ='https://www.freepnglogos.com/uploads/walmart-logo-7.jpeg'

const TITLE_LIMIT=30;
const DETAILS_LIMIT=50;
export{TITLE_LIMIT,DETAILS_LIMIT}