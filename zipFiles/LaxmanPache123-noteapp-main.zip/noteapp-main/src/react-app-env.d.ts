/// <reference types="react-scripts" />
declare module 'uuid';
