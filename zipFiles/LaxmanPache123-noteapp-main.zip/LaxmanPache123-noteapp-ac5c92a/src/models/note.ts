
export interface NoteObject {
    id:number,
    title:string,
    details:string,
    color:string,
    date:string

}