import React from 'react'

function App() {
  return (
    <div>Testisdsfddsfsdsnffgsss {process.env.REACT_APP_SECREAT_KEY}dsdssdfs</div>
  )
}

export default App
