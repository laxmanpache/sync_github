import React from 'react';

export function CentralisedInventory() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      xmlnsXlink="http://www.w3.org/1999/xlink"
      width="512"
      height="429"
      viewBox="295 428 476 397"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="335"
        height="209"
        x="295"
        y="428"
        fill="#f2f2f2"
        viewBox="0.174 0 334.65 209"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="335"
          height="209"
          viewBox="0.762 0 333.892 208.526"
        >
          <path
            fillRule="evenodd"
            d="M.762 192.074L324.905 0l9.749 16.451L10.51 208.526.762 192.074z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="335"
        height="209"
        x="366"
        y="444"
        fill="#f2f2f2"
        viewBox="0.174 0 334.65 209"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="335"
          height="209"
          viewBox="0.214 0.103 333.892 208.526"
        >
          <path
            fillRule="evenodd"
            d="M.214 192.178L324.357.103l9.748 16.452L9.962 208.629.214 192.178z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="335"
        height="210"
        x="428"
        y="461"
        fill="#f2f2f2"
        viewBox="0 0.391 335 209.218"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="335"
          height="210"
          viewBox="0.614 0.717 333.892 208.526"
        >
          <path
            fillRule="evenodd"
            d="M.614 192.791L324.757.717l9.749 16.45L10.362 209.243.614 192.791z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="204"
        height="204"
        x="405"
        y="450"
        fill="#fff"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="204"
          height="204"
          viewBox="0.409 0.187 202.972 202.972"
        >
          <path
            fillRule="evenodd"
            d="M101.895 203.158C45.773 203.158.409 157.794.409 101.673.409 45.55 45.773.187 101.895.187c56.122 0 101.486 45.364 101.486 101.486 0 56.121-45.364 101.485-101.486 101.485z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="206"
        height="205"
        x="404"
        y="449"
        fill="#3f3d56"
        viewBox="0.5 0 205 205"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="206"
          height="205"
          viewBox="0.655 0.432 204.481 204.481"
        >
          <path
            fillRule="evenodd"
            d="M.655 102.672C.655 46.297 46.519.432 102.895.432s102.24 45.865 102.24 102.24c0 56.376-45.864 102.241-102.24 102.241S.655 159.048.655 102.673zm1.51 0c0 55.544 45.187 100.731 100.73 100.731 55.543 0 100.73-45.188 100.73-100.73 0-55.543-45.187-100.731-100.73-100.731-55.543 0-100.73 45.188-100.73 100.73z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="37"
        height="37"
        x="488"
        y="534"
        fill="#3f3d56"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="37"
          height="37"
          viewBox="0.804 0.023 36.182 36.182"
        >
          <path
            fillRule="evenodd"
            d="M.804 18.114C.804 8.122 8.904.022 18.895.023c9.992 0 18.092 8.1 18.091 18.09 0 9.992-8.1 18.092-18.09 18.091-9.992 0-18.091-8.099-18.091-18.09zM18.895.905c-9.5.01-17.197 7.71-17.208 17.209 0 9.504 7.705 17.208 17.208 17.208 9.504 0 17.209-7.704 17.209-17.208C36.104 8.61 28.399.905 18.895.905z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="70"
        height="70"
        x="472"
        y="517"
        fill="#ccc"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="70"
          height="70"
          viewBox="0.478 0.697 68.834 68.834"
        >
          <path
            fillRule="evenodd"
            d="M.478 35.114C.478 16.106 15.888.697 34.895.697c19.008 0 34.417 15.409 34.417 34.417 0 19.008-15.41 34.417-34.417 34.417C15.887 69.53.478 54.12.478 35.114zM34.895 1.579c-18.52 0-33.534 15.014-33.534 33.535 0 18.52 15.013 33.534 33.534 33.534 18.52 0 33.534-15.014 33.534-33.534C68.41 16.602 53.407 1.6 34.895 1.579z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="135"
        height="135"
        x="439"
        y="485"
        fill="#ccc"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="135"
          height="135"
          viewBox="0.826 0.045 134.138 134.138"
        >
          <path
            fillRule="evenodd"
            d="M.826 67.114C.826 30.073 30.854.044 67.895.044c37.041 0 67.069 30.029 67.069 67.07 0 37.04-30.028 67.069-67.069 67.069C30.872 134.14.868 104.137.826 67.113zM67.895.928C31.342.928 1.709 30.56 1.709 67.114c0 36.553 29.633 66.186 66.186 66.186 36.554 0 66.186-29.633 66.187-66.186C134.04 30.577 104.432.969 67.895.928z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="18"
        height="18"
        x="498"
        y="543"
        fill="#2751a5"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="18"
          height="18"
          viewBox="0.511 0.289 16.767 16.767"
        >
          <path
            fillRule="evenodd"
            d="M8.895 17.056A8.376 8.376 0 01.511 8.673 8.376 8.376 0 018.895.289a8.376 8.376 0 018.383 8.384 8.376 8.376 0 01-8.383 8.383z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="18"
        height="18"
        x="476"
        y="567"
        fill="#2751a5"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="18"
          height="18"
          viewBox="0.89 0.557 16.767 16.767"
        >
          <path
            fillRule="evenodd"
            d="M9.274 17.325A8.376 8.376 0 01.89 8.94 8.376 8.376 0 019.274.557a8.376 8.376 0 018.384 8.384 8.376 8.376 0 01-8.384 8.384z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="18"
        height="17"
        x="561"
        y="564"
        fill="#2751a5"
        viewBox="0.5 0 17 17"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="18"
          height="17"
          viewBox="0.241 0.027 16.767 16.767"
        >
          <path
            fillRule="evenodd"
            d="M8.624 16.794A8.376 8.376 0 01.241 8.411 8.376 8.376 0 018.624.027a8.376 8.376 0 018.384 8.384 8.376 8.376 0 01-8.384 8.383z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="9"
        height="9"
        x="502"
        y="547"
        fill="#2f2e41"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="9"
          height="9"
          viewBox="0.924 0.701 7.942 7.942"
        >
          <path
            fillRule="evenodd"
            d="M4.895 8.644A3.968 3.968 0 01.924 4.673 3.968 3.968 0 014.895.7a3.967 3.967 0 013.971 3.972 3.968 3.968 0 01-3.971 3.97z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="9"
        height="9"
        x="565"
        y="568"
        fill="#2f2e41"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="9"
          height="9"
          viewBox="0.653 0.44 7.942 7.942"
        >
          <path
            fillRule="evenodd"
            d="M4.624 8.382A3.967 3.967 0 01.653 4.411 3.967 3.967 0 014.624.44a3.968 3.968 0 013.971 3.97 3.968 3.968 0 01-3.971 3.971z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="9"
        height="9"
        x="481"
        y="572"
        fill="#2f2e41"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="9"
          height="9"
          viewBox="0.303 0.411 7.942 7.942"
        >
          <path
            fillRule="evenodd"
            d="M4.274 8.353a3.967 3.967 0 01-3.97-3.97A3.967 3.967 0 014.273.41a3.967 3.967 0 013.971 3.971 3.967 3.967 0 01-3.97 3.971z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="9"
        height="9"
        x="317"
        y="503"
        fill="#2751a5"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="9"
          height="9"
          viewBox="0.602 0.135 7.942 7.942"
        >
          <path
            fillRule="evenodd"
            d="M4.573 8.078a3.967 3.967 0 01-3.97-3.971A3.967 3.967 0 014.572.135a3.968 3.968 0 013.972 3.972 3.968 3.968 0 01-3.972 3.97z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="176"
        height="46"
        x="332"
        y="506"
        fill="#2f2e41"
        viewBox="0 0.169 176 45.662"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="176"
          height="46"
          viewBox="0.383 0.445 175.174 45.447"
        >
          <path
            fillRule="evenodd"
            d="M174.674 1.328H.384V.445h175.174v45.448h-.884V1.328z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="24"
        height="24"
        x="310"
        y="495"
        fill="#2f2e41"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="24"
          height="24"
          viewBox="0.101 0.635 22.944 22.945"
        >
          <path
            fillRule="evenodd"
            d="M.101 12.107C.101 5.771 5.237.635 11.573.635c6.336 0 11.472 5.136 11.472 11.472 0 6.336-5.136 11.472-11.472 11.472C5.237 23.58.101 18.443.101 12.107zm11.472-10.59C5.724 1.517.983 6.26.983 12.107c0 5.849 4.741 10.59 10.59 10.59s10.59-4.741 10.59-10.59c-.007-5.846-4.744-10.583-10.59-10.59z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="9"
        height="9"
        x="344"
        y="617"
        fill="#2751a5"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="9"
          height="9"
          viewBox="0.077 0.418 7.942 7.942"
        >
          <path
            fillRule="evenodd"
            d="M4.048 8.36A3.967 3.967 0 01.077 4.39 3.967 3.967 0 014.047.418a3.968 3.968 0 013.972 3.97A3.968 3.968 0 014.048 8.36z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="24"
        height="24"
        x="336"
        y="609"
        fill="#2f2e41"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="24"
          height="24"
          viewBox="0.576 0.916 22.944 22.945"
        >
          <path
            fillRule="evenodd"
            d="M.576 12.389C.576 6.053 5.712.916 12.048.916c6.336 0 11.472 5.137 11.472 11.473 0 6.336-5.136 11.472-11.472 11.472-6.336 0-11.472-5.136-11.472-11.472zm11.472-10.59c-5.849 0-10.59 4.741-10.59 10.59 0 5.848 4.741 10.59 10.59 10.59s10.59-4.742 10.59-10.59c-.007-5.846-4.745-10.583-10.59-10.59z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="9"
        height="9"
        x="688"
        y="521"
        fill="#2751a5"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="9"
          height="9"
          viewBox="0.76 0.668 7.942 7.942"
        >
          <path
            fillRule="evenodd"
            d="M4.73 8.61A3.968 3.968 0 01.76 4.64 3.968 3.968 0 014.73.667 3.967 3.967 0 018.703 4.64a3.967 3.967 0 01-3.972 3.97z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="24"
        height="24"
        x="681"
        y="514"
        fill="#2f2e41"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="24"
          height="24"
          viewBox="0.258 0.167 22.945 22.945"
        >
          <path
            fillRule="evenodd"
            d="M.258 11.64C.258 5.302 5.395.166 11.731.166c6.336 0 11.472 5.136 11.472 11.472 0 6.336-5.136 11.472-11.472 11.472C5.395 23.111.258 17.975.258 11.64zM11.731 1.05C5.885 1.055 1.148 5.792 1.14 11.64c0 5.848 4.741 10.589 10.59 10.589 5.848 0 10.59-4.741 10.59-10.59S17.579 1.05 11.73 1.05z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="113"
        height="48"
        x="569"
        y="525"
        fill="#2f2e41"
        viewBox="0 0.294 113 47.413"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="113"
          height="48"
          viewBox="0.183 0.198 112.524 47.213"
        >
          <path
            fillRule="evenodd"
            d="M.183 1.97L112.693.198l.014.882L1.065 2.838v44.573H.183V1.97z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="127"
        height="46"
        x="359"
        y="576"
        fill="#2f2e41"
        viewBox="0 0.211 127 45.578"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="127"
          height="46"
          viewBox="0.079 0.382 126.636 45.447"
        >
          <path
            fillRule="evenodd"
            d="M.079 44.948h125.754V.382h.882V45.83H.08v-.881z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="49"
        height="4"
        x="297"
        y="527"
        fill="#ccc"
        viewBox="0 0.441 49 3.118"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="49"
          height="4"
          viewBox="0.305 0.846 48.537 3.089"
        >
          <path
            fillRule="evenodd"
            d="M.305.846h48.537v3.088H.305V.846z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="49"
        height="4"
        x="297"
        y="536"
        fill="#ccc"
        viewBox="0 0.441 49 3.118"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="49"
          height="4"
          viewBox="0.305 0.67 48.537 3.089"
        >
          <path
            fillRule="evenodd"
            d="M.305.67h48.537v3.089H.305V.67z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="49"
        height="4"
        x="297"
        y="545"
        fill="#ccc"
        viewBox="0 0.441 49 3.118"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="49"
          height="4"
          viewBox="0.305 0.495 48.537 3.089"
        >
          <path
            fillRule="evenodd"
            d="M.305.495h48.537v3.089H.305V.495z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="50"
        height="4"
        x="323"
        y="642"
        fill="#ccc"
        viewBox="0 0.409 50 3.182"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="50"
          height="4"
          viewBox="0.78 0.127 48.537 3.089"
        >
          <path
            fillRule="evenodd"
            d="M.78.127h48.536v3.089H.78V.127z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="50"
        height="5"
        x="323"
        y="650"
        fill="#ccc"
        viewBox="0 0.909 50 3.182"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="50"
          height="5"
          viewBox="0.78 0.952 48.537 3.089"
        >
          <path
            fillRule="evenodd"
            d="M.78.952h48.536V4.04H.78V.952z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="50"
        height="4"
        x="323"
        y="659"
        fill="#ccc"
        viewBox="0 0.409 50 3.182"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="50"
          height="4"
          viewBox="0.78 0.777 48.537 3.089"
        >
          <path
            fillRule="evenodd"
            d="M.78.777h48.536v3.088H.78V.777z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="49"
        height="4"
        x="668"
        y="546"
        fill="#ccc"
        viewBox="0 0.441 49 3.118"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="49"
          height="4"
          viewBox="0.462 0.819 48.537 3.089"
        >
          <path
            fillRule="evenodd"
            d="M.462.819H49v3.088H.462V.82z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="49"
        height="4"
        x="668"
        y="555"
        fill="#ccc"
        viewBox="0 0.441 49 3.118"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="49"
          height="4"
          viewBox="0.462 0.643 48.537 3.089"
        >
          <path
            fillRule="evenodd"
            d="M.462.643H49v3.089H.462V.643z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="49"
        height="4"
        x="668"
        y="564"
        fill="#ccc"
        viewBox="0 0.441 49 3.118"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="49"
          height="4"
          viewBox="0.462 0.468 48.537 3.089"
        >
          <path
            fillRule="evenodd"
            d="M.462.468H49v3.089H.462V.468z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="21"
        height="30"
        x="720"
        y="783"
        fill="#ffb8b8"
        viewBox="0.341 0 20.318 30"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="21"
          height="30"
          viewBox="0.403 0.353 19.702 29.091"
        >
          <path
            fillRule="evenodd"
            d="M20.105 26.978l-6.902 2.466-12.8-25.45L10.591.354l9.514 26.624z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="24"
        height="17"
        x="721"
        y="807"
        fill="#2f2e41"
        viewBox="0.485 0 23.031 17"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="24"
          height="17"
          viewBox="0.363 0.094 22.894 16.899"
        >
          <path
            fillRule="evenodd"
            d="M1 16.993l-.1-.281a9.211 9.211 0 015.567-11.76L20.06.095l3.196 8.946L1 16.993z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="12"
        height="29"
        x="684"
        y="788"
        fill="#ffb8b8"
        viewBox="0.452 0 11.096 29"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="12"
          height="29"
          viewBox="0.402 0.531 10.819 28.274"
        >
          <path
            fillRule="evenodd"
            d="M11.22 28.805H3.89L.402.53h10.819l-.001 28.274z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="25"
        height="10"
        x="673"
        y="814"
        fill="#2f2e41"
        viewBox="0.059 0 24.882 10"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="25"
          height="10"
          viewBox="0.454 0.411 23.636 9.499"
        >
          <path
            fillRule="evenodd"
            d="M24.09 9.91H.453v-.3a9.2 9.2 0 019.2-9.199H24.09v9.5z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="17"
        height="11"
        x="695"
        y="629"
        fill="#2751a5"
        viewBox="0 0.309 17 10.381"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="17"
          height="11"
          viewBox="0.781 0.873 16.144 9.858"
        >
          <path
            fillRule="evenodd"
            d="M16.925 7.172l-3.188-6.3S1.861 3.849.781 10.733l16.144-3.56z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="61"
        height="102"
        x="679"
        y="707"
        fill="#2f2e41"
        viewBox="0.424 0 60.152 102"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="61"
          height="102"
          viewBox="0.487 0.003 59.942 101.644"
        >
          <path
            fillRule="evenodd"
            d="M46.08 1.199l-8.67 48.378 23.019 40.71-13.752 5.38L23.36 56.206l-2.99-10.763-1.793 56.204-12.403-.377L.487 48.79 9.607.003l36.472 1.196z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="48"
        height="88"
        x="682"
        y="632"
        fill="#3f3d56"
        viewBox="0.146 0 47.708 88"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="48"
          height="88"
          viewBox="0.632 0.412 47.287 87.223"
        >
          <path
            fillRule="evenodd"
            d="M1.672 84.926C1.403 83.728.632 47.155.632 47.155s12.75-41.86 12.867-42.203l.046-.134 9.68-3.63c.136-.062 3.36-1.498 6-.3a5.173 5.173 0 012.751 3.38c1.098.818 9.01 9.681 9.01 21.704l.3 28.37 6.633 30.756-.293.063c-.181.038-8.268 2.474-21.004 2.474-7.076 0-24.95-2.709-24.95-2.709z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="27"
        height="27"
        x="685"
        y="601"
        fill="#ffb8b8"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="27"
          height="27"
          viewBox="0.752 0.722 26.168 26.168"
        >
          <path
            fillRule="evenodd"
            d="M13.836 26.89A13.072 13.072 0 01.752 13.806 13.072 13.072 0 0113.836.722 13.072 13.072 0 0126.92 13.806 13.072 13.072 0 0113.836 26.89z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="27"
        height="33"
        x="691"
        y="672"
        opacity="0.2"
        viewBox="0 0.087 27 32.825"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="27"
          height="33"
          viewBox="0.205 0.447 26.27 31.938"
        >
          <path
            fillRule="evenodd"
            d="M26.476.447L3.586 32.385.206 17.47 26.475.447z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="30"
        height="23"
        x="670"
        y="683"
        fill="#ffb8b8"
        viewBox="0.032 0 29.936 23"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="30"
          height="23"
          viewBox="0.944 0.432 28.176 21.648"
        >
          <path
            fillRule="evenodd"
            d="M6.85 22.074a5.614 5.614 0 005.261-6.815L29.12 4.826 19.728.432 5.017 11.013a5.644 5.644 0 001.833 11.06z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="13"
        height="14"
        x="682"
        y="683"
        fill="#2751a5"
        viewBox="0.072 0 12.856 14"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="13"
          height="14"
          viewBox="0.782 0.685 11.805 12.855"
        >
          <path
            fillRule="evenodd"
            d="M6.607.685L.782 4.766l4.94 8.773 6.864-5.68L6.607.685z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="32"
        height="64"
        x="685"
        y="634"
        fill="#3f3d56"
        viewBox="0.095 0 31.811 64"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="32"
          height="64"
          viewBox="0.558 0.333 31.17 62.711"
        >
          <path
            fillRule="evenodd"
            d="M.558 49.942L14.259 34.06 9.01 12.153a9.585 9.585 0 0117.762-6.778l.119.222 4.837 32.531L7.42 63.043l-6.862-13.1z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="30"
        height="31"
        x="684"
        y="596"
        fill="#2f2e41"
        viewBox="0.257 0 29.485 31"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="30"
          height="31"
          viewBox="0.365 0.39 28.691 30.165"
        >
          <path
            fillRule="evenodd"
            d="M25.98 30.165l-10.859.39c-.662.024-2.459-7.12-2.694-8.602a4.045 4.045 0 00-4.219-3.272c-.813.077-2.863-1.442-4.978-3.24-4.016-3.415-3.807-9.827.604-12.712.12-.079.24-.15.355-.216C6.972.956 10.228.433 13.417.393c2.89-.037 5.864.327 8.41 1.696 4.567 2.453 6.996 7.813 7.21 12.992.213 5.179-1.447 10.243-3.33 15.072l.274.012"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="135"
        height="3"
        x="636"
        y="822"
        fill="#3f3d56"
        viewBox="0 0.895 135 1.211"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="135"
          height="3"
          viewBox="0.905 0.894 133.333 1.196"
        >
          <path
            fillRule="evenodd"
            d="M133.64 2.09H1.502a.598.598 0 110-1.196h132.136a.598.598 0 110 1.196z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
    </svg>
  );
}

export function Attestation() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      xmlnsXlink="http://www.w3.org/1999/xlink"
      width="512"
      height="429"
      viewBox="294 396 478 429"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="123"
        height="172"
        x="646"
        y="652"
        fill="#f2f2f2"
        viewBox="0.548 0 121.904 172"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="123"
          height="172"
          viewBox="0.997 0.543 121.325 171.184"
        >
          <path
            fillRule="evenodd"
            d="M121.477 96.442c-4.343 26.72-23.909 47.41-44.74 65.492-2.908 2.525-5.823 5-8.745 7.427-.02.012-.04.035-.061.047-.14.116-.281.233-.412.348l-1.805 1.495.376.117 1.169.36-1.199-.326c-.12-.034-.244-.062-.363-.097-13.81-3.73-27.903-7.824-39.193-16.564-11.713-9.077-19.78-24.553-15.74-38.81a26.087 26.087 0 012.202-5.376c.38-.713.8-1.403 1.242-2.083a27.985 27.985 0 0148.736 2.711c-.197-15.71-14.547-27.166-28.006-35.275-13.465-8.102-28.71-16.856-32.942-31.994-2.361-8.423-.375-17.098 4.259-24.427.144-.223.288-.446.437-.664A40.842 40.842 0 0131.076 1.71c18.645-4.23 38.186 3.56 53.48 15.04 24.614 18.47 41.857 49.31 36.92 79.691z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="91"
        height="154"
        x="652"
        y="670"
        fill="#fff"
        viewBox="0 0.182 91 153.636"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="91"
          height="154"
          viewBox="0.211 0.7 90.64 153.028"
        >
          <path
            fillRule="evenodd"
            d="M75.93 48.925a69.438 69.438 0 0110.446 17.223 60.291 60.291 0 014.192 17.43c1.133 12.296-1.2 24.726-5.852 36.107a111.16 111.16 0 01-13.978 24.249 520.679 520.679 0 01-8.746 7.427c-.02.012-.04.035-.06.047-.141.116-.282.233-.412.349l-1.805 1.494.375.117 1.17.36c-.402-.11-.798-.215-1.2-.326-.119-.034-.243-.062-.363-.096a61.452 61.452 0 00-25.833-50.19 61.977 61.977 0 00-26.898-10.56c.38-.714.8-1.404 1.242-2.084a64.265 64.265 0 0111.01 2.72 62.965 62.965 0 0131.539 23.857 64.372 64.372 0 0111.171 34.237c.483-.556.964-1.122 1.43-1.681 8.889-10.535 16.493-22.315 21.025-35.4A71.858 71.858 0 0087.8 79.552C85.777 66.86 79.278 55.66 70.687 46.261c-9.201-10.058-20.25-18.608-31.812-25.775A170.91 170.91 0 001.057 2.98a1.229 1.229 0 01-.802-1.492c.053-.27.21-.509.437-.664a.91.91 0 01.789-.06C3.12 1.29 4.749 1.83 6.37 2.402a172.857 172.857 0 0138.267 19.13c11.506 7.645 22.553 16.63 31.293 27.392z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="110"
        height="29"
        x="487"
        y="629"
        fill="#2751a5"
        viewBox="0 0.25 110 28.5"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="110"
          height="29"
          viewBox="0.169 0.483 109.703 28.423"
        >
          <path
            fillRule="evenodd"
            d="M6.171 28.906a5.234 5.234 0 01-5.214-4.892L.18 12.156A5.234 5.234 0 015.06 6.59L97.966.507c6.159-.403 11.478 4.262 11.882 10.421.403 6.16-4.263 11.48-10.422 11.883L6.52 28.894a5.326 5.326 0 01-.35.012z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="89"
        height="32"
        x="505"
        y="628"
        fill="#2f2e41"
        viewBox="0 0.222 89 31.557"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="89"
          height="32"
          viewBox="0.597 0.401 87.528 31.035"
        >
          <path
            fillRule="evenodd"
            d="M6.49 31.435a5.24 5.24 0 01-5.227-5.038L.6 8.685A5.233 5.233 0 015.635 3.26L82.034.404a5.233 5.233 0 015.425 5.035l.662 17.712a5.233 5.233 0 01-5.034 5.425l-76.4 2.855a5.663 5.663 0 01-.197.004z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="24"
        height="110"
        x="583"
        y="713"
        fill="#2f2e41"
        viewBox="0.775 0 22.45 110"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="24"
          height="110"
          viewBox="0.9 0.193 22.351 109.513"
        >
          <path
            fillRule="evenodd"
            d="M18.017 109.706H6.134A5.24 5.24 0 01.9 104.473V5.427A5.24 5.24 0 016.134.193h11.883a5.24 5.24 0 015.234 5.234v99.046a5.24 5.24 0 01-5.234 5.233z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="73"
        height="103"
        x="535"
        y="669"
        fill="#2f2e41"
        viewBox="0 0.11 73 102.779"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="73"
          height="103"
          viewBox="0.588 0.782 71.968 101.326"
        >
          <path
            fillRule="evenodd"
            d="M13.27 101.351l-10.163-6.16a5.24 5.24 0 01-1.763-7.188L52.684 3.3a5.24 5.24 0 017.19-1.763l10.162 6.16a5.24 5.24 0 011.763 7.189L20.458 99.588a5.24 5.24 0 01-7.188 1.763z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="84"
        height="83"
        x="541"
        y="527"
        fill="#2751a5"
        viewBox="0.5 0 83 83"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="84"
          height="83"
          viewBox="0.905 0.701 82.127 82.126"
        >
          <path
            fillRule="evenodd"
            d="M41.968 82.827C19.26 82.827.905 64.472.905 41.764.905 19.056 19.26.7 41.968.7c22.708 0 41.063 18.355 41.063 41.063 0 22.708-18.355 41.063-41.063 41.063z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="11"
        height="28"
        x="555"
        y="556"
        fill="#2f2e41"
        viewBox="0.274 0 10.452 28"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="11"
          height="28"
          viewBox="0.248 0.021 10.379 27.806"
        >
          <path
            fillRule="evenodd"
            d="M5.741 26.785a9.739 9.739 0 01-3.556-2.088A6.548 6.548 0 01.27 19.513a4.404 4.404 0 011.96-3.39c1.467-.943 3.431-.945 5.431-.064L7.586.029 9.196.02l.089 18.845-1.24-.78c-1.44-.904-3.495-1.54-4.946-.608a2.829 2.829 0 00-1.225 2.189 4.948 4.948 0 001.423 3.866c1.778 1.698 4.372 2.23 7.33 2.704l-.255 1.59a26.546 26.546 0 01-4.63-1.042z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="10"
        height="3"
        x="545"
        y="555"
        fill="#2f2e41"
        viewBox="0.163 0 9.674 3"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="10"
          height="3"
          viewBox="0.775 0.219 8.809 2.732"
        >
          <path
            fillRule="evenodd"
            d="M.775 1.816L.986.219l8.599 1.136-.211 1.596L.775 1.816z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="10"
        height="4"
        x="572"
        y="558"
        fill="#2f2e41"
        viewBox="0 0.45 10 3.101"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="10"
          height="4"
          viewBox="0.915 0.803 8.809 2.732"
        >
          <path
            fillRule="evenodd"
            d="M.915 2.4L1.126.802l8.599 1.135-.211 1.597L.915 2.399z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="84"
        height="126"
        x="541"
        y="620"
        fill="#2f2e41"
        viewBox="0.135 0 83.729 126"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="84"
          height="126"
          viewBox="0.169 0.201 82.932 124.8"
        >
          <path
            fillRule="evenodd"
            d="M76.256 125H7.012a6.851 6.851 0 01-6.843-6.843L14.665 6.993A6.835 6.835 0 0121.505.2H46.08C66.515.224 83.077 16.785 83.1 37.222v80.935A6.852 6.852 0 0176.256 125z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="25"
        height="111"
        x="577"
        y="632"
        fill="#2751a5"
        viewBox="0.769 0 23.461 111"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="25"
          height="111"
          viewBox="0.943 0.571 23.157 109.562"
        >
          <path
            fillRule="evenodd"
            d="M22.82 107.075a5.242 5.242 0 01-4.805 3.057L6.13 110.03a5.233 5.233 0 01-5.188-5.279l.808-93.1C1.804 5.476 6.85.517 13.022.57c6.172.054 11.132 5.1 11.078 11.272l-.807 93.101a5.21 5.21 0 01-.473 2.13z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="33"
        height="88"
        x="574"
        y="630"
        fill="#2f2e41"
        viewBox="0.623 0 31.754 88"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="33"
          height="88"
          viewBox="0.779 0.185 31.427 87.093"
        >
          <path
            fillRule="evenodd"
            d="M31.07 84.22a5.242 5.242 0 01-4.805 3.058L5.967 87.1A5.24 5.24 0 01.78 81.823l.663-76.45A5.233 5.233 0 016.721.186l20.297.176a5.233 5.233 0 015.188 5.28l-.663 76.449a5.21 5.21 0 01-.473 2.13z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="52"
        height="66"
        x="535"
        y="747"
        fill="#2f2e41"
        viewBox="0 0.202 52 65.597"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="52"
          height="66"
          viewBox="0.383 0.593 51.263 64.667"
        >
          <path
            fillRule="evenodd"
            d="M.451 11.434a5.199 5.199 0 012.33-3.566l9.987-6.442a5.24 5.24 0 017.235 1.562L50.81 50.75a5.234 5.234 0 01-1.561 7.235l-9.987 6.44a5.24 5.24 0 01-7.235-1.56L1.22 15.103a5.195 5.195 0 01-.769-3.67z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="205"
        height="254"
        x="294"
        y="437"
        fill="#3f3d56"
        viewBox="0.008 0 204.983 254"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="205"
          height="254"
          viewBox="0.294 0.474 204.521 253.427"
        >
          <path
            fillRule="evenodd"
            d="M204.05 6.658a10.108 10.108 0 00-9.244-6.184H10.296C4.773.476.296 4.953.294 10.476v233.422c.003 5.523 4.48 10 10.002 10.002h184.516c5.521-.007 9.995-4.48 10.003-10.002V10.475a9.824 9.824 0 00-.759-3.817h-.006zm-1.463 237.24a7.79 7.79 0 01-7.78 7.781H10.295a7.782 7.782 0 01-7.781-7.778V10.476a7.792 7.792 0 017.781-7.78h184.516a7.82 7.82 0 017.223 4.894 7.724 7.724 0 01.559 2.886l-.007 233.422z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="65"
        height="10"
        x="399"
        y="483"
        fill="#3f3d56"
        viewBox="0 0.517 65 8.966"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="65"
          height="10"
          viewBox="0.522 0.691 64.469 8.893"
        >
          <path
            fillRule="evenodd"
            d="M60.545 9.584H4.968a4.446 4.446 0 010-8.893h55.577a4.446 4.446 0 110 8.893z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="65"
        height="9"
        x="399"
        y="507"
        fill="#3f3d56"
        viewBox="0 0.017 65 8.966"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="65"
          height="9"
          viewBox="0.522 0.034 64.469 8.893"
        >
          <path
            fillRule="evenodd"
            d="M60.545 8.926H4.968a4.446 4.446 0 010-8.892h55.577a4.446 4.446 0 110 8.892z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="52"
        height="59"
        x="329"
        y="471"
        fill="#2751a5"
        viewBox="0.224 0 51.552 59"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="52"
          height="59"
          viewBox="0.834 0.283 50.62 57.934"
        >
          <path
            fillRule="evenodd"
            d="M46.452 58.217H5.836a5.008 5.008 0 01-5.002-5.002V5.285A5.008 5.008 0 015.836.284h40.616a5.008 5.008 0 015.002 5.003v47.929a5.008 5.008 0 01-5.002 5.002z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="135"
        height="10"
        x="329"
        y="554"
        fill="#ccc"
        viewBox="0 0.537 135 8.926"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="135"
          height="10"
          viewBox="0.109 0.83 134.496 8.893"
        >
          <path
            fillRule="evenodd"
            d="M130.16 9.722H4.554a4.446 4.446 0 010-8.892H130.16a4.446 4.446 0 110 8.892z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="135"
        height="10"
        x="329"
        y="578"
        fill="#ccc"
        viewBox="0 0.537 135 8.926"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="135"
          height="10"
          viewBox="0.109 0.172 134.496 8.893"
        >
          <path
            fillRule="evenodd"
            d="M130.16 9.065H4.554a4.446 4.446 0 010-8.893H130.16a4.446 4.446 0 110 8.893z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="135"
        height="10"
        x="329"
        y="601"
        fill="#ccc"
        viewBox="0 0.537 135 8.926"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="135"
          height="10"
          viewBox="0.109 0.514 134.496 8.893"
        >
          <path
            fillRule="evenodd"
            d="M130.16 9.407H4.554a4.446 4.446 0 010-8.893H130.16a4.446 4.446 0 110 8.893z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="135"
        height="10"
        x="329"
        y="624"
        fill="#ccc"
        viewBox="0 0.537 135 8.926"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="135"
          height="10"
          viewBox="0.109 0.857 134.496 8.893"
        >
          <path
            fillRule="evenodd"
            d="M130.16 9.75H4.554a4.446 4.446 0 010-8.893H130.16a4.446 4.446 0 110 8.892z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="135"
        height="10"
        x="329"
        y="648"
        fill="#ccc"
        viewBox="0 0.537 135 8.926"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="135"
          height="10"
          viewBox="0.109 0.199 134.496 8.893"
        >
          <path
            fillRule="evenodd"
            d="M130.16 9.092H4.554a4.446 4.446 0 010-8.893H130.16a4.446 4.446 0 110 8.893z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="87"
        height="87"
        x="456"
        y="396"
        fill="#2751a5"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="87"
          height="87"
          viewBox="0.52 0.496 85.82 85.82"
        >
          <path
            fillRule="evenodd"
            d="M43.43 86.316C19.7 86.316.52 67.136.52 43.406.52 19.676 19.7.496 43.43.496c23.729 0 42.91 19.18 42.91 42.91 0 23.73-19.181 42.91-42.91 42.91z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="38"
        height="33"
        x="480"
        y="423"
        fill="#fff"
        viewBox="0.186 0 37.628 33"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="38"
          height="33"
          viewBox="0.613 0.14 37.212 32.635"
        >
          <path
            fillRule="evenodd"
            d="M15.177 32.774a4.448 4.448 0 01-2.677-.89l-.048-.035-10.084-7.715a4.481 4.481 0 115.453-7.113l6.532 5.01L29.788 1.893a4.48 4.48 0 016.28-.83l.002.001-.096.134.098-.134a4.485 4.485 0 01.829 6.282L18.746 31.022a4.483 4.483 0 01-3.565 1.748l-.004.004z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="294"
        height="3"
        x="478"
        y="822"
        fill="#3f3d56"
        viewBox="0 0.705 294 1.589"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="294"
          height="3"
          viewBox="0.181 0.503 293.525 1.587"
        >
          <path
            fillRule="evenodd"
            d="M292.913 2.09H.975a.793.793 0 010-1.587h291.938a.793.793 0 110 1.587z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
    </svg>
  );
}

export function ModelValidation() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      xmlnsXlink="http://www.w3.org/1999/xlink"
      width="512"
      height="429"
      viewBox="277 396 512 429"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="69"
        height="44"
        x="339"
        y="626"
        fill="#ffb8b8"
        viewBox="0.268 0 68.464 44"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="69"
          height="44"
          viewBox="0.778 0.174 67.668 43.489"
        >
          <path
            fillRule="evenodd"
            d="M49.201 37.708l8.74 5.022a7.013 7.013 0 0010.07-3.65 7.01 7.01 0 00-6.192-9.431l-10.583-.582-31.879-9.65L14.217.174.779 7.723 10.02 29.6l39.182 8.107z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="32"
        height="35"
        x="325"
        y="562"
        fill="#2f2e41"
        viewBox="0.432 0 31.136 35"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="32"
          height="35"
          viewBox="0.881 0.104 30.18 33.925"
        >
          <path
            fillRule="evenodd"
            d="M21.536 1.83c-2.022 2.292-1.657 5.049-.184 7.287 1.472 2.238 3.922 4.1 6.066 6.074 1.378 1.269 2.652 2.615 3.27 4.142a4.493 4.493 0 01-.738 4.75c-1.404 1.662-4.02 2.786-6.571 3.75A129.512 129.512 0 01.88 34.03c6.462-7.55 9.696-16.054 9.223-24.245-.1-1.719-.355-3.454.245-5.176A7.035 7.035 0 0115.169.39c2.568-.737 5.951-.008 6.345 1.675l.022-.235"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="28"
        height="85"
        x="291"
        y="722"
        fill="#ffb8b8"
        viewBox="0.138 0 27.725 85"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="28"
          height="85"
          viewBox="0.176 0.23 27.497 84.302"
        >
          <path
            fillRule="evenodd"
            d="M.176 84.13l9.247.402L27.673.23 11.835.91.175 84.13z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="56"
        height="79"
        x="328"
        y="714"
        fill="#ffb8b8"
        viewBox="0 0.298 56 78.404"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="56"
          height="79"
          viewBox="0.222 0.468 55.419 77.591"
        >
          <path
            fillRule="evenodd"
            d="M55.642 74.04l-7.639 4.02L.223 7.17 15.438.467 55.642 74.04z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="31"
        height="30"
        x="315"
        y="561"
        fill="#ffb8b8"
        viewBox="0.5 0 30 30"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="31"
          height="30"
          viewBox="0.757 0.114 29.252 29.253"
        >
          <path
            fillRule="evenodd"
            d="M15.383 29.366C7.294 29.366.757 22.828.757 14.74.757 6.65 7.294.114 15.383.114c8.088 0 14.626 6.537 14.626 14.626 0 8.088-6.538 14.626-14.626 14.626z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="65"
        height="44"
        x="287"
        y="583"
        fill="#ffb8b8"
        viewBox="0 0.129 65 43.742"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="65"
          height="44"
          viewBox="0.558 0.408 63.922 43.017"
        >
          <path
            fillRule="evenodd"
            d="M35.936.408S30.71 11.263 23.473 10.861c0 0-13.669-5.629-18.091 9.648L.558 32.57 64.48 43.425S60.86 21.313 52.419 20.91c0 0-9.649-.804-8.443-4.422 1.207-3.618 5.629-12.06 5.629-12.06L35.936.407z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="102"
        height="168"
        x="280"
        y="626"
        fill="#2f2e41"
        viewBox="0.389 0 101.221 168"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="102"
          height="168"
          viewBox="0.477 0.023 100.797 167.296"
        >
          <path
            fillRule="evenodd"
            d="M64.243 12.888l-9.648 20.905 7.951 33.79 38.728 72.68s-17.836 16.001-22.282 18.568c-3.857 2.226-35.963-58.12-37.136-70.558-.386-4.105-7.427 79.046-7.427 79.046s-26.54-4.38-33.952-5.836c0 0 5.34-37.82 8.488-73.21 2.427-27.28.22-52.002 13.87-63.727L21.629 1.23 53.79.023l10.452 12.865z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="28"
        height="28"
        x="288"
        y="797"
        fill="#2f2e41"
        viewBox="0 0.302 28 27.396"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="28"
          height="28"
          viewBox="0.83 0.819 26.85 26.27"
        >
          <path
            fillRule="evenodd"
            d="M6.29 24.636l14.76 2.144a4.913 4.913 0 105.316-7.947L20.1 12.085l-4.509-9.73C12.895-.4 11.052.575 10.021 5.1L2.81 2.836.922 15.542a8.389 8.389 0 005.368 9.094z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="29"
        height="26"
        x="371"
        y="783"
        fill="#2f2e41"
        viewBox="0 0.022 29 25.955"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="29"
          height="26"
          viewBox="0.782 0.787 27.497 24.61"
        >
          <path
            fillRule="evenodd"
            d="M7.43 25.341l14.916-.052a4.913 4.913 0 104.088-8.642l-7.19-5.753-5.892-8.96C10.28-.396 8.6.84 8.246 5.468L.782 4.29v12.845a8.388 8.388 0 006.647 8.206z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="50"
        height="48"
        x="299"
        y="552"
        fill="#2f2e41"
        viewBox="0.082 0 49.836 48"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="50"
          height="48"
          viewBox="0.476 0.224 48.685 46.891"
        >
          <path
            fillRule="evenodd"
            d="M23.995 1.256c-2.485-1.085-5.44-.66-7.84.605-2.398 1.264-4.315 3.28-5.992 5.41A45.631 45.631 0 00.517 32.96c-.131 2.559-.008 5.26 1.323 7.447 1.462 2.402 4.139 3.781 6.79 4.72a35.72 35.72 0 0027.136-1.492 96.188 96.188 0 01-12.35-11.998c-.703-.817-1.437-1.866-1.08-2.883a3.159 3.159 0 011.013-1.244l8.611-7.478-.217 3.026a8.778 8.778 0 007.74-5.769c-.415.838.377 1.867 1.293 2.056.916.188 1.844-.19 2.703-.559 2.083-.897 4.346-1.964 5.27-4.036a5.79 5.79 0 00-.121-4.57 11.49 11.49 0 00-2.803-3.737 23.441 23.441 0 00-21.885-5.44l.055.254"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="54"
        height="58"
        x="285"
        y="614"
        fill="#ffb8b8"
        viewBox="0.043 0 53.914 58"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="54"
          height="58"
          viewBox="0.245 0.194 53.666 57.734"
        >
          <path
            fillRule="evenodd"
            d="M35.073 47.615l6.422 7.769a7.012 7.012 0 0010.712.115 7.011 7.011 0 00-2.49-11.005l-9.707-4.257-26.469-20.22L15.48.195.245 2.55l.98 23.73 33.848 21.336z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="83"
        height="41"
        x="277"
        y="608"
        fill="#2f2e41"
        viewBox="0 0.504 83 39.992"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="83"
          height="41"
          viewBox="0.105 0.677 82.817 39.904"
        >
          <path
            fillRule="evenodd"
            d="M82.922 36.114s-6.26-22.926-9.562-22.92c-3.303.005-7.725-.398-7.725-.398S60.41-2.48 33.473 2.344C6.538 7.168 18.196-2.078 10.558 1.54 2.919 5.158.105 30.486.105 30.486s41.409-13.67 50.253-6.03a98.19 98.19 0 0016.483 11.658s-4.02 10.051 16.081 0z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="163"
        height="2"
        x="341"
        y="807"
        fill="#3f3d56"
        viewBox="0 0.467 163 1.065"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="163"
          height="2"
          viewBox="0.138 0.083 162.336 1.061"
        >
          <path
            fillRule="evenodd"
            d="M.138.083h162.337v1.061H.138V.084z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="197"
        height="198"
        x="530"
        y="427"
        fill="#e6e6e6"
        viewBox="0 0.5 197 197"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="197"
          height="198"
          viewBox="0 0.768 196.289 196.289"
        >
          <path
            fillRule="evenodd"
            d="M98.145 197.057C43.87 197.057 0 153.187 0 98.913 0 44.639 43.87.768 98.145.768c54.274 0 98.144 43.87 98.144 98.145 0 54.273-43.87 98.144-98.144 98.144z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="163"
        height="2"
        x="447"
        y="471"
        fill="#3f3d56"
        viewBox="0 0.467 163 1.065"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="163"
          height="2"
          viewBox="0.241 0.27 162.336 1.061"
        >
          <path
            fillRule="evenodd"
            d="M.24.27h162.337v1.061H.24V.27z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="320"
        height="2"
        x="447"
        y="500"
        fill="#3f3d56"
        viewBox="0 0.468 320 1.065"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="320"
          height="2"
          viewBox="0.241 0.448 318.837 1.061"
        >
          <path
            fillRule="evenodd"
            d="M.24.448h318.838v1.061H.24V.448z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="198"
        height="198"
        x="569"
        y="407"
        fill="#3f3d56"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="198"
          height="198"
          viewBox="0.258 0.609 197.35 197.35"
        >
          <path
            fillRule="evenodd"
            d="M98.933 197.959c-54.41 0-98.675-44.266-98.675-98.675C.258 44.874 44.524.609 98.933.609c54.41 0 98.675 44.265 98.675 98.675s-44.266 98.675-98.675 98.675zm0-196.29C45.11 1.67 1.32 45.46 1.32 99.285s43.79 97.614 97.614 97.614c53.825 0 97.614-43.79 97.614-97.614 0-53.825-43.79-97.614-97.614-97.614z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="27"
        height="27"
        x="645"
        y="396"
        fill="#2751a5"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="27"
          height="27"
          viewBox="0.874 0.496 25.91 25.911"
        >
          <path
            fillRule="evenodd"
            d="M13.83 26.407A12.943 12.943 0 01.873 13.45 12.944 12.944 0 0113.829.496a12.943 12.943 0 0112.955 12.955c0 7.165-5.79 12.956-12.955 12.956z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="18"
        height="18"
        x="561"
        y="490"
        fill="#0bb7a7"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="18"
          height="18"
          viewBox="0.245 0.957 16.766 16.766"
        >
          <path
            fillRule="evenodd"
            d="M8.628 17.723A8.375 8.375 0 01.245 9.34 8.376 8.376 0 018.628.957 8.375 8.375 0 0117.01 9.34a8.375 8.375 0 01-8.383 8.383z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="39"
        height="39"
        x="750"
        y="480"
        fill="#2751a5"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="39"
          height="39"
          viewBox="0.605 0.333 38.289 38.289"
        >
          <path
            fillRule="evenodd"
            d="M19.75 38.622C9.163 38.622.605 30.065.605 19.478.605 8.89 9.163.333 19.75.333s19.144 8.558 19.144 19.145-8.557 19.144-19.144 19.144z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="113"
        height="24"
        x="400"
        y="575"
        fill="#3f3d56"
        viewBox="0 0.006 113 23.988"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="113"
          height="24"
          viewBox="0.898 0.017 111.59 23.689"
        >
          <path
            fillRule="evenodd"
            d="M100.644.017h-58.09v1.061h58.09c5.955 0 10.783 4.828 10.783 10.784s-4.828 10.783-10.783 10.783H12.742c-5.955 0-10.783-4.827-10.783-10.783 0-5.956 4.828-10.784 10.783-10.784h3.285V.018h-3.285C6.201.017.898 5.32.898 11.861s5.303 11.845 11.844 11.845h87.902c6.541 0 11.844-5.303 11.844-11.845 0-6.542-5.303-11.845-11.844-11.845z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="113"
        height="25"
        x="400"
        y="611"
        fill="#3f3d56"
        viewBox="0 0.506 113 23.988"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="113"
          height="25"
          viewBox="0.898 0.623 111.59 23.689"
        >
          <path
            fillRule="evenodd"
            d="M100.644.623h-58.09v1.06h58.09c5.955 0 10.783 4.829 10.783 10.784 0 5.956-4.828 10.784-10.783 10.784H12.742c-5.955 0-10.783-4.828-10.783-10.784 0-5.955 4.828-10.783 10.783-10.783h3.285V.623h-3.285C6.201.623.898 5.926.898 12.467c0 6.542 5.303 11.845 11.844 11.845h87.902c6.541 0 11.844-5.303 11.844-11.845 0-6.541-5.303-11.844-11.844-11.844z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="113"
        height="24"
        x="400"
        y="648"
        fill="#3f3d56"
        viewBox="0 0.006 113 23.988"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="113"
          height="24"
          viewBox="0.898 0.228 111.59 23.689"
        >
          <path
            fillRule="evenodd"
            d="M100.644.228h-58.09v1.061h58.09c5.955 0 10.783 4.828 10.783 10.783 0 5.956-4.828 10.784-10.783 10.784H12.742c-5.955 0-10.783-4.828-10.783-10.784 0-5.955 4.828-10.783 10.783-10.783h3.285V.228h-3.285C6.201.228.898 5.531.898 12.072c0 6.542 5.303 11.845 11.844 11.845h87.902c6.541 0 11.844-5.303 11.844-11.845 0-6.541-5.303-11.844-11.844-11.844z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="21"
        height="7"
        x="419"
        y="572"
        fill="#2751a5"
        viewBox="0 0.22 21 6.559"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="21"
          height="7"
          viewBox="0.429 0.214 20.201 6.31"
        >
          <path
            fillRule="evenodd"
            d="M3.584.214a3.154 3.154 0 100 6.31h13.839a3.155 3.155 0 100-6.31H3.584z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="21"
        height="7"
        x="419"
        y="609"
        fill="#0bb7a7"
        viewBox="0 0.22 21 6.559"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="21"
          height="7"
          viewBox="0.429 0.35 20.201 6.31"
        >
          <path
            fillRule="evenodd"
            d="M3.584.35a3.154 3.154 0 100 6.31l13.839-.001a3.155 3.155 0 100-6.309H3.584z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="21"
        height="7"
        x="419"
        y="645"
        fill="#3f3d56"
        viewBox="0 0.22 21 6.559"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="21"
          height="7"
          viewBox="0.429 0.424 20.201 6.31"
        >
          <path
            fillRule="evenodd"
            d="M3.584.425a3.154 3.154 0 100 6.31l13.839-.001a3.155 3.155 0 100-6.31H3.584z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="87"
        height="8"
        x="413"
        y="583"
        fill="#e6e6e6"
        viewBox="0 0.788 87 6.424"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="87"
          height="8"
          viewBox="0.941 0.707 85.453 6.31"
        >
          <path
            fillRule="evenodd"
            d="M4.095.707a3.154 3.154 0 100 6.31h79.092a3.155 3.155 0 100-6.31H4.095z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="87"
        height="7"
        x="413"
        y="620"
        fill="#e6e6e6"
        viewBox="0 0.288 87 6.424"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="87"
          height="7"
          viewBox="0.941 0.312 85.453 6.31"
        >
          <path
            fillRule="evenodd"
            d="M4.095.312a3.154 3.154 0 100 6.31h79.092a3.155 3.155 0 100-6.31H4.095z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="87"
        height="8"
        x="413"
        y="656"
        fill="#e6e6e6"
        viewBox="0 0.788 87 6.424"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="87"
          height="8"
          viewBox="0.941 0.917 85.453 6.31"
        >
          <path
            fillRule="evenodd"
            d="M4.095.918a3.154 3.154 0 100 6.31l79.092-.001a3.155 3.155 0 100-6.31H4.095z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="27"
        height="68"
        x="472"
        y="740"
        fill="#3f3d56"
        viewBox="0.72 0 25.56 68"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          width="27"
          height="68"
          viewBox="0.751 0.393 25.378 67.515"
        >
          <path
            fillRule="evenodd"
            d="M25.452 35.415a54.4 54.4 0 00-4.773-15.324l-.341-.706-2.534 2.81 1.877-4.185-.122-.243a100.153 100.153 0 00-5.5-9.543l-.373-.57-.496.55.347-.775-.174-.261c-2.486-3.729-4.396-6.087-4.415-6.11l-.54-.665-.347.792C7.997 1.33 1.684 15.876.848 30.25l-.013.224 4.248 5.135-4.332-2.72.008.988a42 42 0 00.344 5.051c.19 1.441.415 2.849.673 4.222.41.012.808.136 1.153.359a80.068 80.068 0 01-.775-4.73 40.867 40.867 0 01-.315-3.916l8.381 5.262-8.299-10.032C2.677 17.941 7.367 5.697 8.683 2.466c.707.916 2.04 2.695 3.634 5.072L9.42 14l4.133-4.583a98.873 98.873 0 014.945 8.622l-4.464 9.951 6.035-6.693a53.255 53.255 0 014.335 14.282c1.056 7.979.85 15.644-.58 21.584-1.371 5.69-3.787 9.187-6.628 9.596a4.49 4.49 0 01-1.751-.104 2.6 2.6 0 01-1.57.479h-.156c.882.489 1.87.754 2.878.773.248 0 .497-.018.743-.054 3.341-.48 6.009-4.181 7.512-10.42 1.464-6.075 1.678-13.89.601-22.019z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        width="39"
        height="29"
        x="455"
        y="779"
        fill="#3f3d56"
        viewBox="0 0.084 39 28.832"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="39"
          height="29"
          viewBox="0.751 0.35 38.062 28.138"
        >
          <path
            fillRule="evenodd"
            d="M33.103 28.488c-4.37 0-10.67-2.404-16.919-6.78a27.014 27.014 0 01-2.63-2.114l-.7-.64 2.647-.761-3.524-.13-.148-.155C5.223 10.99 1.113 1.22 1.072 1.122L.752.35l.834.038c.083.004 2.069.097 5.053.52l.186.027V.933l.655.1c2.436.37 4.85.878 7.23 1.52l.254.068.794 1.956-.12-1.754.728.21a35.133 35.133 0 019.723 4.508c9.503 6.655 14.762 14.972 11.982 18.941-.95 1.357-2.7 2.005-4.968 2.006zM14.99 19.444c.58.492 1.185.96 1.804 1.396 8.704 6.095 18.05 8.4 20.408 5.034 2.357-3.366-3.006-11.36-11.711-17.456a34.045 34.045 0 00-8.69-4.146l.47 6.853-3.092-7.616a64.946 64.946 0 00-6.205-1.324l.342 4.973-2.128-5.241a65.284 65.284 0 00-3.786-.412c1.102 2.42 4.744 9.895 10.046 15.514l9.724.356-7.182 2.069z"
            paintOrder="stroke fill markers"
          />
        </svg>
      </svg>
    </svg>
  );
}
