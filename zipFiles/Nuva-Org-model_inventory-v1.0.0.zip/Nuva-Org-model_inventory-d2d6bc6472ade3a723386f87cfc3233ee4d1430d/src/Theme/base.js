const theme = {
  typography: {
    fontFamily: ['Open Sans', 'sans-serif'].join(','),
    fontSize: 12,
    h1: {
      fontSize: '30px',
      fontWeight: 300,
    },
    h2: {
      fontSize: '26px',
      fontWeight: 500,
      lineHeight: '29.96px',
    },
    h3: {
      fontSize: '22px',
      fontWeight: 600,
      lineHeight: '29.96px',
    },
    h4: {
      fontSize: '18px',
      fontWeight: 600,
    },
    h5: {
      fontSize: '18px',
      fontWeight: 400,
    },
    h6: {
      fontSize: '16px',
      fontWeight: 700,
    },
    subtitle1: {
      fontSize: '16px',
      fontWeight: 600,
    },
    subtitle2: {
      fontSize: '16px',
      fontWeight: 400,
      lineHeight: '21.79px',
    },
    body1: {
      fontSize: '14px',
      fontWeight: 600,
    },
    body2: {
      fontSize: '14px',
      fontWeight: 400,
      lineHeight: '19.07px',
    },
    body3: {
      fontSize: '12px',
      fontWeight: 600,
    },
    body4: {
      fontSize: '12px',
      fontWeight: 400,
    },
    button: {
      fontSize: '16px',
      fontWeight: 400,
    },
  },
  zIndex: {
    appBar: 1201,
  },
  transitions: {
    duration: {
      shortest: 150,
      shorter: 200,
      short: 250,
      // most basic recommended timing
      standard: 300,
      // this is to be used in complex animations
      complex: 375,
      // recommended when something is entering screen
      enteringScreen: 225,
      // recommended when something is leaving screen
      leavingScreen: 195,
    },
    easing: {
      // This is the most common easing curve.
      easeInOut: 'cubic-bezier(0.4, 0, 0.2, 1)',
      // Objects enter the screen at full velocity from off-screen and
      // slowly decelerate to a resting point.
      easeOut: 'cubic-bezier(0.0, 0, 0.2, 1)',
      // Objects leave the screen at full velocity. They do not decelerate when off-screen.
      easeIn: 'cubic-bezier(0.4, 0, 1, 1)',
      // The sharp curve is used by objects that may return to the screen at any time.
      sharp: 'cubic-bezier(0.4, 0, 0.6, 1)',
    },
  },
  components: {
    MuiGrid: {
      styleOverrides: {
        root: {
          transition: 'all .4s ease-in-out',
        },
      },
    },
    MuiTypography: {
      defaultProps: {
        variantMapping: {
          h1: 'div',
          h2: 'div',
          h3: 'div',
          h4: 'div',
          h5: 'div',
          h6: 'div',
          subtitle1: 'div',
          subtitle2: 'div',
          body1: 'span',
          body2: 'span',
        },
        color: 'text.primary',
      },
    },
    MuiAutocomplete: {
      styleOverrides: {
        paper: {
          marginTop: '5px',
        },
        option: {
          fontWeight: '400',
          margin: '5px',
          minHeight: '40px !important',
          borderRadius: '4px',
        },
        endAdornment: {
          top: '17px',
          right: '18px !important',
        },
      },
    },
    MuiCard: {
      defaultProps: {
        elevation: 0,
      },
      styleOverrides: {
        root: {
          borderRadius: '8px',
        },
      },
    },
    MuiSelect: {
      defaultProps: {
        variant: 'outlined',
      },
      styleOverrides: {
        select: {
          display: 'block',
          textOverflow: 'ellipsis',
          borderBottom: 'none !important',
          boxShadow: 'none',
          fontSize: 14,
          whiteSpace: 'nowrap',
          borderRadius: '4px',
          '&:focus': {
            borderRadius: '4px',
          },
          '&:before': {
            borderBottom: 'none !important',
          },
          '&:after': {
            borderBottom: 'none !important',
          },
        },
        icon: {
          right: '20px',
          top: 'calc(50% - 0.2em)',
        },
        root: {
          borderRadius: '4px',
        },
      },
    },
    MuiToolbar: {
      styleOverrides: {
        root: {
          minHeight: '58px !important',
        },
      },
    },
    MuiInput: {
      styleOverrides: {
        root: {
          // '&:before': {
          //   borderBottom: 'none !important',
          // },
          // '&:after': {
          //   borderBottom: 'none !important',
          // },
        },
      },
    },
    MuiFilledInput: {
      styleOverrides: {
        root: {
          // '&:hover:not(.Mui-disabled):before': {
          //   borderBottom: 'none !important',
          // },
          // '&:after': {
          //   borderBottom: 'none !important',
          // },
          // '&:before': {
          //   borderBottom: 'none !important',
          // },
        },
        underline: {
          // '& :before': {
          //   borderBottom: 'none !important',
          // },
          // '& :after': {
          //   borderBottom: 'none !important',
          // },
        },
      },
    },

    MuiIconButton: {
      styleOverrides: {
        root: {
          '&.Mui-disabled': {
            pointerEvents: 'auto',
          },
        },
      },
    },
    MuiFab: {
      styleOverrides: {
        root: {
          width: '25px',
          height: '25px',
          minHeight: '15px',
          boxShadow: 'none',
          zIndex: 0,
        },
      },
    },
    MuiTextField: {
      defaultProps: {
        variant: 'outlined',
        autoComplete: 'off',
      },
      styleOverrides: {
        root: {
          borderRadius: '4px',
          '& .MuiInputLabel-root': {
            lineHeight: '19.07px',
          },
          '& .MuiInputLabel-shrink': {
            lineHeight: '15px',
          },
          // '& .MuiFilledInput-root:after': {
          //   borderBottom: 'none !important',
          // },
          '& .MuiFilledInput-root': {
            borderRadius: '4px',
            // '&:hover:not(.Mui-disabled):before': {
            //   borderBottom: 'none !important',
            // },
            // '&:before': {
            //   borderBottom: 'none !important',
            // },
          },
          '& .MuiFilledInput-underline': {
            '& :before': {
              borderBottom: 'none !important',
            },
            '& :after': {
              borderBottom: 'none !important',
            },
          },
          '& .MuiFilledInput-input': {
            lineHeight: '19.07px',
            fontWeight: '500',
            fontStyle: 'normal',
          },
        },
      },
    },
    MuiButton: {
      defaultProps: {
        disableElevation: true,
      },
      styleOverrides: {
        root: {
          fontSize: '16px',
          fontWeight: '400',
          height: '40px',
          boxShadow: 'none !important',
          '&.Mui-disabled': {
            pointerEvents: 'auto',
          },
        },
      },
    },
    MuiFormHelperText: {
      styleOverrides: {
        root: {
          fontSize: 12,
          fontWeight: '400',
          lineHeight: '19.07px',
          marginLeft: '10px',
          marginTop: '2px',
        },
      },
    },
    MuiTabs: {
      styleOverrides: {
        root: {
          minHeight: '42px',
          borderBottom: '1px solid',
        },
        indicator: {
          height: '3px',
        },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: {
          fontSize: '16px',
          fontWeight: 600,
          textTransform: 'capitalize',
          paddingTop: 0,
          paddingBottom: '16px',
          paddingLeft: '12px',
          paddingRight: '12px',
          whiteSpace: 'nowrap',
          display: 'block',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          maxWidth: '180px',
          flexDirection: 'initial',
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        head: {
          fontWeight: 600,
          padding: '2px 2px 2px 2px !important',
          lineHeight: 2,
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          color: 'white !important',
          userSelect: 'none',
          fontSize: '12px !important',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          textTransform: 'uppercase',
          '&:last-child': {
            borderRadius: '0 4px 0 0',
          },
          '&:first-child': {
            borderRadius: '4px 0 0 0',
          },
        },
        root: {
          borderBottom: 'solid 1px',
          minHeight: 25,
          fontWeight: 400,
          fontSize: '16px !important',
        },
        sizeSmall: {
          padding: '7px 7px 7px 7px !important',
          borderRight: 'solid 1px',
          wordBreak: 'break-all',
          '&:last-child': {
            paddingRight: 4,
            borderRight: 'none',
          },
          input: {
            fontFamily: 'Open Sans, sans-serif',
          },
        },
      },
    },
    MuiTableBody: {
      styleOverrides: {
        root: {
          borderLeft: '1px',
          borderRight: '1px',
          borderBottom: '2px',
          borderTop: 0,
          borderStyle: 'solid',
        },
      },
    },
    MuiTable: {
      styleOverrides: {
        root: {
          '& .MuiTableBody-root *:hover::-webkit-scrollbar': {
            width: '10px !important',
          },
        },
      },
    },
    MuiTablePagination: {
      styleOverrides: {
        root: {
          width: '100%',
          display: 'block',
          borderBottom: 0,
          '& p': {
            margin: 0,
          },
        },
        caption: {
          userSelect: 'none',
        },
        select: {
          borderRadius: 2,
          paddingX: 0,
        },
      },
    },
    MuiDialog: {
      defaultProps: {
        maxWidth: 'sm',
        fullWidth: true,
      },
      styleOverrides: {
        paper: {
          borderRadius: '4px',
          padding: 16,
          paddingBottom: 60,
          // padding: "22.05px",
          '& .mui-dialog-close-icon-btn': {},
        },
      },
    },
    // MuiDialogTitle: {
    // 	styleOverrides: {
    // 		root: {
    // 			paddingTop: 0,
    // 			paddingBottom: 0,
    // 			paddingLeft: 15,
    // 			paddingRight: 1,
    // 		},
    // 	},
    // },
    // MuiDialogContent: {
    // 	styleOverrides: {
    // 		root: {
    // 			padding: '20px 35px',
    // 		},
    // 	},
    // },
    // MuiDialogActions: {
    // 	styleOverrides: {
    // 		root: {
    // 			paddingTop: 6,
    // 			paddingBottom: 18,
    // 			paddingLeft: 15,
    // 			paddingRight: 15,
    // 		},
    // 	},
    // },
    // MuiSelect: {
    // 	styleOverrides: {
    // 		select: {
    // 			display: 'block',
    // 			borderBottom: '1px solid #0BB7A7',
    // 			boxShadow: 'none',
    // 			fontSize: 14,
    // 			whiteSpace: 'nowrap',
    // 			textOverflow: 'ellipsis',
    // 		},
    // 	},
    // },
    MuiFormControl: {
      defaultProps: {
        variant: 'outlined',
      },
      styleOverrides: {
        root: {
          minWidth: '100%',
          display: 'flex !important',
        },
      },
    },
    MuiFormLabel: {
      styleOverrides: {
        root: {
          fontSize: 14,
          fontWeight: 400,
        },
      },
    },
    MuiList: {
      styleOverrides: {
        root: {
          // fontSize: 13,
          // boxShadow: 'none',
          // selected: {},
          paddingBottom: '0px',
        },
      },
    },
    MuiListItem: {
      styleOverrides: {
        root: {
          '& .MuiListItemButton-root': {
            '& .list-item-button-hover-actions-right': {
              display: 'none',
              position: 'absolute',
              right: '0',
            },
            '&:hover': {
              '& .list-item-button-hover-actions-right': {
                display: 'block',
              },
            },
          },
        },
      },
    },
    MuiMenuItem: {
      styleOverrides: {
        root: {
          fontSize: 14,
          boxShadow: 'none',
          selected: {},
          padding: '10px',
          '&:hover': {
            fontWeight: '700',
            cursor: 'pointer',
          },
        },
      },
    },
    MuiLinearProgress: {
      styleOverrides: {
        root: {
          borderRadius: '8px',
          height: '8px',
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          border: 0,
          paddingLeft: '13px',
          paddingRight: '13px',
          paddingTop: '6px',
          paddingBottom: '7px',
          minHeight: 32,
        },
        label: {
          fontSize: 14,
          lineHeight: '19.7px',
          fontWeight: 400,
          fontStyle: 'normal',
          maxWidth: '180px',
        },
        colorSecondary: {
          borderWidth: '1px',
          borderStyle: 'solid',
        },
      },
    },
    MuiRadio: {
      styleOverrides: {
        root: {
          '& .MuiSvgIcon-root': {
            fontSize: '20px',
          },
        },
      },
    },
    MuiCheckbox: {
      styleOverrides: {
        root: {
          '& .MuiSvgIcon-root': {
            fontSize: '20px',
          },
        },
      },
    },
    MuiSwitch: {
      styleOverrides: {
        track: {
          height: '14px !important',
          width: '34px !important',
          borderRadius: '7px',
        },
        thumb: {
          height: '20px !important',
          width: '20px !important',
          border: '1px solid',
        },
      },
    },
    MuiSlider: {
      styleOverrides: {
        root: {
          height: '4px',
        },
        mark: {
          height: '4px',
          width: '4px',
          borderRadius: '2px',
        },
        valueLabel: {
          fontSize: '14px',
          lineHeight: '20px',
          fontWeight: 400,
          letterSpacing: '0.25px',
        },
        markLabel: {
          fontSize: '10px',
          lineHeight: '20px',
          fontWeight: '600 !important',
          letterSpacing: '0.25px',
        },
        thumb: {
          height: 20,
          width: 20,
        },
      },
    },
    MuiAccordion: {
      styleOverrides: {
        root: {
          border: 'none',
          boxShadow: 'none',
        },
      },
    },
  },
};
export default theme;
