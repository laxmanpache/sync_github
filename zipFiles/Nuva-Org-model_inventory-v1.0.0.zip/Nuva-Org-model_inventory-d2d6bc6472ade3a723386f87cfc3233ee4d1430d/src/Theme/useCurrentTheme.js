import { useMemo } from 'react';
import { createTheme } from '@mui/material/styles';
import _ from 'lodash';
import darkTheme from './dark';
import lightTheme from './light';
/**
 * Returns theme based on user preferences.
 *
 * @returns {Object} Current theme
 */
const useCurrentTheme = (themeValue) =>
  useMemo(
    () => (themeValue === 'light-theme' ? lightTheme : darkTheme),
    [themeValue]
  );

const ReactQueryBuilderTheme = createTheme(
  _.merge(useCurrentTheme, {
    palette: {
      secondary: {
        main: '#0BB7A7',
        contrastText: '#FFFFFF',
      },
    },
  })
);
export { ReactQueryBuilderTheme };

export default useCurrentTheme;
