import { combineReducers } from 'redux';
import userSilcer from './slices/UserSilcer';

const RootReducer = combineReducers({
  users: userSilcer,
});

export default RootReducer;
