/* eslint-disable no-param-reassign */
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  isAuthenticate: !!localStorage.getItem('access_token'),
  userData: JSON.parse(localStorage.getItem('user_data')),
  profileData: JSON.parse(localStorage.getItem('profile_data')),
};

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    loginSuccess: (state, action) => {
      localStorage.setItem('access_token', action.payload.token);
      localStorage.setItem('refresh_token', action.payload.refresh);
      localStorage.setItem('user_data', JSON.stringify(action.payload.user));
      localStorage.setItem(
        'profile_data',
        JSON.stringify(action.payload.profile)
      );
      try {
        window?.cookieStore?.set('user', JSON.stringify(action.payload.user));
        // eslint-disable-next-line no-empty
      } catch (e) {}
      state.isAuthenticate = true;
      state.userData = action.payload.user;
      state.profileData = action.payload.profile;
      localStorage.setItem(
        'remember_me',
        JSON.stringify(action.payload.remember)
      );
    },
    login(state, action) {
      state.push(action.payload);
    },
    logout(state) {
      state.pop();
    },
  },
});
export const { login, logout, loginSuccess } = userSlice.actions;
export default userSlice.reducer;
