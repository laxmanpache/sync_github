export const RELATION_OPTIONS = [
  { label: 'Related to', value: 'Related to' },
  { label: 'Duplicate to', value: 'Duplicate to' },
  { label: 'Parent to', value: 'Parent to' },
  { label: 'Blocks', value: 'Blocks' },
];

export const ENTITY_TYPES = [
  { label: 'ModelInventory', value: 'ModelInventory' },
  { label: 'ModelAssociation', value: 'ModelAssociation' },
];

export const PRIORITIES = [
  { label: 'High', value: 'High' },
  { label: 'Medium', value: 'Medium' },
  { label: 'Low', value: 'Low' },
];

export const RISK_RATINGS = [
  { label: 'Tier-1', value: 'Tier-1' },
  { label: 'Tier-2', value: 'Tier-2' },
  { label: 'Tier-3', value: 'Tier-3' },
];
