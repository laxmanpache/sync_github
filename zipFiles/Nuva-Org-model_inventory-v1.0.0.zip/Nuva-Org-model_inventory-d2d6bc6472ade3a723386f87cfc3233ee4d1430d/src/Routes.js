import React from 'react';

const ModelInventory = React.lazy(
  () => import('./views/ModelInventory/ModelInventory')
);
const Dashboard = React.lazy(() => import('./views/ModelInventory/Dashboard'));
const CreateModelInventory = React.lazy(
  () => import('./views/ModelInventory/CreateModelInventory')
);
const ImportDataFromExcel = React.lazy(
  () => import('./views/ModelInventory/ImportDataFromExcel')
);
const ModelAssociation = React.lazy(
  () => import('./views/ModelAssociation/ModelAssociation')
);
const EditModelAssociation = React.lazy(
  () => import('./views/ModelAssociation/EditModelAssociation')
);
const ModelValidation = React.lazy(
  () => import('./views/ModelAssociation/ModelValidation')
);
const Configuration = React.lazy(
  () => import('./views/Configuration/Configuration')
);
const NewTemplate = React.lazy(
  () => import('./views/Configuration/CreateEditTemplate')
);
const TemplateList = React.lazy(
  () => import('./views/Configuration/TemplateList')
);
const EditModelDetails = React.lazy(
  () => import('./views/ModelInventory/EditModelDetails')
);
const WorkFlowList = React.lazy(
  () => import('./views/Configuration/Workflow/WorkFlowList')
);
const EditWorkFlow = React.lazy(
  () => import('./views/Configuration/Workflow/EditWorkFlow')
);
const Rules = React.lazy(() => import('./views/RulesAndReports/Rules'));

const Reports = React.lazy(() => import('./views/RulesAndReports/Reports'));
const Routes = [
  {
    name: 'Model Inventory',
    path: 'model-inventory',
    key: 'modelInventory',
    element: <ModelInventory />,
  },
  {
    name: 'Create Model Inventory',
    key: 'createModelInventory',
    path: 'model-inventory/create-model-Inventory',
    element: <CreateModelInventory />,
  },
  {
    name: 'Edit Model ',
    key: 'editModel',
    path: 'model-inventory/:modelId',
    element: <EditModelDetails />,
  },
  {
    name: 'Dashboard',
    key: 'dashboard',
    path: 'dashboard',
    element: <Dashboard />,
  },
  {
    name: 'Import From Excel',
    key: 'importFromExcel',
    path: 'model-inventory/import-from-excel',
    element: <ImportDataFromExcel />,
  },
  {
    path: 'model-association',
    element: <ModelAssociation />,
  },
  {
    path: 'model-association/:assId',
    element: <EditModelAssociation />,
  },
  {
    path: 'model-validation',
    element: <ModelValidation />,
  },
  {
    path: 'configuration',
    element: <Configuration />,
  },
  {
    path: 'configuration/create-template',
    element: <NewTemplate />,
  },
  {
    path: 'configuration/workflow',
    element: <WorkFlowList />,
  },
  {
    path: 'configuration/edit-workflow',
    element: <EditWorkFlow />,
  },
  {
    path: 'configuration/template-list',
    element: <TemplateList />,
  },
  {
    path: 'rules',
    element: <Rules />,
  },
  {
    path: 'report',
    element: <Reports />,
  },
  // {
  //   path: '/workflows/model-change-request',
  //   element: <ModelChangeRequest />,
  // },
  // {
  //   path: '/workflows/model-validation',
  //   element: <ModelValidation />,
  // },
  // {
  //   path: '/reporting',
  //   element: <Reporting />,
  // },
  // {
  //   path: '/document-inventory',
  //   element: <DocumnetInventory />,
  // },
  // {
  //   path: '/contact-us',
  //   element: <ContactUs />,
  // },
];
export { Routes };
