/* eslint-disable react/prop-types */
import React from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Stack,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { VaultDynamicFrom } from '../Common/VaultDynamicFrom';
import SwalToast from '../Common/SwalTost';

const EditModelAttributesDetails = ({
  open,
  handleClose,
  fromDetails,
  attributeDetails,
  createModelSecondStep,
  entityId,
}) => {
  const onSubmitSecondStep = (values) => {
    const params = {
      entity_id: entityId,
      entity_type: 'ModelAssociation',
    };
    createModelSecondStep({ attributeValue: values }, params).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: 'Step second created successfully.',
        });
      }
    });
    handleClose();
  };
  return (
    <Box>
      <Dialog maxWidth="lg" open={open} onClose={handleClose}>
        <Grid container overflow="auto">
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Grid item xs={12}>
            <Box
              display="flex"
              justifyContent="space-around"
              alignItems="center"
              mb={2}
            >
              <Typography variant="h3">Edit Model Details</Typography>
            </Box>
          </Grid>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="100%">
              <Grid item xs={12}>
                <VaultDynamicFrom
                  fromSchema={fromDetails}
                  attributeDetails={attributeDetails}
                  onFormSubmit={onSubmitSecondStep}
                />
              </Grid>
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </Box>
  );
};

export default EditModelAttributesDetails;
