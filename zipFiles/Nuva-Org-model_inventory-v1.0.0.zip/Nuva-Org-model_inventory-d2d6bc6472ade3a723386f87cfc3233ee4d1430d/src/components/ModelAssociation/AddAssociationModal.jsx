import React, { useState } from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Stack,
  Button,
  TextField,
} from '@mui/material';
import * as Yup from 'yup';
import CloseIcon from '@mui/icons-material/Close';
import { useFormik } from 'formik';
import PropTypes from 'prop-types';
import { DropDown, DropdownItem } from '../Common/DropDown';
import SwalToast from '../Common/SwalTost';
import { RELATION_OPTIONS } from '../../const/CommonConst';
import DialogTransition from '../Common/Transition/DialogTransition';

const AddAssociationModal = ({
  open,
  handleClose,
  getAllModelEntity,
  createModelThirdStep,
  entityId,
  getAllAssociation,
}) => {
  const [modelAssociation, setModelAssociation] = useState([]);
  const formValidationSchema = Yup.object({
    association_name: Yup.string().required('Required'),
    association_type: Yup.string().required('Required'),
    association_id: Yup.number().required('Required'),
    relation: Yup.string().required('Required'),
  });
  const formikForm = useFormik({
    initialValues: {
      association_name: '',
      entity_type: 'ModelAssociation',
      association_type: '',
      association_id: '',
      relation: '',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      createModelThirdStep({
        entity_id: entityId,
        ...values,
      }).then((res) => {
        if (res) {
          SwalToast({
            icon: 'success',
            title: res?.data?.msg,
          });
          getAllAssociation();
          formikForm?.handleReset();
        }
      });
      formikForm.handleReset();
      handleClose();
    },
  });
  return (
    <Box>
      <Dialog
        maxWidth="xs"
        open={open}
        onClose={handleClose}
        TransitionComponent={DialogTransition}
      >
        <Grid container>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Grid item xs={12}>
            <Box
              display="flex"
              justifyContent="space-around"
              alignItems="center"
              mb={2}
            >
              <Typography variant="h3">Link Association</Typography>
            </Box>
          </Grid>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="300px">
              <DropDown
                label="Relation Option"
                value={formikForm.values.relation}
                name="relation_option"
                onChange={(event) => {
                  formikForm.setFieldValue('relation', event.target.value);
                }}
                helperText={
                  formikForm?.errors?.relation && formikForm?.touched?.relation
                    ? formikForm.errors.relation
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.relation) &&
                  formikForm?.touched?.relation
                }
              >
                {RELATION_OPTIONS.map(({ label, value }) => (
                  <DropdownItem key={label} value={value}>
                    {label}
                  </DropdownItem>
                ))}
              </DropDown>
              <TextField
                name="association_name"
                value={formikForm?.values?.association_name}
                {...formikForm.getFieldProps('association_name')}
                placeholder="Enter association name."
                label="Association name"
                helperText={
                  formikForm?.errors?.association_name &&
                  formikForm?.touched?.association_name
                    ? formikForm.errors.association_name
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.association_name) &&
                  formikForm?.touched?.association_name
                }
              />
              <DropDown
                label="Association type"
                value={formikForm.values.association_type}
                name="association_type"
                onChange={(event) => {
                  getAllModelEntity({ entityType: event?.target.value }).then(
                    (res) => {
                      if (res) {
                        setModelAssociation(res?.data?.modelEntity);
                      }
                    }
                  );
                  formikForm.setFieldValue('association_id', '');
                  formikForm.setFieldValue(
                    'association_type',
                    event.target.value
                  );
                }}
                helperText={
                  formikForm?.errors?.association_type &&
                  formikForm?.touched?.association_type
                    ? formikForm.errors.association_type
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.association_type) &&
                  formikForm?.touched?.association_type
                }
              >
                <DropdownItem key={1} value="ModelAssociation">
                  ModelAssociation
                </DropdownItem>
              </DropDown>
              <DropDown
                label="Select association"
                value={formikForm.values.association_id}
                onChange={(event) => {
                  formikForm.setFieldValue(
                    'association_id',
                    event.target.value
                  );
                }}
                helperText={
                  formikForm?.errors?.association_id &&
                  formikForm?.touched?.association_id
                    ? formikForm.errors.association_id
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.association_id) &&
                  formikForm?.touched?.association_id
                }
              >
                {modelAssociation?.length > 0 ? (
                  modelAssociation?.map((entity) => {
                    return (
                      <DropdownItem
                        key={3}
                        value={
                          formikForm.values.association_type ===
                          'ModelAssociation'
                            ? entity?.association_id
                            : entity?.model_id
                        }
                      >
                        {formikForm.values.association_type ===
                        'ModelAssociation'
                          ? entity?.association_name
                          : entity?.model_name}
                      </DropdownItem>
                    );
                  })
                ) : (
                  <DropdownItem key={3} disabled>
                    No association available.
                  </DropdownItem>
                )}
              </DropDown>

              <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
                <Button
                  onClick={() => {
                    formikForm.handleReset();
                  }}
                >
                  RESET
                </Button>
                <Button onClick={formikForm.handleSubmit} variant="contained">
                  SUBMIT
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </Box>
  );
};
AddAssociationModal.propTypes = {
  open: PropTypes.bool.isRequired,
  entityId: PropTypes.number.isRequired,
  handleClose: PropTypes.func.isRequired,
  getAllModelEntity: PropTypes.func.isRequired,
  createModelThirdStep: PropTypes.func.isRequired,
  getAllAssociation: PropTypes.func.isRequired,
};

export default AddAssociationModal;
