/* eslint-disable no-nested-ternary */
/* eslint-disable no-use-before-define */
/* eslint-disable react/prop-types */
import React, { useEffect, useState } from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Stack,
  TextField,
  Button,
} from '@mui/material';
import * as Yup from 'yup';
import CloseIcon from '@mui/icons-material/Close';
import { useFormik } from 'formik';
import { useSelector } from 'react-redux';
import { DropDown, DropdownItem } from '../Common/DropDown';
import SwalToast from '../Common/SwalTost';
import { VaultDynamicFrom } from '../Common/VaultDynamicFrom';
import DocumentUploadForm from '../Common/Forms/DocumentUploadForm';
import { RELATION_OPTIONS, PRIORITIES } from '../../const/CommonConst';

const CreateAssociationModal = ({
  open,
  setOpen,
  entityList,
  typeOfEntity,
  createModelFirstStep,
  getCustomEntityTemplate,
  createModelSecondStep,
  getAllModelEntity,
  createModelThirdStep,
  createModelForthStep,
  allUserList,
  attachDocument,
}) => {
  const [stepFirst, setStepFirst] = useState('block');
  const [stepSecond, setStepSecond] = useState('none');
  const [stepThird, setStepThird] = useState('none');
  const [stepForth, setStepForth] = useState('none');
  const [stepFifth, setStepFifth] = useState('none');
  const [fromDetails, setFormDetails] = useState([]);
  const [entityDetails, setEntityDetails] = useState({});
  const [modelAssociation, setModelAssociation] = useState([]);
  const { profileData } = useSelector((state) => state.users);

  const handleClose = () => {
    setOpen(!open);
    setStepSecond('none');
    setStepThird('none');
    setStepFirst('block');
    setStepForth('none');
    setStepFifth('none');
  };

  const formValidationSchema = Yup.object({
    model_name: Yup.string().required('Required'),
    entityName: Yup.string().required('Required'),
    entityType: Yup.string(),
    priority: Yup.string().required('Required'),
  });

  const formikForm = useFormik({
    initialValues: {
      model_name: '',
      entityName: '',
      entityType: typeOfEntity || '',
      priority: '',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      createModelFirstStep(values).then((res) => {
        if (res) {
          getAllModelEntity({ entityType: 'ModelAssociation' });
          setEntityDetails(res?.data?.ModelEntity);
          getCustomEntityTemplate({
            entityName: res?.data?.ModelEntity?.ModelEntityType,
          }).then((resp) => {
            if (resp) {
              setFormDetails(
                resp?.data?.Entity?.[res?.data?.ModelEntity?.ModelEntityType]
                  ?.sections
              );
              setTimeout(() => {
                setStepFirst('none');
                setStepSecond('block');
              }, 800);
            }
          });

          SwalToast({
            icon: 'success',
            title: 'Step first created successfully.',
          });
        }
      });

      formikForm.handleReset();
    },
  });

  const onSubmitSecondStep = (values) => {
    const params = {
      entity_id: entityDetails?.ModelEntityId,
      entity_type: 'ModelAssociation',
    };
    createModelSecondStep({ attributeValue: values }, params).then((res) => {
      if (res) {
        setStepSecond('none');
        setStepThird('block');
        SwalToast({
          icon: 'success',
          title: 'Step second created successfully.',
        });
      }
    });
  };

  const associationFromValidationSchema = Yup.object({
    association_name: Yup.string().required('Required'),
    association_type: Yup.string().required('Required'),
    association_id: Yup.number().required('Required'),
    relation: Yup.string().required('Required'),
  });

  const associationFormikFrom = useFormik({
    initialValues: {
      association_name: '',
      association_type: '',
      association_id: '',
      entity_type: 'ModelAssociation',
      relation: '',
    },
    validationSchema: associationFromValidationSchema,
    onSubmit: (values) => {
      createModelThirdStep({
        entity_id: entityDetails?.ModelEntityId,
        ...values,
      }).then((res) => {
        if (res) {
          setStepForth('block');
          setStepThird('none');
          SwalToast({
            icon: 'success',
            title: res?.data?.msg,
          });
          associationFormikFrom?.handleReset();
        }
      });
    },
  });

  const createTeamValidationSchema = Yup.object({
    Approver: Yup.string().required('Required'),
    Reviewer: Yup.string().required('Required'),
  });

  const teamFormikFrom = useFormik({
    initialValues: {
      Approver: '',
      Reviewer: '',
    },
    validationSchema: createTeamValidationSchema,
    onSubmit: (values) => {
      createModelForthStep({
        entity_id: entityDetails?.ModelEntityId,
        entity_type: 'ModelAssociation',
        team: values,
      }).then((res) => {
        if (res) {
          setStepForth('none');
          setStepFifth('block');
          SwalToast({
            icon: 'success',
            title: 'Team created successfully.',
          });
          teamFormikFrom?.handleReset();
        }
      });
    },
  });

  useEffect(() => {
    formikForm?.setFieldValue('Primary Owner', profileData?.first_name);
  }, [profileData]);

  return (
    <div>
      <Dialog
        maxWidth={
          stepSecond === 'block' ? 'xl' : stepFifth === 'block' ? 'md' : 'xs'
        }
        open={open}
        onClose={() => {
          formikForm.handleReset();
          associationFormikFrom.handleReset();
          teamFormikFrom.handleReset();
          handleClose();
        }}
      >
        <Grid container>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  formikForm.handleReset();
                  associationFormikFrom.handleReset();
                  teamFormikFrom.handleReset();
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
        </Grid>
        <Grid container>
          <Grid item xs={12}>
            <Box
              display="flex"
              justifyContent="space-around"
              alignItems="center"
              mb={2}
            >
              <Typography variant="h3">
                {stepFirst === 'block'
                  ? `Create Association`
                  : stepSecond === 'block'
                  ? 'Model Related Details'
                  : stepThird === 'block'
                  ? 'Add Association'
                  : stepForth === 'block'
                  ? 'Create Team'
                  : 'Upload Document'}
              </Typography>
            </Box>
          </Grid>
        </Grid>
        <Grid container display={stepFirst}>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="space-around"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="300px">
              <TextField
                name="model_name"
                value={formikForm?.values?.model_name}
                {...formikForm.getFieldProps('model_name')}
                placeholder="Enter association name."
                label="Association name"
                helperText={
                  formikForm?.errors?.model_name &&
                  formikForm?.touched?.model_name
                    ? formikForm?.errors?.model_name
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.model_name) &&
                  formikForm?.touched?.model_name
                }
              />
              <DropDown
                label="Select template"
                value={formikForm.values.entityName}
                onChange={(event) => {
                  formikForm.setFieldValue('entityName', event.target.value);
                }}
                helperText={
                  formikForm?.errors?.entityName &&
                  formikForm?.touched?.entityName
                    ? formikForm.errors?.entityName
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.entityName) &&
                  formikForm?.touched?.entityName
                }
              >
                {entityList?.map((entity) => {
                  return (
                    <DropdownItem key={3} value={entity?.entity_name}>
                      {entity?.entity_name}
                    </DropdownItem>
                  );
                })}
              </DropDown>
              <DropDown
                label="Select priority"
                value={formikForm.values.priority}
                onChange={(event) => {
                  formikForm.setFieldValue('priority', event.target.value);
                }}
                helperText={
                  formikForm?.errors?.priority && formikForm?.touched?.priority
                    ? formikForm.errors?.priority
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.priority) &&
                  formikForm?.touched?.priority
                }
              >
                {PRIORITIES.map(({ label, value }) => (
                  <DropdownItem key={value} value={value}>
                    {label}
                  </DropdownItem>
                ))}
              </DropDown>
              <TextField
                name="entity_type"
                disabled
                defaultValue={typeOfEntity}
                value={formikForm?.values?.entity_type}
                {...formikForm.getFieldProps('entity_type')}
                placeholder="Enter entity type."
                label="Entity type"
              />
              <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
                <Button
                  onClick={() => {
                    formikForm.handleReset();
                  }}
                >
                  RESET
                </Button>
                <Button onClick={formikForm.handleSubmit} variant="contained">
                  NEXT
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
        <Grid container display={stepSecond}>
          <Grid item xs={12}>
            {stepSecond === 'block' ? (
              <VaultDynamicFrom
                fromSchema={fromDetails}
                stepFirst={stepFirst}
                onFormSubmit={onSubmitSecondStep}
              />
            ) : null}
          </Grid>
        </Grid>
        <Grid container display={stepThird}>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="space-around"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="300px">
              <Stack direction="column" spacing={3} mt={3} width="300px">
                <DropDown
                  label="Relation Option"
                  value={associationFormikFrom.values.relation}
                  name="relation_option"
                  onChange={(event) => {
                    associationFormikFrom.setFieldValue(
                      'relation',
                      event.target.value
                    );
                  }}
                  helperText={
                    associationFormikFrom?.errors?.relation &&
                    associationFormikFrom?.touched?.relation
                      ? associationFormikFrom.errors.relation
                      : null
                  }
                  error={
                    Boolean(associationFormikFrom?.errors?.relation) &&
                    associationFormikFrom?.touched?.relation
                  }
                >
                  {RELATION_OPTIONS.map(({ label, value }) => (
                    <DropdownItem key={label} value={value}>
                      {label}
                    </DropdownItem>
                  ))}
                </DropDown>
                <TextField
                  name="association_name"
                  value={associationFormikFrom?.values?.association_name}
                  {...associationFormikFrom.getFieldProps('association_name')}
                  placeholder="Enter association name."
                  label="Association name"
                  helperText={
                    associationFormikFrom?.errors?.association_name &&
                    associationFormikFrom?.touched?.association_name
                      ? associationFormikFrom.errors?.association_name
                      : null
                  }
                  error={
                    Boolean(associationFormikFrom?.errors?.association_name) &&
                    associationFormikFrom?.touched?.association_name
                  }
                />
                <DropDown
                  label="Association type"
                  value={associationFormikFrom.values.association_type}
                  name="association_type"
                  onChange={(event) => {
                    getAllModelEntity({ entityType: event?.target.value }).then(
                      (res) => {
                        if (res) {
                          setModelAssociation(res?.data?.modelEntity);
                        }
                      }
                    );
                    associationFormikFrom.setFieldValue('association_id', '');
                    associationFormikFrom.setFieldValue(
                      'association_type',
                      event.target.value
                    );
                  }}
                  helperText={
                    associationFormikFrom?.errors?.association_type &&
                    associationFormikFrom?.touched?.association_type
                      ? associationFormikFrom.errors?.association_type
                      : null
                  }
                  error={
                    Boolean(associationFormikFrom?.errors?.association_type) &&
                    associationFormikFrom?.touched?.association_type
                  }
                >
                  <DropdownItem key={1} value="ModelAssociation">
                    ModelAssociation
                  </DropdownItem>
                </DropDown>
                <DropDown
                  label="Select association template"
                  value={associationFormikFrom.values.association_id}
                  onChange={(event) => {
                    associationFormikFrom.setFieldValue(
                      'association_id',
                      event.target.value
                    );
                  }}
                  helperText={
                    associationFormikFrom?.errors?.association_id &&
                    associationFormikFrom?.touched?.association_id
                      ? associationFormikFrom.errors?.association_id
                      : null
                  }
                  error={
                    Boolean(associationFormikFrom?.errors?.association_id) &&
                    associationFormikFrom?.touched?.association_id
                  }
                >
                  {modelAssociation?.length > 0 ? (
                    modelAssociation?.map((entity, i) => {
                      return (
                        <DropdownItem
                          // eslint-disable-next-line react/no-array-index-key
                          key={i}
                          value={
                            associationFormikFrom.values.association_type ===
                            'ModelAssociation'
                              ? entity?.association_id
                              : entity?.model_id
                          }
                        >
                          {associationFormikFrom.values.association_type ===
                          'ModelAssociation'
                            ? entity?.association_name
                            : entity?.model_name}
                        </DropdownItem>
                      );
                    })
                  ) : (
                    <DropdownItem key={3} disabled>
                      No template available.
                    </DropdownItem>
                  )}
                </DropDown>
                <Stack
                  direction="row"
                  spacing={3}
                  justifyContent="center"
                  mt={3}
                >
                  <Button
                    onClick={() => {
                      associationFormikFrom.handleReset();
                    }}
                  >
                    RESET
                  </Button>
                  <Button
                    onClick={associationFormikFrom.handleSubmit}
                    variant="contained"
                  >
                    NEXT
                  </Button>
                  <Button
                    onClick={() => {
                      setStepForth('block');
                      setStepThird('none');
                    }}
                  >
                    SKIP
                  </Button>
                </Stack>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
        <Grid container display={stepForth}>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="space-around"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="300px">
              <Stack direction="column" spacing={3} mt={3} width="300px">
                <DropDown
                  label="Select approver"
                  value={teamFormikFrom.values.Approver}
                  onChange={(event) => {
                    teamFormikFrom.setFieldValue(
                      'Approver',
                      event.target.value
                    );
                  }}
                  helperText={
                    teamFormikFrom?.errors?.Approver &&
                    teamFormikFrom?.touched?.Approver
                      ? teamFormikFrom.errors?.Approver
                      : null
                  }
                  error={
                    Boolean(teamFormikFrom?.errors?.Approver) &&
                    teamFormikFrom?.touched?.Approver
                  }
                >
                  {allUserList?.map((usr, index) => {
                    return (
                      // eslint-disable-next-line react/no-array-index-key
                      <DropdownItem key={index} value={usr?.username}>
                        {usr?.username}
                      </DropdownItem>
                    );
                  })}
                </DropDown>
                <DropDown
                  label="Select reviewer"
                  value={teamFormikFrom.values.Reviewer}
                  onChange={(event) => {
                    teamFormikFrom.setFieldValue(
                      'Reviewer',
                      event.target.value
                    );
                  }}
                  helperText={
                    teamFormikFrom?.errors?.Reviewer &&
                    teamFormikFrom?.touched?.Reviewer
                      ? teamFormikFrom.errors?.Reviewer
                      : null
                  }
                  error={
                    Boolean(teamFormikFrom?.errors?.Reviewer) &&
                    teamFormikFrom?.touched?.Reviewer
                  }
                >
                  {allUserList?.map((usr, index) => {
                    return (
                      // eslint-disable-next-line react/no-array-index-key
                      <DropdownItem key={index} value={usr?.username}>
                        {usr?.username}
                      </DropdownItem>
                    );
                  })}
                </DropDown>
                <Stack
                  direction="row"
                  spacing={3}
                  justifyContent="center"
                  mt={3}
                >
                  <Button
                    onClick={() => {
                      teamFormikFrom.handleReset();
                    }}
                  >
                    RESET
                  </Button>
                  <Button
                    onClick={teamFormikFrom.handleSubmit}
                    variant="contained"
                  >
                    SUBMIT
                  </Button>
                  <Button
                    onClick={() => {
                      setStepForth('none');
                      setStepFifth('block');
                    }}
                  >
                    SKIP
                  </Button>
                </Stack>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
        <Grid container display={stepFifth}>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="space-around"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="700px">
              <DocumentUploadForm
                attachDocument={attachDocument}
                enitityType="ModelAssociation"
                entityId={entityDetails?.ModelEntityId}
                handleClose={handleClose}
              />
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </div>
  );
};

export default CreateAssociationModal;
