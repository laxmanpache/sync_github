import React, { useEffect, useState, useCallback } from 'react';
import { Box, Grid, IconButton } from '@mui/material';
import ReactFlow, {
  MiniMap,
  MarkerType,
  Background,
  Controls,
  applyNodeChanges,
} from 'reactflow';
import SyncIcon from '@mui/icons-material/Sync';
import * as _ from 'lodash';
import 'reactflow/dist/style.css';
import {
  WorkflowNode,
  ModelInventory,
  ModelAssociation,
} from '../../Common/ReactFlow/NodeTypes';
import useDashboard from '../../../hooks/ModelInventory/useDashboard';

const edgeOptions = {
  animated: true,
  style: {
    stroke: 'black',
  },
  markerEnd: {
    type: MarkerType.ArrowClosed,
    color: 'black',
  },
};
const connectionLineStyle = { stroke: 'black' };
// const DEFAULT_NODES = [
//   {
//     id: 'M1L1',
//     data: {
//       label: 'M1L1',
//     },
//     position: {
//       x: 69.33333333333331,
//       y: 80.999999999999972,
//     },

//     type: 'workflowNode',
//     sourcePosition: 'right',
//     targetPosition: 'left',
//   },
//   {
//     id: 'M2L3',
//     data: {
//       label: 'M2L2',
//     },
//     position: {
//       x: 50.33333333333331,
//       y: 50.999999999999972,
//     },

//     type: 'workflowNode',
//     sourcePosition: 'right',
//     targetPosition: 'left',
//   },
//   {
//     id: 'M3L3',
//     data: {
//       label: 'M3L3',
//     },
//     position: {
//       x: 100.33333333333331,
//       y: 15.999999999999972,
//     },
//     type: 'workflowNode',
//     sourcePosition: 'right',
//     targetPosition: 'left',
//   },
// ];
// const DEFAULT_EDGES = [
//   {
//     id: 'reactflow__edge-M1L1-M2L3',
//     style: {
//       stroke: 'black',
//     },
//     source: 'M1L1',
//     target: 'M2L3',
//     animated: true,
//     markerEnd: {
//       type: 'arrowclosed',
//       color: 'black',
//     },
//   },
//   {
//     id: 'reactflow__edge-M3L3-M2L3',
//     style: {
//       stroke: 'black',
//     },
//     source: 'M3L3',
//     target: 'M2L3',
//     animated: true,
//     rules_id: [],
//     markerEnd: {
//       type: 'arrowclosed',
//       color: 'black',
//     },
//   },
// ];
const defaultViewport = { x: 10, y: 15, zoom: 5 };

const AllNetworks = () => {
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  // eslint-disable-next-line no-unused-vars
  const [nodeData, setNodeData] = useState({});
  const { getNodesEdges } = useDashboard();
  const getNetWorkDetails = () => {
    getNodesEdges().then((res) => {
      setNodes(
        res?.data?.DEFAULT_NODES?.map((node) => {
          // eslint-disable-next-line no-unsafe-optional-chaining
          const X = node?.position?.x * 800;
          // eslint-disable-next-line no-unsafe-optional-chaining
          const Y = node?.position?.y * 400;

          return { ...node, position: { x: X, y: Y } };
        })
      );
      setEdges(res?.data?.DEFAULT_EDGES);
    });
  };
  useEffect(() => {
    getNetWorkDetails();
  }, []);

  const onNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );

  const onNodeClick = (event, node) => {
    setNodeData(_.clone(node));
  };

  const nodeTypes = React.useMemo(
    () => ({
      workflowNode: WorkflowNode,
      modelAssociation: ModelAssociation,
      modelInventory: ModelInventory,
    }),
    [WorkflowNode]
  );
  return (
    <Box>
      <Grid container spacing={1}>
        <Grid item container xs={12}>
          <Box
            width="100%"
            sx={{ height: `calc(100vh - 250px)`, position: 'relative' }}
          >
            <Box sx={{ position: 'absolute', right: 1, zIndex: 10 }}>
              <IconButton
                title="Sync changes"
                onClick={() => {
                  getNetWorkDetails();
                }}
              >
                <SyncIcon color="primary" />
              </IconButton>
            </Box>

            <ReactFlow
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              nodeTypes={nodeTypes}
              onNodeClick={onNodeClick}
              defaultEdgeOptions={edgeOptions}
              defaultViewport={defaultViewport}
              defaultZoom={1}
              maxZoom={1.5}
              fitView
              style={{
                backgroundColor: (theme) => theme.palette.other.white,
              }}
              connectionLineStyle={connectionLineStyle}
            >
              <Background
                variant="lines"
                gap={20}
                size={0.4}
                style={{ color: (theme) => theme.palette.primary.main }}
              />
              <MiniMap nodeStrokeWidth={3} />
              <Controls />
            </ReactFlow>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default AllNetworks;
