/* eslint-disable no-nested-ternary */
/* eslint-disable no-use-before-define */
/* eslint-disable react/prop-types */
import React, { useEffect, useState } from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Stack,
  TextField,
  Button,
} from '@mui/material';
import * as Yup from 'yup';
import CloseIcon from '@mui/icons-material/Close';
import { useFormik } from 'formik';
import { useSelector } from 'react-redux';
import { DropDown, DropdownItem } from '../Common/DropDown';
import SwalToast from '../Common/SwalTost';
import { VaultDynamicFrom } from '../Common/VaultDynamicFrom';
import DocumentUploadForm from '../Common/Forms/DocumentUploadForm';
import {
  ENTITY_TYPES,
  RELATION_OPTIONS,
  RISK_RATINGS,
} from '../../const/CommonConst';
import DialogTransition from '../Common/Transition/DialogTransition';

// const data = {
//   ws: {
//     entity_type: 'ws',
//     description: 'dsfsdfd',
//     sections: [
//       {
//         section_name: 'User Info',
//         attributes: [
//           {
//             name: 'usename',
//             label: 'User Name',
//             data_type: 'Text',
//             is_null: false,
//             defaultValue: null,
//             is_unique: false,
//             drop_down_options: [],
//             input_control_type: 'TEXTFIELD',
//             yup_schema: '',
//           },
//           {
//             name: 'lastname',
//             label: 'Last Name',
//             data_type: 'Text',
//             is_null: false,
//             defaultValue: null,
//             is_unique: true,
//             drop_down_options: [],
//             input_control_type: 'TEXTFIELD',
//             yup_schema: '',
//           },
//           {
//             name: 'address',
//             label: 'Address',
//             data_type: 'Text',
//             is_null: false,
//             defaultValue: null,
//             is_unique: false,
//             drop_down_options: [],
//             input_control_type: 'TEXTFIELD',
//             yup_schema: '',
//           },
//         ],
//       },
//       {
//         section_name: 'Educational Details',
//         attributes: [
//           {
//             name: 'collegename',
//             label: 'College Name',
//             data_type: 'Text',
//             is_null: false,
//             defaultValue: null,
//             is_unique: false,
//             drop_down_options: [
//               'ads',
//               'ww',
//               'sadasd',
//               'asdas',
//               'sad',
//               'sazdsa',
//               'sad',
//             ],
//             input_control_type: 'CHOICE',
//             yup_schema: '',
//           },
//           {
//             name: 'address1',
//             label: 'Address1',
//             data_type: 'Text',
//             is_null: false,
//             defaultValue: null,
//             is_unique: false,
//             drop_down_options: [],
//             input_control_type: 'TEXTFIELD',
//             yup_schema: '',
//           },
//         ],
//       },
//     ],
//   },
// };

const CreateModel = ({
  open,
  setOpen,
  entityList,
  typeOfEntity,
  createModelFirstStep,
  getCustomEntityTemplate,
  createModelSecondStep,
  getAllModelEntity,
  createModelThirdStep,
  createModelForthStep,
  attachDocument,
  allUserList,
  getModelDetails,
}) => {
  const [stepFirst, setStepFirst] = useState('block');
  const [stepSecond, setStepSecond] = useState('none');
  const [stepThird, setStepThird] = useState('none');
  const [stepForth, setStepForth] = useState('none');
  const [stepFifth, setStepFifth] = useState('none');
  const [fromDetails, setFormDetails] = useState([]);
  const [entityDetails, setEntityDetails] = useState({});
  const [modelAssociation, setModelAssociation] = useState([]);
  const { profileData } = useSelector((state) => state.users);

  const handleClose = () => {
    setOpen(!open);
    setStepSecond('none');
    setStepThird('none');
    setStepFirst('block');
    setStepForth('none');
    setStepFifth('none');
  };

  const formValidationSchema = Yup.object({
    model_name: Yup.string().required('Required'),
    entityName: Yup.string().required('Required'),
    entityType: Yup.string(),
    riskRating: Yup.string().required('Required'),
  });

  const formikForm = useFormik({
    initialValues: {
      model_name: '',
      entityName: '',
      entityType: typeOfEntity || '',
      riskRating: '',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      createModelFirstStep(values).then((res) => {
        if (res) {
          getModelDetails();
          setEntityDetails(res?.data?.ModelEntity);
          getCustomEntityTemplate({
            entityName: res?.data?.ModelEntity?.ModelEntityType,
          }).then((resp) => {
            if (resp) {
              setFormDetails(
                resp?.data?.Entity?.[res?.data?.ModelEntity?.ModelEntityType]
                  ?.sections
              );
              setTimeout(() => {
                setStepFirst('none');
                setStepSecond('block');
              }, 800);
            }
          });

          SwalToast({
            icon: 'success',
            title: 'Step first created successfully.',
          });
        }
      });

      formikForm.handleReset();
    },
  });

  const onSubmitSecondStep = (values) => {
    const params = {
      entity_id: entityDetails?.ModelEntityId,
      entity_type: 'ModelInventory',
    };
    createModelSecondStep({ attributeValue: values }, params).then((res) => {
      if (res) {
        setStepSecond('none');
        setStepThird('block');
        SwalToast({
          icon: 'success',
          title: 'Step second created successfully.',
        });
      }
    });
  };

  const associationFormValidationSchema = Yup.object({
    association_name: Yup.string().required('Required'),
    association_type: Yup.string().required('Required'),
    association_id: Yup.number().required('Required'),
    relation: Yup.string().required('Required'),
  });

  const associationFormikForm = useFormik({
    initialValues: {
      association_name: '',
      association_type: '',
      association_id: '',
      entity_type: 'ModelInventory',
      relation: '',
    },
    validationSchema: associationFormValidationSchema,
    onSubmit: (values) => {
      createModelThirdStep({
        entity_id: entityDetails?.ModelEntityId,
        ...values,
      }).then((res) => {
        if (res) {
          setStepForth('block');
          setStepThird('none');
          SwalToast({
            icon: 'success',
            title: res?.data?.msg,
          });
          associationFormikForm?.handleReset();
        }
      });
    },
  });

  const createTeamValidationSchema = Yup.object({
    Approver: Yup.string().required('Required'),
    Reviewer: Yup.string().required('Required'),
  });

  const teamFormikForm = useFormik({
    initialValues: {
      Approver: '',
      Reviewer: '',
    },
    validationSchema: createTeamValidationSchema,
    onSubmit: (values) => {
      createModelForthStep({
        entity_id: entityDetails?.ModelEntityId,
        entity_type: 'ModelInventory',
        team: values,
      }).then((res) => {
        if (res) {
          setStepForth('none');
          setStepFifth('block');
          SwalToast({
            icon: 'success',
            title: 'Team created successfully.',
          });
          teamFormikForm?.handleReset();
        }
      });
    },
  });

  useEffect(() => {
    formikForm?.setFieldValue('Primary Owner', profileData?.first_name);
  }, [profileData]);

  return (
    <div>
      <Dialog
        maxWidth={
          stepSecond === 'block' ? 'xl' : stepFifth === 'block' ? 'md' : 'xs'
        }
        open={open}
        onClose={() => {
          formikForm.handleReset();
          associationFormikForm.handleReset();
          teamFormikForm.handleReset();
          handleClose();
        }}
        TransitionComponent={DialogTransition}
      >
        <Grid container>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  formikForm.handleReset();
                  associationFormikForm.handleReset();
                  teamFormikForm.handleReset();
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Box
            display="flex"
            justifyContent="space-around"
            alignItems="center"
            mb={2}
          >
            <Typography variant="h3">
              {stepFirst === 'block'
                ? `Create Model`
                : stepSecond === 'block'
                ? 'Model Related Details'
                : stepThird === 'block'
                ? 'Link Association'
                : stepForth === 'block'
                ? 'Create Team'
                : 'Upload Document'}
            </Typography>
          </Box>
        </Grid>
        <Grid container display={stepFirst}>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="space-around"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="300px">
              <TextField
                name="model_name"
                value={formikForm?.values?.model_name}
                {...formikForm.getFieldProps('model_name')}
                placeholder="Enter model name."
                label="Model name"
                helperText={
                  formikForm?.errors?.model_name &&
                  formikForm?.touched?.model_name
                    ? formikForm?.errors?.model_name
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.model_name) &&
                  formikForm?.touched?.model_name
                }
              />
              <DropDown
                label="Template name"
                value={formikForm.values.entityName}
                onChange={(event) => {
                  formikForm.setFieldValue('entityName', event.target.value);
                }}
                helperText={
                  formikForm?.errors?.entityName &&
                  formikForm?.touched?.entityName
                    ? formikForm.errors?.entityName
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.entityName) &&
                  formikForm?.touched?.entityName
                }
              >
                {entityList?.map((entity) => {
                  return (
                    <DropdownItem
                      key={entity?.entity_name}
                      value={entity?.entity_name}
                    >
                      {entity?.entity_name}
                    </DropdownItem>
                  );
                })}
              </DropDown>
              <DropDown
                label="Risk rating"
                value={formikForm.values.riskRating}
                onChange={(event) => {
                  formikForm.setFieldValue('riskRating', event.target.value);
                }}
                helperText={
                  formikForm?.errors?.riskRating &&
                  formikForm?.touched?.riskRating
                    ? formikForm.errors?.riskRating
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.riskRating) &&
                  formikForm?.touched?.riskRating
                }
              >
                {RISK_RATINGS.map(({ label, value }) => (
                  <DropdownItem key={value} value={value}>
                    {label}
                  </DropdownItem>
                ))}
              </DropDown>
              <TextField
                name="entity_type"
                disabled
                defaultValue={typeOfEntity}
                value={formikForm?.values?.entity_type}
                {...formikForm.getFieldProps('entity_type')}
                placeholder="Enter entity type."
                label="Entity type"
              />
              <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
                <Button
                  onClick={() => {
                    formikForm.handleReset();
                  }}
                >
                  RESET
                </Button>
                <Button onClick={formikForm.handleSubmit} variant="contained">
                  NEXT
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
        <Grid container display={stepSecond}>
          <Grid item xs={12}>
            {stepSecond === 'block' ? (
              <VaultDynamicFrom
                fromSchema={fromDetails}
                stepFirst={stepFirst}
                onFormSubmit={onSubmitSecondStep}
              />
            ) : null}
          </Grid>

          {/* <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
            <Button
              onClick={() => {
                // formikFrom2.handleReset();
              }}
            >
              RESET
            </Button>
          </Stack> */}
        </Grid>
        <Grid container display={stepThird}>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="space-around"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="300px">
              <Stack direction="column" spacing={3} mt={3} width="300px">
                <DropDown
                  label="Relation Option"
                  value={associationFormikForm?.values?.relation}
                  name="relation_option"
                  onChange={(event) => {
                    associationFormikForm.setFieldValue(
                      'relation',
                      event.target.value
                    );
                  }}
                  helperText={
                    associationFormikForm?.errors?.relation &&
                    associationFormikForm?.touched?.relation
                      ? associationFormikForm?.errors?.relation
                      : null
                  }
                  error={
                    Boolean(associationFormikForm?.errors?.relation) &&
                    associationFormikForm?.touched?.relation
                  }
                >
                  {RELATION_OPTIONS.map(({ label, value }) => (
                    <DropdownItem key={label} value={value}>
                      {label}
                    </DropdownItem>
                  ))}
                </DropDown>
                <TextField
                  name="association_name"
                  value={associationFormikForm?.values?.association_name}
                  {...associationFormikForm.getFieldProps('association_name')}
                  placeholder="Enter association name."
                  label="Association name"
                  helperText={
                    associationFormikForm?.errors?.association_name &&
                    associationFormikForm?.touched?.association_name
                      ? associationFormikForm?.errors?.association_name
                      : null
                  }
                  error={
                    Boolean(associationFormikForm?.errors?.association_name) &&
                    associationFormikForm?.touched?.association_name
                  }
                />
                <DropDown
                  label="Association type"
                  value={associationFormikForm?.values?.association_type}
                  name="association_type"
                  onChange={(event) => {
                    getAllModelEntity({ entityType: event?.target.value }).then(
                      (res) => {
                        if (res) {
                          setModelAssociation(res?.data?.modelEntity);
                        }
                      }
                    );
                    associationFormikForm.setFieldValue('association_id', '');
                    associationFormikForm.setFieldValue(
                      'association_type',
                      event.target.value
                    );
                  }}
                  helperText={
                    associationFormikForm?.errors?.association_type &&
                    associationFormikForm?.touched?.association_type
                      ? associationFormikForm.errors?.association_type
                      : null
                  }
                  error={
                    Boolean(associationFormikForm?.errors?.association_type) &&
                    associationFormikForm?.touched?.association_type
                  }
                >
                  {ENTITY_TYPES.map((item) => (
                    <DropdownItem key={item?.value} value={item?.value}>
                      {item?.label}
                    </DropdownItem>
                  ))}
                </DropDown>
                <DropDown
                  label="Select association"
                  value={associationFormikForm?.values?.association_id}
                  onChange={(event) => {
                    associationFormikForm.setFieldValue(
                      'association_id',
                      event.target.value
                    );
                  }}
                  helperText={
                    associationFormikForm?.errors?.association_id &&
                    associationFormikForm?.touched?.association_id
                      ? associationFormikForm.errors?.association_id
                      : null
                  }
                  error={
                    Boolean(associationFormikForm?.errors?.association_id) &&
                    associationFormikForm?.touched?.association_id
                  }
                >
                  {modelAssociation?.length > 0 ? (
                    modelAssociation?.map((entity) => {
                      return (
                        <DropdownItem
                          key={entity?.association_id}
                          value={
                            associationFormikForm?.values?.association_type ===
                            'ModelAssociation'
                              ? entity?.association_id
                              : entity?.model_id
                          }
                        >
                          {associationFormikForm?.values?.association_type ===
                          'ModelAssociation'
                            ? entity?.association_name
                            : entity?.model_name}
                        </DropdownItem>
                      );
                    })
                  ) : (
                    <DropdownItem key={3} disabled>
                      no model present
                    </DropdownItem>
                  )}
                </DropDown>
                <Stack
                  direction="row"
                  spacing={3}
                  justifyContent="center"
                  mt={3}
                >
                  <Button
                    onClick={() => {
                      associationFormikForm.handleReset();
                    }}
                  >
                    RESET
                  </Button>
                  <Button
                    onClick={associationFormikForm.handleSubmit}
                    variant="contained"
                  >
                    NEXT
                  </Button>
                  <Button
                    onClick={() => {
                      setStepForth('block');
                      setStepThird('none');
                    }}
                  >
                    SKIP
                  </Button>
                </Stack>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
        <Grid container display={stepForth}>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="space-around"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="300px">
              <Stack direction="column" spacing={3} mt={3} width="300px">
                <DropDown
                  label="Select approver"
                  value={teamFormikForm.values.Approver}
                  onChange={(event) => {
                    teamFormikForm.setFieldValue(
                      'Approver',
                      event.target.value
                    );
                  }}
                  helperText={
                    teamFormikForm?.errors?.Approver &&
                    teamFormikForm?.touched?.Approver
                      ? teamFormikForm?.errors?.Approver
                      : null
                  }
                  error={
                    Boolean(teamFormikForm?.errors?.Approver) &&
                    teamFormikForm?.touched?.Approver
                  }
                >
                  {allUserList?.map((usr, index) => {
                    return (
                      // eslint-disable-next-line react/no-array-index-key
                      <DropdownItem key={index} value={usr?.username}>
                        {usr?.username}
                      </DropdownItem>
                    );
                  })}
                </DropDown>
                <DropDown
                  label="Select reviewer"
                  value={teamFormikForm.values.Reviewer}
                  onChange={(event) => {
                    teamFormikForm.setFieldValue(
                      'Reviewer',
                      event.target.value
                    );
                  }}
                  helperText={
                    teamFormikForm?.errors?.Reviewer &&
                    teamFormikForm?.touched?.Reviewer
                      ? teamFormikForm.errors?.Reviewer
                      : null
                  }
                  error={
                    Boolean(teamFormikForm?.errors?.Reviewer) &&
                    teamFormikForm?.touched?.Reviewer
                  }
                >
                  {allUserList?.map((usr, index) => {
                    return (
                      // eslint-disable-next-line react/no-array-index-key
                      <DropdownItem key={index} value={usr?.username}>
                        {usr?.username}
                      </DropdownItem>
                    );
                  })}
                </DropDown>
                <Stack
                  direction="row"
                  spacing={3}
                  justifyContent="center"
                  mt={3}
                >
                  <Button
                    onClick={() => {
                      teamFormikForm.handleReset();
                    }}
                  >
                    RESET
                  </Button>
                  <Button
                    onClick={teamFormikForm.handleSubmit}
                    variant="contained"
                  >
                    SUBMIT
                  </Button>
                  <Button
                    onClick={() => {
                      setStepForth('none');
                      setStepFifth('block');
                    }}
                  >
                    SKIP
                  </Button>
                </Stack>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
        <Grid container display={stepFifth}>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="space-around"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="700px">
              <DocumentUploadForm
                attachDocument={attachDocument}
                enitityType="ModelInventory"
                entityId={entityDetails?.ModelEntityId}
                handleClose={handleClose}
              />
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </div>
  );
};

export default CreateModel;
