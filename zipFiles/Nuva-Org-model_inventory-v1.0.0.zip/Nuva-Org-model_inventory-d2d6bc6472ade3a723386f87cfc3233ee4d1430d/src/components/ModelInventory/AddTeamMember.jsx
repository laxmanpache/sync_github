import React from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Stack,
  Button,
} from '@mui/material';
import * as Yup from 'yup';
import CloseIcon from '@mui/icons-material/Close';
import PropTypes from 'prop-types';
import { useFormik } from 'formik';
import { DropDown, DropdownItem } from '../Common/DropDown';
import SwalToast from '../Common/SwalTost';
import DialogTransition from '../Common/Transition/DialogTransition';

const AddTeamMember = ({
  open,
  handleClose,
  entityId,
  addSingleTeamMember,
  allUserList,
  allUserRoles,
  getAllTeamDetails,
}) => {
  const formValidationSchema = Yup.object({
    role: Yup.string().required('Required'),
    user: Yup.string().required('Required'),
  });
  const formikForm = useFormik({
    initialValues: {
      role: '',
      user: '',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      const teamMember = {};
      teamMember[values?.role] = values?.user;
      addSingleTeamMember({
        entity_id: entityId,
        entity_type: 'ModelInventory',
        team: teamMember,
      }).then((res) => {
        if (res) {
          handleClose();
          SwalToast({
            icon: 'success',
            title: 'Team member added successfully.',
          });
          getAllTeamDetails();
          formikForm?.handleReset();
        }
      });
      formikForm.handleReset();
      handleClose();
    },
  });
  return (
    <Box>
      <Dialog
        maxWidth="xs"
        open={open}
        onClose={handleClose}
        TransitionComponent={DialogTransition}
      >
        <Grid container>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Grid item xs={12}>
            <Box
              display="flex"
              justifyContent="space-around"
              alignItems="center"
              mb={2}
            >
              <Typography variant="h3">Add Team Member</Typography>
            </Box>
          </Grid>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="300px">
              <DropDown
                label="Select member"
                value={formikForm.values.user}
                {...formikForm.getFieldProps('user')}
                helperText={
                  formikForm?.errors?.user && formikForm?.touched?.user
                    ? formikForm.errors.user
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.user) && formikForm?.touched?.user
                }
                onChange={(event) => {
                  formikForm.setFieldValue('user', event.target.value);
                }}
              >
                {allUserList?.map((usr) => {
                  return (
                    <DropdownItem key={1} value={usr?.username}>
                      {usr?.username}
                    </DropdownItem>
                  );
                })}
              </DropDown>
              <DropDown
                label="Role type"
                value={formikForm.values.role}
                helperText={
                  formikForm?.errors?.role && formikForm?.touched?.role
                    ? formikForm.errors.role
                    : null
                }
                {...formikForm.getFieldProps('role')}
                error={
                  Boolean(formikForm?.errors?.role) && formikForm?.touched?.role
                }
                onChange={(event) => {
                  formikForm.setFieldValue('role', event.target.value);
                }}
              >
                {allUserRoles?.map((role) => {
                  return (
                    <DropdownItem key={1} value={role?.role_name}>
                      {role?.role_name}
                    </DropdownItem>
                  );
                })}
              </DropDown>

              <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
                <Button
                  onClick={() => {
                    formikForm.handleReset();
                  }}
                >
                  RESET
                </Button>
                <Button onClick={formikForm.handleSubmit} variant="contained">
                  SUBMIT
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </Box>
  );
};
AddTeamMember.propTypes = {
  open: PropTypes.bool.isRequired,
  entityId: PropTypes.number.isRequired,
  handleClose: PropTypes.func.isRequired,
  allTeamMembers: PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.object]))
    .isRequired,
  allUserList: PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.object]))
    .isRequired,
  allUserRoles: PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.object]))
    .isRequired,
  addSingleTeamMember: PropTypes.func.isRequired,
  getAllTeamDetails: PropTypes.func.isRequired,
};

export default AddTeamMember;
