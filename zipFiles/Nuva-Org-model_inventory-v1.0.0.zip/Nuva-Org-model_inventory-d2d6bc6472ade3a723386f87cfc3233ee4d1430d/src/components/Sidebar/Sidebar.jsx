/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
/* eslint-disable react/jsx-no-useless-fragment */
import { Box, IconButton, Drawer, Slide, Stack, alpha } from '@mui/material';
import React, { useState } from 'react';
import List from '@mui/material/List';
import { AiOutlineMenuUnfold, AiOutlineMenuFold } from 'react-icons/ai';
import { styled, useTheme } from '@mui/material/styles';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Collapse from '@mui/material/Collapse';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import { NavLink, useLocation } from 'react-router-dom';

import SidebarConfig from './SidebarConfig';
// import useTheme from '@mui/material/styles';
const COLLAPSE_WIDTH = 250;
const DRAWER_WIDTH = 400;

const NavSection = ({ item, setCollapse, collapse }) => {
  const { pathname } = useLocation();
  const theme = useTheme();
  const ActiveRoot =
    pathname?.split('/')[1] === item?.route || item?.route === pathname;
  const [open, setOpen] = useState(ActiveRoot);
  const activeRootStyle = {
    color: theme.palette.primary.dark,
    fontWeight: '600',
    bgcolor: theme.palette.secondary.main,
    borderRadius: '4px',
    '&:before': { display: 'block' },
    borderLeft: 'solid',
    svg: {
      color: theme.palette.primary.main,
      fill: theme.palette.primary.main,
    },
  };
  const handleClick = () => {
    if (collapse == null) {
      setOpen(false);
      setCollapse(0);
    }
    setCollapse(null);
    setOpen(!open);
  };
  const NavItem = styled(NavLink)``;
  return (
    <>
      {item?.children?.length > 0 ? (
        <>
          <ListItemButton onClick={handleClick}>
            <ListItemIcon>{item?.icon}</ListItemIcon>
            <ListItemText primary={item?.name} />
            {open ? <ExpandLess /> : <ExpandMore />}
          </ListItemButton>
          <Collapse in={open} timeout="auto" unmountOnExit>
            {item?.children.map((subItem) => {
              return (
                <List
                  component="div"
                  sx={{
                    ...(subItem?.route === pathname && activeRootStyle),
                  }}
                  key={subItem?.name}
                  disablePadding
                >
                  <ListItemButton
                    component={NavItem}
                    to={subItem.route}
                    sx={{ pl: 4 }}
                  >
                    <ListItemIcon>{subItem?.icon}</ListItemIcon>
                    <ListItemText primary={subItem?.name} />
                  </ListItemButton>
                </List>
              );
            })}
          </Collapse>
        </>
      ) : (
        <List
          component="div"
          key={item?.name}
          disablePadding
          sx={{ ...(ActiveRoot && activeRootStyle) }}
        >
          <ListItemButton component={NavItem} to={item.route} key={item.name}>
            <ListItemIcon>{item?.icon}</ListItemIcon>
            <ListItemText primary={item?.name} />
          </ListItemButton>
        </List>
      )}
    </>
  );
};
// eslint-disable-next-line no-unused-vars
const Sidebar = ({ collapse, setCollapse }) => {
  const theme = useTheme();
  return (
    <Box>
      <Slide in={true} direction="right" mountOnEnter timeout={700}>
        <List
          sx={{
            // eslint-disable-next-line no-shadow
            bgcolor: (theme) => theme.palette.secondary.light,
            overflow: 'hidden',
          }}
          component="nav"
          subheader={
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              {collapse === 0 ? (
                <IconButton
                  onClick={() => {
                    setCollapse(null);
                  }}
                >
                  <AiOutlineMenuUnfold />
                </IconButton>
              ) : (
                <IconButton
                  onClick={() => {
                    setCollapse(0);
                  }}
                >
                  <AiOutlineMenuFold />
                </IconButton>
              )}
            </Box>
          }
          aria-labelledby="nested-list-subheader"
        >
          {SidebarConfig?.map((item) => {
            return (
              <>
                <NavSection
                  collapse={collapse}
                  setCollapse={setCollapse}
                  item={item}
                />
              </>
            );
          })}
        </List>
      </Slide>
    </Box>
  );
};

export default Sidebar;
