const SidebarConfig = [
  {
    name: 'Model Inventory',
    key: 'ModelInventory',
    path: 'model-inventory',
    children: [
      {
        name: 'Dashboard',
        key: 'dashboard',
        route: '/dashboard',
      },
      {
        name: 'Model Inventory',
        route: '/model-inventory',
        key: 'modelInventory',
      },
      // {
      //   name: 'Create Model Inventory',
      //   key: 'createModelInventory',
      //   route: '/model-inventory/create-model-Inventory',
      // },
      {
        name: 'Import From Excel',
        key: 'importFromExcel',
        route: '/model-inventory/import-from-excel',
      },
    ],
  },
  {
    name: 'Model Association',
    path: 'model-association',
    key: 'ModelAssociation',
    children: [
      // {
      //   name: 'Model Association',
      //   route: '/model-association',
      //   key: 'modelAssociation',
      // },
      // {
      //   name: 'Model Validation',
      //   key: 'modelValidation',
      //   route: '/model-validation',
      // },
    ],
  },
  {
    name: 'Rules,Reports & Alerts',
    key: 'RulesReportsAlert',
    children: [
      {
        name: 'Rules',
        key: 'rules',
        route: '/rules',
      },
      {
        name: 'Reports',
        key: 'report',
        route: '/report',
      },
    ],
  },
  {
    name: 'Configuration',
    key: 'Configuration',
    path: 'configuration',
    children: [
      // {
      //   name: 'Configuration',
      //   route: '/configuration',
      //   key: 'configuration',
      // },
      {
        name: 'Workflow',
        key: 'workflow',
        route: '/configuration/workflow',
      },
      {
        name: 'Template List',
        key: 'templateList',
        route: '/configuration/template-list',
      },
    ],
  },
  {
    name: 'Administrative Options',
    route: '/model-inventory',
    key: 'AdministrativeOptions',
    disable: true,
  },
];

export default SidebarConfig;
