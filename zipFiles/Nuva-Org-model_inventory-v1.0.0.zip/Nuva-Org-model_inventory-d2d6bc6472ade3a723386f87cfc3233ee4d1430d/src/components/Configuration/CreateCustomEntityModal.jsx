import React from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Stack,
  TextField,
  Button,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import * as Yup from 'yup';
import PropTypes from 'prop-types';
import { useFormik } from 'formik';

import { DropDown, DropdownItem } from '../Common/DropDown';
import SwalToast from '../Common/SwalTost';
import { ENTITY_TYPES } from '../../const/CommonConst';

const CreateCustomEntityModal = ({
  open,
  handleClose,
  createCustomEntity,
  attachWorkflow,
  workflowList,
}) => {
  const formValidationSchema = Yup.object({
    entity_name: Yup.string().required('Required'),
    description: Yup.string().required('Required'),
    entity_type: Yup.string().required('Required'),
    prefix_key: Yup.string().required('Required'),
    workflowType: Yup.string().required('Required'),
  });

  const formikForm = useFormik({
    initialValues: {
      entity_name: '',
      description: '',
      entity_type: '',
      workflowType: '',
      section_list: [],
      prefix_key: '',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      const body = {
        entityName: values?.entity_name,
        workflowType: values?.workflowType,
      };
      createCustomEntity(values).then((res) => {
        if (res) {
          SwalToast({
            icon: 'success',
            title: 'Entity created successfully.',
          });
          attachWorkflow(body).then(() => {
            if (res) {
              SwalToast({
                icon: 'success',
                title: 'Workflow connected successfully.',
              });
            }
          });
        }

        handleClose(res?.data?.entity_name);
      });
      formikForm.handleReset();
    },
  });

  return (
    <Box>
      <Dialog
        maxWidth="sm"
        open={open}
        onClose={() => {
          formikForm.handleReset();
          handleClose();
        }}
      >
        <Grid container>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  formikForm.handleReset();
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
          <Grid item xs={12}>
            <Box
              display="flex"
              justifyContent="space-around"
              alignItems="center"
              mb={2}
            >
              <Typography variant="h3">Create New Template</Typography>
            </Box>
          </Grid>
        </Grid>

        <Grid
          item
          container
          xs={12}
          display="flex"
          justifyContent="space-around"
          alignItems="center"
          spacing={2}
          padding={2}
        >
          <Grid item xs={6}>
            <TextField
              name="entity_name"
              value={formikForm?.values?.entity_name}
              {...formikForm.getFieldProps('entity_name')}
              helperText={
                formikForm?.errors?.entity_name &&
                formikForm?.touched?.entity_name
                  ? formikForm.errors.entity_name
                  : null
              }
              error={
                Boolean(formikForm?.errors?.entity_name) &&
                formikForm?.touched?.entity_name
              }
              placeholder="Enter entity name."
              label="Entity name"
            />
          </Grid>
          <Grid item xs={6}>
            <DropDown
              label="Template type"
              value={formikForm.values.entity_type}
              onChange={(event) => {
                formikForm.setFieldValue('entity_type', event.target.value);
              }}
              helperText={
                formikForm?.errors?.entity_type &&
                formikForm?.touched?.entity_type
                  ? formikForm.errors.entity_type
                  : null
              }
              error={
                Boolean(formikForm?.errors?.entity_type) &&
                formikForm?.touched?.entity_type
              }
            >
              {ENTITY_TYPES.map((entityType, i) => (
                // eslint-disable-next-line react/no-array-index-key
                <DropdownItem key={i} value={entityType?.value}>
                  {entityType?.label}
                </DropdownItem>
              ))}
            </DropDown>
          </Grid>
          <Grid item xs={6}>
            <DropDown
              label="Attach workflow"
              value={formikForm.values.workflowType}
              onChange={(event) => {
                formikForm.setFieldValue('workflowType', event.target.value);
              }}
              helperText={
                formikForm?.errors?.workflowType &&
                formikForm?.touched?.workflowType
                  ? formikForm.errors.workflowType
                  : null
              }
              error={
                Boolean(formikForm?.errors?.workflowType) &&
                formikForm?.touched?.workflowType
              }
            >
              {workflowList?.map((workflow) => {
                return (
                  <DropdownItem key={1} value={workflow?.label}>
                    {workflow?.label}
                  </DropdownItem>
                );
              })}
            </DropDown>
          </Grid>
          <Grid item xs={6}>
            <TextField
              name="description"
              value={formikForm?.values?.description}
              label="Enter description"
              {...formikForm.getFieldProps('description')}
              helperText={
                formikForm?.errors?.description &&
                formikForm?.touched?.description
                  ? formikForm.errors.description
                  : null
              }
              error={
                Boolean(formikForm?.errors?.description) &&
                formikForm?.touched?.description
              }
              placeholder="Enter entity description."
              multiline
              row={3}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              name="prefix_key"
              value={formikForm?.values?.prefix_key}
              label="Prefix"
              {...formikForm.getFieldProps('prefix_key')}
              helperText={
                formikForm?.errors?.prefix_key &&
                formikForm?.touched?.prefix_key
                  ? formikForm.errors.prefix_key
                  : null
              }
              error={
                Boolean(formikForm?.errors?.prefix_key) &&
                formikForm?.touched?.prefix_key
              }
              placeholder="Enter Prefix."
              multiline
              row={3}
            />
          </Grid>
        </Grid>

        <Grid item xs={12}>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={1} width="300px">
              <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
                <Button
                  onClick={() => {
                    formikForm.handleReset();
                  }}
                >
                  RESET
                </Button>
                <Button onClick={formikForm.handleSubmit} variant="contained">
                  SUBMIT
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </Box>
  );
};
CreateCustomEntityModal.propTypes = {
  open: PropTypes.bool.isRequired,
  setOpenCreateEntityModal: PropTypes.func.isRequired,
  handleClose: PropTypes.func.isRequired,
  createCustomEntity: PropTypes.func.isRequired,
  attachWorkflow: PropTypes.func.isRequired,
  workflowList: PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.object]))
    .isRequired,
};

export default CreateCustomEntityModal;
