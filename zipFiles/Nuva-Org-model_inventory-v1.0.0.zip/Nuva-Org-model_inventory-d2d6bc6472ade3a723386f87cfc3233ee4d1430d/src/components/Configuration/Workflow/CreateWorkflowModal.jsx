import React from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Stack,
  Button,
  TextField,
} from '@mui/material';
import * as Yup from 'yup';
import CloseIcon from '@mui/icons-material/Close';
import { useFormik } from 'formik';
import PropTypes from 'prop-types';
import SwalToast from '../../Common/SwalTost';

const CreateWorkflowModal = ({ open, handleClose, createWorkflow }) => {
  const formValidationSchema = Yup.object({
    label: Yup.string().required('Required'),
    description: Yup.string().required('Required'),
  });
  const formikForm = useFormik({
    initialValues: {
      label: '',
      description: '',
      flowDisplay: {},
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      createWorkflow(values).then((res) => {
        if (res) {
          SwalToast({
            icon: 'success',
            title: 'Workflow created successfully.',
          });
          formikForm.handleReset();
          handleClose();
        }
      });
    },
  });
  return (
    <Box>
      <Dialog
        maxWidth="xs"
        open={open}
        onClose={() => {
          formikForm.handleReset();
          handleClose();
        }}
      >
        <Grid container xs={12}>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  formikForm.handleReset();
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
          <Grid item xs={12}>
            <Box
              display="flex"
              justifyContent="space-around"
              alignItems="center"
              mb={2}
            >
              <Typography variant="h3">Add Workflow State</Typography>
            </Box>
          </Grid>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="300px">
              <TextField
                name="label"
                value={formikForm?.values?.label}
                {...formikForm.getFieldProps('label')}
                placeholder="Enter flow name."
                label="Workflow name"
                helperText={
                  formikForm?.errors?.label && formikForm?.touched?.label
                    ? formikForm.errors.label
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.label) &&
                  formikForm?.touched?.label
                }
              />
              <TextField
                name="description"
                value={formikForm?.values?.description}
                {...formikForm.getFieldProps('description')}
                placeholder="Enter Workflow description."
                label="Workflow description"
                helperText={
                  formikForm?.errors?.description &&
                  formikForm?.touched?.description
                    ? formikForm.errors.description
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.description) &&
                  formikForm?.touched?.description
                }
              />

              <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
                <Button
                  onClick={() => {
                    formikForm.handleReset();
                  }}
                >
                  RESET
                </Button>
                <Button onClick={formikForm.handleSubmit} variant="contained">
                  SUBMIT
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </Box>
  );
};
CreateWorkflowModal.propTypes = {
  open: PropTypes.bool.isRequired,
  handleClose: PropTypes.func.isRequired,
  createWorkflow: PropTypes.func.isRequired,
};

export default CreateWorkflowModal;
