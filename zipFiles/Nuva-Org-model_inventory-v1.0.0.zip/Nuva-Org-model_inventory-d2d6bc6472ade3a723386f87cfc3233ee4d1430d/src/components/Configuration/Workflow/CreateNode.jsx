import React from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Stack,
  Button,
  TextField,
} from '@mui/material';
import * as Yup from 'yup';
import CloseIcon from '@mui/icons-material/Close';
import { useFormik } from 'formik';
import PropTypes from 'prop-types';
import DialogTransition from '../../Common/Transition/DialogTransition';

const CreateNode = ({ open, handleClose, setNodes }) => {
  const formValidationSchema = Yup.object({
    label: Yup.string().required('Required'),
    description: Yup.string().required('Required'),
  });
  const formikForm = useFormik({
    initialValues: {
      label: '',
      description: '',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      const newNode = {
        id: values?.label,
        data: {
          label: values?.label,
          description: values?.description,
        },
        position: {
          x: 69.33333333333331,
          y: 9.999999999999972,
        },
        label: values?.label,
        description: values?.description,
        type: 'workflowNode',
        nodeId: 294,
        sourcePosition: 'right',
        targetPosition: 'left',
        nodeDisplayName: 'Draft',
      };
      setNodes((pre) => [...pre, newNode]);
      formikForm.handleReset();
      handleClose();
    },
  });
  return (
    <Box>
      <Dialog
        maxWidth="xs"
        open={open}
        onClose={handleClose}
        TransitionComponent={DialogTransition}
      >
        <Grid container>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Grid item xs={12}>
            <Box
              display="flex"
              justifyContent="space-around"
              alignItems="center"
              mb={2}
            >
              <Typography variant="h3">Add Workflow State</Typography>
            </Box>
          </Grid>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="300px">
              <TextField
                name="label"
                value={formikForm?.values?.label}
                {...formikForm.getFieldProps('label')}
                placeholder="Enter flow name."
                label="Flow status name"
                helperText={
                  formikForm?.errors?.label && formikForm?.touched?.label
                    ? formikForm.errors.label
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.label) &&
                  formikForm?.touched?.label
                }
              />
              <TextField
                name="description"
                value={formikForm?.values?.description}
                {...formikForm.getFieldProps('description')}
                placeholder="Enter description."
                label="Flow status description"
                helperText={
                  formikForm?.errors?.description &&
                  formikForm?.touched?.description
                    ? formikForm.errors.description
                    : null
                }
                error={
                  Boolean(formikForm?.errors?.description) &&
                  formikForm?.touched?.description
                }
              />

              <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
                <Button
                  onClick={() => {
                    formikForm.handleReset();
                  }}
                >
                  RESET
                </Button>
                <Button onClick={formikForm.handleSubmit} variant="contained">
                  SUBMIT
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </Box>
  );
};
CreateNode.propTypes = {
  open: PropTypes.bool.isRequired,
  handleClose: PropTypes.func.isRequired,
  setNodes: PropTypes.func.isRequired,
};

export default CreateNode;
