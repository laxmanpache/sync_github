import React from 'react';

import { Handle } from 'reactflow';
import { Box, Typography, Card } from '@mui/material';
import PropTypes from 'prop-types';
import AccountTreeIcon from '@mui/icons-material/AccountTree';

const WorkflowNode = ({ data }) => {
  return (
    <>
      <Card
        elevation={1}
        title={`${data?.label} node`}
        sx={{
          borderWidth: '1px',
          borderStyle: 'solid',
          borderColor: (theme) => theme.palette.primary.light,
          display: 'flex',
          flexGrow: 1,
          borderRadius: 1,
          maxWidth: '200px',
          background: (theme) => theme.palette.primary.contrastText,
        }}
      >
        <Box
          sx={{
            background: (theme) => theme.palette.other.gray3,
          }}
          p={1}
        >
          <AccountTreeIcon color="primary" width={20} height={20} />
        </Box>
        <Box
          px={1}
          py={0.5}
          m={0}
          width="100%"
          overflow="hidden"
          textOverflow="ellipsis"
          display="flex"
          flexDirection="column"
        >
          <Typography
            sx={{
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
            variant="body3"
          >
            {data?.label}
          </Typography>
        </Box>
      </Card>
      <Handle
        type="source"
        position="right"
        id="b"
        style={{ bottom: 15, top: 'auto', background: '#555' }}
        isConnectable={true}
      />
      <Handle
        type="target"
        position="left"
        id="b"
        style={{ bottom: 15, top: 'auto', background: '#555' }}
        isConnectable={true}
      />
    </>
  );
};

WorkflowNode.propTypes = {
  data: PropTypes.oneOfType([PropTypes.object]).isRequired,
};
export default WorkflowNode;
