/* eslint-disable react/prop-types */
import React, { useEffect, useState } from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Stack,
  Switch,
  Button,
  Autocomplete,
  TextField,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import CloseIcon from '@mui/icons-material/Close';
import PropTypes from 'prop-types';
import { useFormik } from 'formik';
import * as _ from 'lodash';

import { DropDown, DropdownItem } from '../../Common/DropDown';

const EditWorkflowNode = ({
  open,
  handleClose,
  nodeData,
  allEdges,
  setNodes,
  allUserRoles,
  setEdges,
  rules,
}) => {
  const [prevEdgeData, setPrevEdgeData] = useState({});
  const getIncomingNodeIds = (node, edges = []) => {
    const incomingNodes = [];
    edges.forEach((element) => {
      if (node.label === element.target) {
        setPrevEdgeData(element);
        incomingNodes.push(element?.source);
      }
    });
    return incomingNodes;
  };
  const formikForm = useFormik({
    initialValues: {
      onApprove: false,
      toassignRole: 'PrimaryOwner',
      rules: [],
    },
    onSubmit: (values) => {
      const body = _.clone(prevEdgeData);
      body.onApprove = values?.onApprove;
      body.toassignRole = values?.toassignRole;
      body.rules_id = values?.rules?.map((rule) => rule?.id) ?? [];
      setPrevEdgeData(body);
      setEdges((edg) => {
        const data = edg?.filter((ed) => ed.target !== body.target);
        return [...data, body];
      });
      handleClose();
    },
  });

  useEffect(() => {
    // eslint-disable-next-line no-unused-vars
    const incomingNodes = getIncomingNodeIds(nodeData, allEdges);
    formikForm.setFieldValue('onApprove', prevEdgeData?.onApprove);
    formikForm.setFieldValue('toassignRole', prevEdgeData?.toassignRole);
    formikForm.setFieldValue(
      'rules',
      rules?.filter((rule) => prevEdgeData?.rules_id?.includes(rule?.id))
    );
  }, [nodeData, open, prevEdgeData]);
  return (
    <Box>
      <Dialog maxWidth="xs" open={open} onClose={handleClose}>
        <Grid container overflow="auto">
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Grid item xs={12}>
            <Box
              display="flex"
              justifyContent="space-around"
              alignItems="center"
              mb={2}
            >
              <Typography variant="h3">
                {`${nodeData?.label}  Status`}
              </Typography>
            </Box>
          </Grid>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            <Stack
              direction="column"
              justifyContent="center"
              spacing={3}
              mt={3}
              width="200px"
            >
              {nodeData?.label !== 'Draft' ? (
                <>
                  <Grid item xs={12} display="flex">
                    <Autocomplete
                      value={formikForm.values.rules}
                      onChange={(event, newValue) => {
                        formikForm.setFieldValue('rules', newValue);
                      }}
                      multiple
                      options={rules}
                      getOptionLabel={(option) => option?.label}
                      isOptionEqualToValue={(option, value) =>
                        option?.id === value?.id
                      }
                      fullWidth
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Rules"
                          placeholder="Rules"
                        />
                      )}
                    />
                  </Grid>
                  <Grid item xs={12} display="flex">
                    <DropDown
                      label="To Assign Role"
                      value={formikForm.values.toassignRole}
                      {...formikForm.getFieldProps('toassignRole')}
                      onChange={(event) => {
                        formikForm.setFieldValue(
                          'toassignRole',
                          event.target.value
                        );
                      }}
                    >
                      {allUserRoles?.map((role) => {
                        return (
                          <DropdownItem key={1} value={role?.role_name}>
                            {role?.role_name}
                          </DropdownItem>
                        );
                      })}
                    </DropDown>
                  </Grid>
                  <Grid item xs={12} display="flex">
                    <Grid item xs={6}>
                      <Typography variant="subtitle">Is Approved:</Typography>
                    </Grid>
                    <Grid item xs={12}>
                      <Switch
                        name="onApprove"
                        checked={formikForm.values.onApprove === true}
                        onChange={(e, checked) => {
                          formikForm.setFieldValue('onApprove', checked);
                        }}
                      />
                    </Grid>
                  </Grid>

                  <Box>
                    <IconButton
                      width="10px"
                      onClick={() => {
                        setNodes((nds) =>
                          nds.filter((node) => node.label !== nodeData?.label)
                        );
                        handleClose();
                      }}
                      title="Delete Node"
                    >
                      <DeleteIcon color="primary" />
                    </IconButton>
                  </Box>
                </>
              ) : null}

              <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
                <Button
                  onClick={() => {
                    formikForm.handleReset();
                  }}
                >
                  RESET
                </Button>
                <Button onClick={formikForm.handleSubmit} variant="contained">
                  SUBMIT
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </Box>
  );
};
EditWorkflowNode.propTypes = {
  open: PropTypes.bool.isRequired,
  handleClose: PropTypes.func.isRequired,
};

export default EditWorkflowNode;
