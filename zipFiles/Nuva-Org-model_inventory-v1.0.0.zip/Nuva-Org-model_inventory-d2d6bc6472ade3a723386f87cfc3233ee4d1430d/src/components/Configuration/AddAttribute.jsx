import React from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Stack,
  TextField,
  Button,
  Switch,
} from '@mui/material';
import * as _ from 'lodash';
import CloseIcon from '@mui/icons-material/Close';
import PropTypes from 'prop-types';
import { useFormik } from 'formik';
import * as Yup from 'yup';

import { DropDown, DropdownItem } from '../Common/DropDown';
import SwalToast from '../Common/SwalTost';
import DialogTransition from '../Common/Transition/DialogTransition';

const AddAttribute = ({
  open,
  handleClose,
  addAttribute,
  selectedSectionName,
  entityType,
  getCustomEntityTemp,
}) => {
  function isJsonString(str) {
    if (_.isEmpty(str)) return true;
    try {
      JSON.parse(str);
    } catch (e) {
      return false;
    }
    return true;
  }

  Yup.addMethod(Yup.string, 'isJsonString', isJsonString);
  const formValidationSchema = Yup.object({
    attribute_name: Yup.string().required('Required'),
    display_name: Yup.string().required('Required'),
    data_type: Yup.string().required('Required'),
    attribute_order: Yup.string().required('Required'),
    input_control_type: Yup.string().required('Required'),
    entity_type: Yup.string().required('Required'),
    drop_down_options: Yup.string().when(
      'input_control_type',
      (inputControlType) => {
        return ['SINGLE_SELECT', 'MULTI_SELECT']?.includes(inputControlType[0])
          ? Yup.string().required('Required')
          : Yup.string();
      }
    ),
    yup_schema: Yup.string().test(
      'isJsonString',
      'Enter valid json',
      isJsonString
    ),
  }).required('Required');

  const formikForm = useFormik({
    initialValues: {
      attribute_name: '',
      display_name: '',
      section: selectedSectionName || '',
      is_unique: false,
      is_null: false,
      data_type: '',
      deafult: '',
      entity_type: entityType || '',
      yup_schema: '{ "schema": [{}] }',
      attribute_order: '',
      input_control_type: '',
      drop_down_options: '',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      addAttribute({
        ...values,
        yup_schema: JSON.parse(values?.yup_schema)?.schema || [],
        name: values?.attribute_name,
        label: values?.display_name,
        drop_down_options:
          // eslint-disable-next-line camelcase
          typeof values?.drop_down_options === 'string' &&
          values?.drop_down_options?.length > 0
            ? values?.drop_down_options?.split(',')
            : [],
      }).then((res) => {
        if (res) {
          SwalToast({
            icon: 'success',
            title: 'Attribute added successfully.',
          });
          getCustomEntityTemp(entityType);
        }
      });
      handleClose();
      formikForm.handleReset();
    },
  });

  return (
    <Box>
      <Dialog
        maxWidth="md"
        open={open}
        onClose={handleClose}
        TransitionComponent={DialogTransition}
      >
        <Grid container>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Grid item xs={12}>
            <Box
              display="flex"
              justifyContent="space-around"
              alignItems="center"
              mb={2}
            >
              <Typography variant="h3">Add Attribute</Typography>
            </Box>
          </Grid>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            <Stack direction="column" spacing={3} mt={3} width="100%">
              <Grid
                container
                display="flex"
                justifyContent="center"
                item
                xs={12}
              >
                <Grid xs={3} mr={2}>
                  <TextField
                    name="attribute_name"
                    value={formikForm?.values?.attribute_name}
                    {...formikForm.getFieldProps('attribute_name')}
                    placeholder="Enter attribute name."
                    label="Attribute name"
                    helperText={
                      formikForm?.errors?.attribute_name &&
                      formikForm?.touched?.attribute_name
                        ? formikForm.errors.attribute_name
                        : null
                    }
                    error={
                      Boolean(formikForm?.errors?.attribute_name) &&
                      formikForm?.touched?.attribute_name
                    }
                  />
                </Grid>
                <Grid xs={3} mr={2}>
                  <TextField
                    name="display_name"
                    value={formikForm?.values?.display_name}
                    {...formikForm.getFieldProps('display_name')}
                    placeholder="Enter attribute display name."
                    label="Attribute display name"
                    helperText={
                      formikForm?.errors?.display_name &&
                      formikForm?.touched?.display_name
                        ? formikForm.errors.display_name
                        : null
                    }
                    error={
                      Boolean(formikForm?.errors?.display_name) &&
                      formikForm?.touched?.display_name
                    }
                  />
                </Grid>
                <Grid xs={3}>
                  <TextField
                    name="section"
                    label="Section name"
                    placeholder="Enter entity section."
                    required
                    disabled
                    defaultValue={selectedSectionName}
                    type="text"
                    value={formikForm.values.section}
                    onChange={(event) => {
                      formikForm.setFieldValue('section', event.target.value);
                    }}
                    helperText={
                      formikForm?.errors?.section &&
                      formikForm?.touched?.section
                        ? formikForm.errors.section
                        : null
                    }
                    error={
                      Boolean(formikForm?.errors?.section) &&
                      formikForm?.touched?.section
                    }
                  />
                </Grid>
              </Grid>

              <Grid
                container
                display="flex"
                justifyContent="center"
                item
                xs={12}
              >
                <Grid xs={3} mr={2}>
                  <TextField
                    name="entity_type"
                    value={formikForm?.values?.entity_type}
                    label="Entity type"
                    disabled
                    {...formikForm.getFieldProps('entity_type')}
                    placeholder="Entity type."
                    helperText={
                      formikForm?.errors?.entity_type &&
                      formikForm?.touched?.entity_type
                        ? formikForm.errors.entity_type
                        : null
                    }
                    error={
                      Boolean(formikForm?.errors?.entity_type) &&
                      formikForm?.touched?.entity_type
                    }
                  />
                </Grid>
                <Grid xs={3} mr={2}>
                  <DropDown
                    label="Data type"
                    value={formikForm.values.data_type}
                    onChange={(event) => {
                      formikForm.setFieldValue('data_type', event.target.value);
                    }}
                    helperText={
                      formikForm?.errors?.data_type &&
                      formikForm?.touched?.data_type
                        ? formikForm.errors.data_type
                        : null
                    }
                    error={
                      Boolean(formikForm?.errors?.data_type) &&
                      formikForm?.touched?.data_type
                    }
                  >
                    <DropdownItem key={1} value="Character">
                      TEXT
                    </DropdownItem>
                    <DropdownItem key={1} value="Date">
                      DATE
                    </DropdownItem>
                    <DropdownItem key={2} value="Integer">
                      INTEGER
                    </DropdownItem>
                    <DropdownItem key={3} value="Decimal">
                      FLOAT
                    </DropdownItem>
                    {/* <DropdownItem key={4} value="Boolean">
                      BOOLEAN
                    </DropdownItem> */}
                  </DropDown>
                </Grid>
                <Grid xs={3}>
                  <TextField
                    name="deafult"
                    value={formikForm?.values?.deafult}
                    label="Enter default value"
                    {...formikForm.getFieldProps('deafult')}
                    placeholder="Enter default value ."
                  />
                </Grid>
              </Grid>
              <Grid
                container
                display="flex"
                justifyContent="center"
                item
                xs={12}
              >
                <Grid xs={3} mr={2}>
                  <TextField
                    name="attribute_order"
                    value={formikForm?.values?.attribute_order}
                    label="Enter attribute order"
                    onChange={(event) => {
                      formikForm.setFieldValue(
                        'attribute_order',
                        Number(event.target.value)
                      );
                    }}
                    placeholder="Enter Attribute Order."
                    helperText={
                      formikForm?.errors?.attribute_order &&
                      formikForm?.touched?.attribute_order
                        ? formikForm.errors.attribute_order
                        : null
                    }
                    error={
                      Boolean(formikForm?.errors?.attribute_order) &&
                      formikForm?.touched?.attribute_order
                    }
                  />
                </Grid>
                <Grid xs={3} mr={2}>
                  <DropDown
                    label="Input type"
                    value={formikForm.values.input_control_type}
                    onChange={(event) => {
                      formikForm.setFieldValue(
                        'input_control_type',
                        event.target.value
                      );
                    }}
                    helperText={
                      formikForm?.errors?.input_control_type &&
                      formikForm?.touched?.input_control_type
                        ? formikForm.errors.input_control_type
                        : null
                    }
                    error={
                      Boolean(formikForm?.errors?.input_control_type) &&
                      formikForm?.touched?.input_control_type
                    }
                  >
                    <DropdownItem key={3} value="SINGLE_SELECT">
                      SINGLE SELECT
                    </DropdownItem>
                    <DropdownItem key={4} value="MULTI_SELECT">
                      MULTI SELECT
                    </DropdownItem>
                    <DropdownItem key={4} value="TEXTFIELD">
                      TEXTFIELD
                    </DropdownItem>
                  </DropDown>
                </Grid>
                <Grid xs={3}>
                  <TextField
                    name="yup_schema"
                    value={formikForm?.values?.yup_schema}
                    {...formikForm.getFieldProps('yup_schema')}
                    placeholder="Enter valid Yup schema."
                    label="Yup schema"
                    error={Boolean(
                      formikForm.errors.yup_schema &&
                        formikForm.touched.yup_schema
                        ? formikForm.errors.yup_schema
                        : null
                    )}
                    helperText={
                      formikForm?.errors?.yup_schema &&
                      formikForm?.touched?.yup_schema
                        ? formikForm.errors.yup_schema
                        : null
                    }
                  />
                </Grid>
              </Grid>
              <Grid
                container
                display="flex"
                justifyContent="center"
                item
                xs={12}
              >
                <Grid xs={3} mr={2}>
                  <Typography
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                  >
                    is null value
                  </Typography>
                  <Stack
                    direction="row"
                    spacing={1}
                    justifyContent="center"
                    alignItems="center"
                  >
                    <Typography>No</Typography>
                    <Switch
                      name="is_null"
                      checked={formikForm.values.is_null === true}
                      {...formikForm.getFieldProps('is_null')}
                    />
                    <Typography>Yes</Typography>
                  </Stack>
                </Grid>
                <Grid xs={3}>
                  <>
                    <Typography
                      display="flex"
                      justifyContent="center"
                      alignItems="center"
                    >
                      is unique
                    </Typography>
                    <Stack
                      direction="row"
                      spacing={1}
                      justifyContent="center"
                      alignItems="center"
                    >
                      <Typography>No</Typography>
                      <Switch
                        name="is_unique"
                        checked={formikForm.values.is_unique === true}
                        {...formikForm.getFieldProps('is_unique')}
                      />
                      <Typography>Yes</Typography>
                    </Stack>
                  </>
                </Grid>
                <Grid xs={3}>
                  {['SINGLE_SELECT', 'MULTI_SELECT'].includes(
                    formikForm.values.input_control_type
                  ) ? (
                    <TextField
                      name="drop_down_options"
                      value={formikForm?.values?.default}
                      label="Enter options"
                      {...formikForm.getFieldProps('drop_down_options')}
                      placeholder="Enter comma separated choice option ."
                      helperText={
                        formikForm?.errors?.drop_down_options &&
                        formikForm?.touched?.drop_down_options
                          ? formikForm?.errors?.drop_down_options
                          : null
                      }
                      error={
                        Boolean(formikForm?.errors?.drop_down_options) &&
                        formikForm?.touched?.drop_down_options
                      }
                    />
                  ) : null}
                </Grid>
              </Grid>

              <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
                <Button
                  onClick={() => {
                    formikForm.handleReset();
                  }}
                >
                  RESET
                </Button>
                <Button onClick={formikForm.handleSubmit} variant="contained">
                  SUBMIT
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </Box>
  );
};
AddAttribute.propTypes = {
  open: PropTypes.bool.isRequired,
  selectedSectionName: PropTypes.string.isRequired,
  handleClose: PropTypes.func.isRequired,
  getCustomEntityTemp: PropTypes.func.isRequired,
  entityType: PropTypes.string.isRequired,
  addAttribute: PropTypes.func.isRequired,
};

export default AddAttribute;
