import React from 'react';
import { Box, Dialog, Grid, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import PropTypes from 'prop-types';

import CreateEntitySection from './CreateEntitySection';
import DialogTransition from '../Common/Transition/DialogTransition';

const CreateSectionModal = ({
  open,
  handleClose,
  entityType,
  createSection,
  getCustomEntityTemp,
}) => {
  return (
    <Box>
      <Dialog
        maxWidth="xs"
        open={open}
        onClose={handleClose}
        TransitionComponent={DialogTransition}
      >
        <Grid container>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
        </Grid>
        <Grid item xs={12} widht="400px">
          <CreateEntitySection
            entityType={entityType}
            handleClose={handleClose}
            createSection={createSection}
            getCustomEntityTemp={getCustomEntityTemp}
          />
        </Grid>
      </Dialog>
    </Box>
  );
};
CreateSectionModal.propTypes = {
  open: PropTypes.bool.isRequired,
  entityType: PropTypes.string.isRequired,
  handleClose: PropTypes.func.isRequired,
  createSection: PropTypes.func.isRequired,
  getCustomEntityTemp: PropTypes.func.isRequired,
};
export default CreateSectionModal;
