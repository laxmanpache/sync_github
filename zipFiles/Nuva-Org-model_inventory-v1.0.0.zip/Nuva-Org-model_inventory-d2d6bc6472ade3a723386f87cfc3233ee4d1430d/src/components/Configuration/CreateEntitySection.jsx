import React from 'react';
import { Box, Grid, Stack, Typography, TextField, Button } from '@mui/material';
import { useSearchParams } from 'react-router-dom';
import { useFormik } from 'formik';
import PropTypes from 'prop-types';
import * as Yup from 'yup';

import SwalToast from '../Common/SwalTost';

const CreateEntitySection = ({
  entityType,
  createSection,
  getCustomEntityTemp,
  handleClose = () => {},
}) => {
  const [searchParams] = useSearchParams();
  const formValidationSchema = Yup.object({
    entity_type: Yup.string().required('Required'),
    section_name: Yup.string().required('Required'),
    section_order: Yup.number().required('Required'),
  });
  const formikForm = useFormik({
    initialValues: {
      entity_type: entityType || '',
      section_name: '',
      section_order: '',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      createSection(values).then((res) => {
        if (res) {
          if (searchParams.get('eid')) {
            getCustomEntityTemp(searchParams.get('eid'));
          }
          SwalToast({
            icon: 'success',
            title: 'Section created successfully.',
          });
        }
      });
      handleClose();
      formikForm.handleReset();
    },
  });

  return (
    <Box width="400px">
      <Grid container spacing={2}>
        <Grid item xs={12} mb={2}>
          <Typography
            variant="h3"
            align="center"
            sx={{ wordBreak: 'break-all' }}
          >
            Add Section
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Box display="flex" alignItems="center" flexDirection="column">
            <Stack direction="column" spacing={3} width="250px">
              <Grid item xs={12}>
                <TextField
                  required
                  label="Entity type"
                  type="text"
                  value={formikForm.values.entity_type}
                  onChange={(event) => {
                    formikForm.setFieldValue('entity_type', event.target.value);
                  }}
                  disabled
                  name="entity_type"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  value={formikForm.values.section_name}
                  label="Section name"
                  onChange={(event) => {
                    formikForm.setFieldValue(
                      'section_name',
                      event.target.value
                    );
                  }}
                  type="text"
                  name="section_name"
                  helperText={
                    formikForm?.errors?.section_name &&
                    formikForm?.touched?.section_name
                      ? formikForm.errors.section_name
                      : null
                  }
                  error={
                    Boolean(formikForm?.errors?.section_name) &&
                    formikForm?.touched?.section_name
                  }
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  label="Section order"
                  onChange={(event) => {
                    formikForm.setFieldValue(
                      'section_order',
                      event.target.value
                    );
                  }}
                  type="number"
                  value={formikForm.values.section_order}
                  name="section_order"
                  helperText={
                    formikForm?.errors?.section_order &&
                    formikForm?.touched?.section_order
                      ? formikForm.errors.section_order
                      : null
                  }
                  error={
                    Boolean(formikForm?.errors?.section_order) &&
                    formikForm?.touched?.section_order
                  }
                />
              </Grid>
              <Grid item xs={12}>
                <Stack
                  direction="row"
                  spacing={2}
                  justifyContent="center"
                  mt={2}
                >
                  <Button
                    color="primary"
                    variant="text"
                    size="large"
                    onClick={() => {
                      formikForm.handleReset();
                    }}
                  >
                    RESET
                  </Button>
                  <Button
                    color="primary"
                    variant="contained"
                    onClick={() => formikForm.handleSubmit()}
                  >
                    SUBMIT
                  </Button>
                </Stack>
              </Grid>
            </Stack>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

CreateEntitySection.propTypes = {
  entityType: PropTypes.string.isRequired,
  createSection: PropTypes.func.isRequired,
  getCustomEntityTemp: PropTypes.func.isRequired,
  handleClose: PropTypes.func.isRequired,
};
export default CreateEntitySection;
