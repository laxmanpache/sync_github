/* eslint-disable no-unused-vars */
/* eslint-disable react/no-unescaped-entities */
import React, { useEffect, useState, useRef } from 'react';
import {
  Box,
  AppBar,
  Toolbar,
  Stack,
  Typography,
  IconButton,
  Paper,
  Popper,
  Grow,
  ClickAwayListener,
  MenuList,
  MenuItem,
  Badge,
  Button,
} from '@mui/material';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { FaSignOutAlt } from 'react-icons/fa';
import NotificationsIcon from '@mui/icons-material/Notifications';
import { ReactComponent as NimbusLogo } from '../../assets/Icons/NIMBUSVaultWhite.svg';
import Notifications from './Notifications';

const AppHeader = ({
  getNotification,
  notificationList,
  clearAllNotification,
}) => {
  const logOut = () => {
    localStorage.clear();
    sessionStorage.clear();
    window.location.reload();
  };
  useEffect(() => {
    getNotification();
  }, []);

  const { profileData } = useSelector((state) => state.users);
  const [open, setOpen] = useState(false);
  const anchorRef = useRef();

  /**
   * @function handleToggle
   * @description Reversing state of prevOpen
   * @returns {void}
   * @example handleToggle()
   */
  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen);
  };

  /**
   * @function handleListKeyDown
   * @description Once the required condition is fulfilled it prevents the default action and -
   * - change the state to false
   * @param {object} event - event object
   * @returns {void}
   * @example handleListKeyDown event={event}
   */
  function handleListKeyDown(event) {
    if (event.key === 'Tab') {
      event.preventDefault();
      setOpen(false);
    }
  }
  /**
   * @function handleCloseUser
   * @description Handling the close user
   * @param {object} event - event object
   * @returns {void}
   * @example handleCloseUser(event)
   */
  const handleCloseUser = () => {
    setOpen(false);
    getNotification();
  };
  return (
    <Box>
      <AppBar elevation={0} position="static">
        <Toolbar
          sx={{
            padding: '0px 10px 0px 12px !important',
          }}
        >
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              width: '100%',
            }}
          >
            <Box>
              <NimbusLogo height="3rem" width="7.1rem" />
            </Box>
            <Stack spacing={2} direction="row" mt={1}>
              <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                <Typography variant="body2" color="light">
                  {profileData?.first_name}
                </Typography>
                <Typography variant="body3" color="light">
                  {profileData?.role}
                </Typography>
              </Box>
              <Badge
                badgeContent={
                  notificationList?.filter(
                    (notification) => !notification?.read_status
                  )?.length
                }
                sx={(theme) => ({
                  '& .MuiBadge-badge': {
                    color: theme.palette.other.white,
                    backgroundColor: theme.palette.other.badgeBorder,
                    marginRight: '10px',
                    marginTop: '10px',
                  },
                })}
              >
                <IconButton
                  onClick={handleToggle}
                  color="inherit"
                  title="Notifications"
                  ref={anchorRef}
                >
                  <NotificationsIcon />
                </IconButton>
              </Badge>
              <Popper
                open={open}
                anchorEl={anchorRef.current}
                role={undefined}
                transition
                disablePortal
                sx={{ zIndex: 10 }}
              >
                {({ TransitionProps, placement }) => (
                  <Grow
                    {...TransitionProps}
                    style={{
                      transformOrigin:
                        placement === 'bottom' ? 'center top' : 'center bottom',
                      marginTop: '8px',
                      marginRight: '24px',
                    }}
                  >
                    <Paper
                      backgroundColor="primary"
                      sx={{ height: '90vh', width: '30vw', overflow: 'hidden' }}
                    >
                      <ClickAwayListener onClickAway={() => setOpen(false)}>
                        <Box p={2}>
                          <Notifications notificationList={notificationList} />
                        </Box>
                      </ClickAwayListener>
                    </Paper>
                  </Grow>
                )}
              </Popper>

              <IconButton title="Logout" onClick={logOut} color="inherit">
                <FaSignOutAlt color="light" />
              </IconButton>
            </Stack>
          </Box>
        </Toolbar>
      </AppBar>
    </Box>
  );
};
AppHeader.propTypes = {
  getNotification: PropTypes.func.isRequired,
  clearAllNotification: PropTypes.func.isRequired,
  notificationList: PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.object]))
    .isRequired,
};

export default AppHeader;
