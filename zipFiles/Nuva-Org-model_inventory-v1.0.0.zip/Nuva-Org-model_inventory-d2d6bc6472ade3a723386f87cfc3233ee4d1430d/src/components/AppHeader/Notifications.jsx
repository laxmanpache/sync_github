/* eslint-disable no-nested-ternary */
/* eslint-disable react/no-array-index-key */
import React, { useState } from 'react';
import moment from 'moment';
import {
  Box,
  Grid,
  Tab,
  Tabs,
  Typography,
  Avatar,
  Stack,
  Radio,
} from '@mui/material';
import propTypes from 'prop-types';
import { styled } from '@mui/material/styles';
import { TabPanel } from '../Common/Tabs';

const MuiTabs = styled(Tabs)(({ theme }) => ({
  minHeight: '30px',
  borderColor: theme.palette.primary.main,
}));
const MuiTab = styled(Tab)(({ theme }) => ({
  minHeight: '25px',
  minWidth: 0,
  padding: 0,
  paddingRight: '10px',
  marginBottom: '5px',
  display: 'flex',
  justifyContent: 'flex-start',
  '&.Mui-selected': {
    borderRadius: '3px',
    color: `${theme.palette.primary.main} !important`,
  },
}));

const Notifications = ({ notificationList }) => {
  const [tabValue, setTabValue] = useState(0);

  const handleChange = (event, newValue) => {
    setTabValue(newValue);
  };
  const handleMarkAsReadUnread = (value) => {
    console.log(value);
  };
  return (
    <Box>
      <Grid container item xs={12} rowSpacing={2}>
        <Grid item xs={12}>
          <Typography variant="h4">Notifications</Typography>
        </Grid>
        <Grid item xs={12}>
          <MuiTabs value={tabValue} onChange={handleChange}>
            <MuiTab title="Direct" label="Direct" />
            <MuiTab title="Watching" label="Watching" />
          </MuiTabs>
          <Box sx={{ height: 'calc(90vh - 65px)', overflowY: 'scroll' }}>
            <TabPanel value={tabValue} index={0}>
              {notificationList?.length > 0 ? (
                <Stack m={1} direction="column" spacing={3}>
                  <Box
                    sx={{ display: 'flex', justifyContent: 'space-between' }}
                  >
                    {notificationList?.length > 0 ? (
                      notificationList?.filter(
                        (notification) =>
                          moment(notification?.created_at).format(
                            'YYYY / MM / DD'
                          ) === moment(new Date()).format('YYYY / MM / DD')
                      )?.length > 0 ? (
                        <Typography>TODAY</Typography>
                      ) : (
                        <Typography>LATEST</Typography>
                      )
                    ) : null}
                    {notificationList?.filter(
                      (notification) => !notification?.read_status
                    )?.length > 0 ? (
                      <Typography
                        variant="body4"
                        sx={{
                          '&:hover': {
                            cursor: 'pointer',
                          },
                        }}
                      >
                        Mark all as read
                      </Typography>
                    ) : null}
                  </Box>

                  {notificationList
                    ?.filter(
                      (notification) =>
                        moment(notification?.created_at).format(
                          'YYYY / MM / DD'
                        ) === moment(new Date()).format('YYYY / MM / DD')
                    )
                    .map((notification, i) => {
                      return (
                        <Box
                          key={i}
                          sx={{
                            '& :hover': {
                              background: (theme) =>
                                theme.palette.secondary.light,
                              cursor: 'pointer',
                              borderRadius: '4px',
                            },
                            padding: '1px',
                          }}
                        >
                          <Stack
                            direction="row"
                            padding={1}
                            spacing={2}
                            width="100%"
                          >
                            <Box
                              sx={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                              }}
                            >
                              <Avatar
                                sx={{
                                  width: 24,
                                  height: 24,
                                  background: (theme) =>
                                    theme.palette.primary.main,
                                }}
                              >
                                L
                              </Avatar>
                            </Box>
                            <Box
                              sx={{
                                flex: 1,
                              }}
                            >
                              <Box
                                sx={{
                                  wordBreak: 'break-all',
                                  overflow: 'hidden',
                                }}
                              >
                                {notification?.msg}
                              </Box>
                              <Typography>
                                {moment(notification.created_at).fromNow()}
                              </Typography>
                            </Box>
                            <Box>
                              <Radio
                                checked={!notification?.read_status}
                                title={
                                  !notification?.read_status
                                    ? 'Mark as unread'
                                    : 'Mark as read'
                                }
                                onChange={() => {
                                  handleMarkAsReadUnread(notification);
                                }}
                              />
                            </Box>
                          </Stack>
                        </Box>
                      );
                    })}
                  {notificationList?.filter(
                    (notification) =>
                      moment(notification?.created_at).format(
                        'YYYY / MM / DD'
                      ) === moment(new Date()).format('YYYY / MM / DD')
                  )?.length > 0 ? (
                    <Typography>OLDER</Typography>
                  ) : null}
                  {notificationList
                    ?.filter(
                      (notification) =>
                        moment(notification?.created_at).format(
                          'YYYY / MM / DD'
                        ) !== moment(new Date()).format('YYYY / MM / DD')
                    )
                    ?.map((notification, i) => {
                      return (
                        <Box
                          key={i}
                          sx={{
                            '& :hover': {
                              background: (theme) =>
                                theme.palette.secondary.light,
                              cursor: 'pointer',
                              borderRadius: '4px',
                            },
                            padding: '1px',
                          }}
                        >
                          <Stack
                            direction="row"
                            padding={1}
                            spacing={2}
                            width="100%"
                          >
                            <Box
                              sx={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                              }}
                            >
                              <Avatar
                                sx={{
                                  width: 24,
                                  height: 24,
                                  background: (theme) =>
                                    theme.palette.primary.main,
                                }}
                              >
                                L
                              </Avatar>
                            </Box>
                            <Box
                              sx={{
                                flex: 1,
                              }}
                            >
                              <Box
                                sx={{
                                  wordBreak: 'break-all',
                                  overflow: 'hidden',
                                }}
                              >
                                {notification?.msg}
                              </Box>
                              <Typography>
                                {moment(notification.created_at).fromNow()}
                              </Typography>
                            </Box>
                            <Box>
                              <Radio
                                checked={!notification?.read_status}
                                title={
                                  !notification?.read_status
                                    ? 'Mark as unread'
                                    : 'Mark as read'
                                }
                                onChange={() => {
                                  handleMarkAsReadUnread(notification);
                                }}
                              />
                            </Box>
                          </Stack>
                        </Box>
                      );
                    })}
                </Stack>
              ) : (
                <Box
                  display="flex"
                  style={{ height: 'calc(99vh  - 200px)' }}
                  flexGrow={1}
                  alignItems="center"
                  flexDirection="column"
                  justifyContent="center"
                >
                  <Typography variant="subtitle1">
                    No notification unread notifications.
                  </Typography>
                </Box>
              )}
            </TabPanel>
            <TabPanel value={tabValue} index={1}>
              {notificationList?.length > 0 ? (
                <Stack m={1} direction="column" spacing={3}>
                  <Box
                    sx={{ display: 'flex', justifyContent: 'space-between' }}
                  >
                    {notificationList?.length > 0 ? (
                      notificationList?.filter(
                        (notification) =>
                          moment(notification?.created_at).format(
                            'YYYY / MM / DD'
                          ) === moment(new Date()).format('YYYY / MM / DD')
                      )?.length > 0 ? (
                        <Typography>TODAY</Typography>
                      ) : (
                        <Typography>LATEST</Typography>
                      )
                    ) : null}
                    {notificationList?.filter(
                      (notification) => !notification?.read_status
                    )?.length > 0 ? (
                      <Typography
                        variant="body4"
                        sx={{
                          '&:hover': {
                            cursor: 'pointer',
                          },
                        }}
                      >
                        Mark all as read
                      </Typography>
                    ) : null}
                  </Box>
                  {notificationList
                    ?.filter(
                      (notification) =>
                        moment(notification?.created_at).format(
                          'YYYY / MM / DD'
                        ) === moment(new Date()).format('YYYY / MM / DD')
                    )
                    .map((notification, i) => {
                      return (
                        <Box
                          key={i}
                          sx={{
                            '& :hover': {
                              background: (theme) =>
                                theme.palette.secondary.light,
                              cursor: 'pointer',
                              borderRadius: '4px',
                            },
                            padding: '1px',
                          }}
                        >
                          <Stack
                            direction="row"
                            padding={1}
                            spacing={2}
                            width="100%"
                          >
                            <Box
                              sx={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                              }}
                            >
                              <Avatar
                                sx={{
                                  width: 24,
                                  height: 24,
                                  background: (theme) =>
                                    theme.palette.primary.main,
                                }}
                              >
                                L
                              </Avatar>
                            </Box>
                            <Box
                              sx={{
                                flex: 1,
                              }}
                            >
                              <Box
                                sx={{
                                  wordBreak: 'break-all',
                                  overflow: 'hidden',
                                }}
                              >
                                {notification?.msg}
                              </Box>
                              <Typography>
                                {moment(notification.created_at).fromNow()}
                              </Typography>
                            </Box>
                            <Box>
                              <Radio
                                checked={!notification?.read_status}
                                title={
                                  !notification?.read_status
                                    ? 'Mark as unread'
                                    : 'Mark as read'
                                }
                                onChange={() => {
                                  handleMarkAsReadUnread(notification);
                                }}
                              />
                            </Box>
                          </Stack>
                        </Box>
                      );
                    })}
                  {notificationList?.filter(
                    (notification) =>
                      moment(notification?.created_at).format(
                        'YYYY / MM / DD'
                      ) === moment(new Date()).format('YYYY / MM / DD')
                  )?.length > 0 ? (
                    <Typography>OLDER</Typography>
                  ) : null}
                  {notificationList
                    ?.filter(
                      (notification) =>
                        moment(notification?.created_at).format(
                          'YYYY / MM / DD'
                        ) !== moment(new Date()).format('YYYY / MM / DD')
                    )
                    ?.map((notification, i) => {
                      return (
                        <Box
                          key={i}
                          sx={{
                            '& :hover': {
                              background: (theme) =>
                                theme.palette.secondary.light,
                              cursor: 'pointer',
                              borderRadius: '4px',
                            },
                            padding: '1px',
                          }}
                        >
                          <Stack
                            direction="row"
                            padding={1}
                            spacing={2}
                            width="100%"
                          >
                            <Box
                              sx={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                              }}
                            >
                              <Avatar
                                sx={{
                                  width: 24,
                                  height: 24,
                                  background: (theme) =>
                                    theme.palette.primary.main,
                                }}
                              >
                                L
                              </Avatar>
                            </Box>
                            <Box
                              sx={{
                                flex: 1,
                              }}
                            >
                              <Box
                                sx={{
                                  wordBreak: 'break-all',
                                  overflow: 'hidden',
                                }}
                              >
                                {notification?.msg}
                              </Box>
                              <Typography>
                                {moment(notification.created_at).fromNow()}
                              </Typography>
                            </Box>
                            <Box>
                              <Radio
                                checked={!notification?.read_status}
                                title={
                                  !notification?.read_status
                                    ? 'Mark as unread'
                                    : 'Mark as read'
                                }
                                onChange={() => {
                                  handleMarkAsReadUnread(notification);
                                }}
                              />
                            </Box>
                          </Stack>
                        </Box>
                      );
                    })}
                </Stack>
              ) : (
                <Box
                  display="flex"
                  style={{ height: 'calc(99vh  - 200px)' }}
                  flexGrow={1}
                  alignItems="center"
                  flexDirection="column"
                  justifyContent="center"
                >
                  <Typography variant="subtitle1">
                    No notification unread notifications.
                  </Typography>
                </Box>
              )}
            </TabPanel>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

Notifications.propTypes = {
  notificationList: propTypes.arrayOf(propTypes.oneOfType([propTypes.object]))
    .isRequired,
};
export default Notifications;
