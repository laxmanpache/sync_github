import React from 'react';
import { Box, Toolbar, AppBar } from '@mui/material';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
import DropdownMenu from '../Common/DropdownMenu';

const TopNavBar = ({ SidebarConfig }) => {
  const navigate = useNavigate();

  return (
    <AppBar position="static">
      <Toolbar
        variant="dense"
        disableGutters={true}
        sx={{
          borderBottom: '1px solid',
          background: 'white',
          width: '100%',
          overflow: 'auto',
        }}
      >
        {SidebarConfig?.map((item) => {
          return (
            <Box key={item?.name} mx={2}>
              <DropdownMenu
                menuItem={item}
                onItemClick={(_item) => {
                  if (!_item?.children?.length) {
                    navigate(_item.route);
                  }
                }}
              />
            </Box>
          );
        })}
      </Toolbar>
    </AppBar>
  );
};
TopNavBar.propTypes = {
  SidebarConfig: PropTypes.oneOfType([PropTypes.object]).isRequired,
};

export default TopNavBar;
