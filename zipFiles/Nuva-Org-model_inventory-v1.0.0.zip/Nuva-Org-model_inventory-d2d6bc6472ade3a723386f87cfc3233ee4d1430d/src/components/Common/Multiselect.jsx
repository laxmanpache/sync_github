/* eslint-disable react/prop-types */
import { Autocomplete } from '@mui/material';
import React from 'react';

const Multiselect = ({ options, ...props }) => {
  const SELECT_ALL_OPTIONS = {
    label: 'Select all options',
    value: 'mui_select_all',
  };
  return (
    <Autocomplete
      {...props}
      fullWidth
      options={[SELECT_ALL_OPTIONS, ...options]}
      limitTags={1}
      onChange={(e, value) => {
        if (value.includes(SELECT_ALL_OPTIONS)) {
          return props.onChange(options);
        }
        return props.onChange(value);
      }}
      multiple
    />
  );
};

export default Multiselect;
