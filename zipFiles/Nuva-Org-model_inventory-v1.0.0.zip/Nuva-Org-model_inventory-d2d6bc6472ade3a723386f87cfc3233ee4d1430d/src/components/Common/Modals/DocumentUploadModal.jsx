import {
  Box,
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  Typography,
} from '@mui/material';
import React from 'react';
import PropTypes from 'prop-types';
import CloseIcon from '@mui/icons-material/Close';
import DocumentUploadForm from '../Forms/DocumentUploadForm';

function DocumentUploadModal({
  open,
  handleClose,
  isMultiple,
  enitityType,
  entityId,
  attachDocument = () => {},
}) {
  return (
    <Dialog
      disableBackdropClick
      onClose={() => handleClose(false)}
      open={open}
      maxWidth="md"
      fullWidth={true}
      aria-labelledby="doc-attach-modal"
    >
      <DialogTitle
        id="doc-attach-modal"
        style={{
          paddingTop: 0,
          paddingBottom: 0,
          paddingRight: 0,
        }}
        onClose={() => handleClose(false)}
      >
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Typography color="primary">Attach Document</Typography>
          <IconButton
            aria-label="close"
            onClick={() => {
              handleClose(false);
            }}
          >
            <CloseIcon />
          </IconButton>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        <DocumentUploadForm
          handleClose={handleClose}
          isMultiple={isMultiple}
          enitityType={enitityType}
          entityId={entityId}
          attachDocument={attachDocument}
        />
      </DialogContent>
    </Dialog>
  );
}
DocumentUploadModal.propTypes = {
  open: PropTypes.bool.isRequired,
  isMultiple: PropTypes.bool.isRequired,
  handleClose: PropTypes.func.isRequired,
  enitityType: PropTypes.string.isRequired,
  entityId: PropTypes.number.isRequired,
  attachDocument: PropTypes.func.isRequired,
};
export default DocumentUploadModal;
