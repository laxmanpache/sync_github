import { Box, Dialog, IconButton, Grid, Typography } from '@mui/material';
import React from 'react';
import PropTypes from 'prop-types';
import CloseIcon from '@mui/icons-material/Close';
import CreateEditRuleForm from '../Forms/CreateEditRuleForm';
import DialogTransition from '../Transition/DialogTransition';

function CreateEditRuleModal({
  open,
  handleClose,
  createRule = () => {},
  updateRule = () => {},
  associationTypeList = [],
  rule = null,
  fetchAllStates = () => {},
  getCustomEntityTemplate = () => {},
}) {
  return (
    <Dialog
      disableBackdropClick
      onClose={() => handleClose(false)}
      open={open}
      maxWidth="xs"
      fullWidth={true}
      aria-labelledby="doc-attach-modal"
      sx={{
        '& .MuiPaper-root': {
          'padding-bottom': '24px',
        },
      }}
      TransitionComponent={DialogTransition}
    >
      <Grid container>
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
            <IconButton
              onClick={() => {
                handleClose();
              }}
            >
              <CloseIcon />
            </IconButton>
          </Box>
        </Grid>
        <Grid item xs={12}>
          <Box display="flex" justifyContent="space-around" alignItems="center">
            <Typography variant="h3">
              {rule ? 'Edit' : 'Create a new'} Rule
            </Typography>
          </Box>
        </Grid>
      </Grid>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          marginTop: '24px',
        }}
      >
        <CreateEditRuleForm
          rule={rule}
          handleClose={handleClose}
          createRule={createRule}
          updateRule={updateRule}
          associationTypeList={associationTypeList}
          fetchAllStates={fetchAllStates}
          getCustomEntityTemplate={getCustomEntityTemplate}
        />
      </Box>
    </Dialog>
  );
}
CreateEditRuleModal.propTypes = {
  associationTypeList: PropTypes.oneOfType([PropTypes.array]).isRequired,
  createRule: PropTypes.func.isRequired,
  fetchAllStates: PropTypes.func.isRequired,
  getCustomEntityTemplate: PropTypes.func.isRequired,
  handleClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  rule: PropTypes.oneOfType([PropTypes.object]).isRequired,
  updateRule: PropTypes.func.isRequired,
};
export default CreateEditRuleModal;
