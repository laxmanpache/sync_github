import React from 'react';
import {
  Box,
  Dialog,
  Grid,
  IconButton,
  Typography,
  Button,
  Stack,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import PropTypes from 'prop-types';
import DialogTransition from '../Transition/DialogTransition';

const DeleteModal = ({
  open = false,
  handleClose = () => {},
  deleteConfirm = () => {},
  alertLabelText = '',
}) => {
  return (
    <Box>
      <Dialog
        maxWidth="xs"
        open={open}
        onClose={handleClose}
        sx={{
          '& .MuiPaper-root': {
            'padding-bottom': '24px',
          },
        }}
        TransitionComponent={DialogTransition}
      >
        <Grid container>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <IconButton
                onClick={() => {
                  handleClose();
                }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </Grid>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="center"
            alignItems="center"
            mb={3}
          >
            <Box
              display="flex"
              justifyContent="center"
              alignItems="center"
              mt={1}
            >
              <Typography variant="h4" align="center">
                {alertLabelText}
              </Typography>
            </Box>
          </Grid>
          <Grid
            item
            xs={12}
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
              <Button variant="contained" onClick={deleteConfirm}>
                Delete
              </Button>
              <Button
                onClick={() => {
                  handleClose();
                }}
              >
                Cancel
              </Button>
            </Stack>
          </Grid>
        </Grid>
      </Dialog>
    </Box>
  );
};

DeleteModal.propTypes = {
  open: PropTypes.bool.isRequired,
  handleClose: PropTypes.func.isRequired,
  deleteConfirm: PropTypes.func.isRequired,
  alertLabelText: PropTypes.string.isRequired,
};

export default DeleteModal;
