import PropTypes from 'prop-types';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import React, { useEffect, useMemo, useState } from 'react';
import { Button, Grid, Stack, TextField } from '@mui/material';
import { DropDown, DropdownItem } from '../DropDown';

const RULE_TYPES = [
  {
    label: 'Attribute Rule',
    value: 'AttributeRule',
  },
  {
    label: 'Association Rule',
    value: 'AssociationRule',
  },
];

const ENTITY_TYPES = [
  {
    label: 'Model Inventory',
    value: 'ModelInventory',
  },
  {
    label: 'Model Association',
    value: 'ModelAssociation',
  },
];

const ATTRIBUTE_OPERATORS = {
  Integer: [
    { label: 'equal', value: 'equal' },
    { label: 'greater than equal', value: 'gte' },
    { label: 'less than equal', value: 'lte' },
  ],
  Character: [
    { label: 'equal', value: 'equal' },
    { label: 'contains', value: 'contains' },
  ],
  Text: [
    { label: 'equal', value: 'equal' },
    { label: 'contains', value: 'contains' },
  ],
  Bool: [{ label: 'equal', value: 'equal' }],
};

const CreateEditRuleForm = ({
  rule = null,
  handleClose = () => {},
  createRule = () => {},
  updateRule = () => {},
  associationTypeList = [],
  fetchAllStates = () => {},
  getCustomEntityTemplate = () => {},
}) => {
  const [states, setStates] = useState([]);
  const [selectedEntityType, setSelectedEntityType] = useState(null);
  const [customEntityDetails, setCustomEntityDetails] = useState(null);
  const [selectedSection, setSelectedSection] = useState(null);

  const mode = useMemo(() => (rule ? 'edit' : 'create'), [rule]);

  const formValidationSchema = Yup.object({
    label: Yup.string().required('Required'),
    type: Yup.string().required('Required'),
    detail: Yup.object().when('type', ([type]) => {
      if (type === 'AttributeRule') {
        return Yup.object().shape({
          entity_type: Yup.string().required('Required'),
          association_type: Yup.string().required('Required'),
          section_name: Yup.string().required('Required'),
          attribute_name: Yup.string().required('Required'),
          attribute_type: Yup.string().required('Required'),
          attribute_operator: Yup.string().required('Required'),
          attribute_value: Yup.string().required('Required'),
        });
      }
      return Yup.object().shape({
        association_type: Yup.string().required('Required'),
        entity_type: Yup.string().required(' Required'),
        status: Yup.string().required('Required'),
      });
    }),
  });

  const formik = useFormik({
    initialValues: {
      label: '',
      type: '',
      detail: {
        attribute_name: '',
        attribute_type: '',
        section_name: '',
        attribute_operator: '',
        attribute_value: '',
        entity_type: '',
        association_type: '',
        status: '',
      },
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      if (rule) {
        updateRule(values).then(() => {
          handleClose();
        });
      } else {
        createRule(values).then(() => {
          handleClose();
        });
      }
    },
  });

  useEffect(() => {
    const workflow = selectedEntityType?.workflow;
    if (selectedEntityType) {
      if (formik.values.type === 'AssociationRule') {
        fetchAllStates(workflow).then((res) => {
          if (res && workflow === selectedEntityType?.workflow) {
            setStates(res?.data?.States ?? []);
          }
        });
      } else {
        getCustomEntityTemplate({
          entityName: selectedEntityType?.entity_name,
        }).then((res) => {
          if (res && workflow === selectedEntityType?.workflow) {
            setCustomEntityDetails(
              res?.data?.Entity[selectedEntityType?.entity_name] ?? null
            );
            if (rule) {
              setSelectedSection(
                res?.data?.Entity[
                  selectedEntityType?.entity_name
                ]?.sections?.find(
                  (section) =>
                    section.section_name === rule?.detail?.section_name
                )
              );
            }
          }
        });
      }
    }
  }, [selectedEntityType]);

  useEffect(() => {
    if (rule) {
      formik.setValues(rule);
      if (rule?.detail?.association_type) {
        associationTypeList?.forEach((item) => {
          if (item?.entity_name === rule?.detail?.association_type) {
            setSelectedEntityType(item);
          }
        });
      }
    }
  }, [rule]);

  const handleResetForm = () => {
    formik.handleReset();
    setStates([]);
    setSelectedEntityType(null);
    setCustomEntityDetails(null);
    setSelectedSection(null);
  };

  return (
    <Grid container xs={12} spacing={2} justifyContent="center" p={2}>
      <Grid item xs={6}>
        <TextField
          {...formik.getFieldProps('label')}
          label="Name"
          variant="outlined"
          placeholder="Enter Label"
          name="label"
          helperText={
            formik.touched.label && formik.errors.label
              ? formik.errors.label
              : null
          }
          error={formik.touched.label && Boolean(formik.errors.label)}
        />
      </Grid>
      <Grid item xs={6}>
        <DropDown
          label="Rule type"
          placeholder="Select Type"
          name="type"
          value={formik.values.type}
          onChange={(e) => {
            formik.setFieldValue('type', e.target.value);
            formik.setFieldValue('detail', {
              attribute_name: '',
              attribute_type: '',
              section_name: '',
              attribute_operator: '',
              attribute_value: '',
              entity_type: '',
              association_type: '',
              status: '',
            });
          }}
          helperText={
            formik.touched.type && formik.errors.type
              ? formik.errors.type
              : null
          }
          error={formik.touched.type && Boolean(formik.errors.type)}
        >
          {RULE_TYPES.map((item) => (
            <DropdownItem key={item.value} value={item.value}>
              {item.label}
            </DropdownItem>
          ))}
        </DropDown>
      </Grid>
      <Grid item xs={6}>
        <DropDown
          label="Entity Type"
          placeholder="Select Type"
          name="detail.entity_type"
          value={formik.values.detail.entity_type}
          onChange={(e) => {
            formik.setFieldValue('detail.entity_type', e.target.value);
          }}
          helperText={
            formik.touched.detail?.entity_type &&
            formik.errors.detail?.entity_type
              ? formik.errors.detail?.entity_type
              : null
          }
          error={
            formik.touched.detail?.entity_type &&
            Boolean(formik.errors.detail?.entity_type)
          }
        >
          {ENTITY_TYPES.map((item) => (
            <DropdownItem key={item.value} value={item.value}>
              {item.label}
            </DropdownItem>
          ))}
        </DropDown>
      </Grid>
      <Grid item xs={6}>
        <DropDown
          label="Association Type"
          placeholder="Select Type"
          value={formik.values.detail.association_type}
          onChange={(e) => {
            formik.setFieldValue('detail.association_type', e.target.value);
            formik.setFieldValue('detail.status', '');
            formik.setFieldValue('detail.attribute_name', '');
            formik.setFieldValue('detail.attribute_type', '');
            formik.setFieldValue('detail.section_name', '');
            formik.setFieldValue('detail.attribute_operator', '');
            formik.setFieldValue('detail.attribute_value', '');
          }}
          name="detail.association_type"
          helperText={
            formik.touched.detail?.association_type &&
            formik.errors.detail?.association_type
              ? formik.errors.detail?.association_type
              : null
          }
          error={
            formik.touched.detail?.association_type &&
            Boolean(formik.errors.detail?.association_type)
          }
        >
          {associationTypeList
            ?.filter((entity) => {
              return entity.entity_type === formik.values.detail.entity_type;
            })
            .map((item) => (
              <DropdownItem
                key={item.entity_name}
                value={item.entity_name}
                onClick={() => {
                  setSelectedEntityType(item);
                }}
              >
                {item.entity_name}
              </DropdownItem>
            ))}
          {associationTypeList?.filter((entity) => {
            return entity.entity_type === formik.values.detail.entity_type;
          }).length === 0 && (
            <DropdownItem value="" disabled>
              No options
            </DropdownItem>
          )}
        </DropDown>
      </Grid>

      {formik.values.type === 'AttributeRule' ? (
        <Grid container item xs={12} spacing={2}>
          <Grid item xs={Array.isArray(selectedSection?.attributes) ? 6 : 12}>
            <DropDown
              label="Section"
              placeholder="Select Section"
              value={formik.values.detail.section_name}
              onChange={(e) => {
                formik.setFieldValue('detail.section_name', e.target.value);
                formik.setFieldValue('detail.attribute_name', '');
                formik.setFieldValue('detail.attribute_type', '');
                formik.setFieldValue('detail.attribute_operator', '');
                formik.setFieldValue('detail.attribute_value', '');
              }}
              name="detail.section_name"
              helperText={
                formik.touched.detail?.section_name &&
                formik.errors.detail?.section_name
                  ? formik.errors.detail?.section_name
                  : null
              }
              error={
                formik.touched.detail?.section_name &&
                Boolean(formik.errors.detail?.section_name)
              }
            >
              {customEntityDetails?.sections?.length > 0 ? (
                customEntityDetails?.sections?.map((item) => (
                  <DropdownItem
                    key={item.section_name}
                    value={item.section_name}
                    onClick={() => {
                      setSelectedSection(item);
                    }}
                  >
                    {item.section_name}
                  </DropdownItem>
                ))
              ) : (
                <DropdownItem value="" disabled>
                  No options
                </DropdownItem>
              )}
            </DropDown>
          </Grid>
          {Array.isArray(selectedSection?.attributes) ? (
            <>
              <Grid item xs={6}>
                <DropDown
                  name="detail.attribute_name"
                  label="Attribute Name"
                  placeholder="Select Attribute"
                  value={formik.values.detail.attribute_name}
                  onChange={(e) => {
                    formik.setFieldValue(
                      'detail.attribute_name',
                      e.target.value
                    );
                    formik.setFieldValue('detail.attribute_operator', '');
                    formik.setFieldValue('detail.attribute_value', '');
                  }}
                  helperText={
                    formik.touched.detail?.attribute_name &&
                    formik.errors.detail?.attribute_name
                      ? formik.errors.detail?.attribute_name
                      : null
                  }
                  error={
                    formik.touched.detail?.attribute_name &&
                    Boolean(formik.errors.detail?.attribute_name)
                  }
                >
                  {selectedSection?.attributes?.length > 0 ? (
                    selectedSection?.attributes?.map((item) => (
                      <DropdownItem
                        key={item.name}
                        value={item.name}
                        onClick={() => {
                          formik.setFieldValue(
                            'detail.attribute_type',
                            item.data_type
                          );
                        }}
                      >
                        {item.label}
                      </DropdownItem>
                    ))
                  ) : (
                    <DropdownItem value="" disabled>
                      No options
                    </DropdownItem>
                  )}
                </DropDown>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  {...formik.getFieldProps('detail.attribute_type')}
                  label="Attribute Type"
                  disabled
                  name="detail.attribute_type"
                  helperText={
                    formik.touched.detail?.attribute_type &&
                    formik.errors.detail?.attribute_type
                      ? formik.errors.detail?.attribute_type
                      : null
                  }
                  error={
                    formik.touched.detail?.attribute_type &&
                    Boolean(formik.errors.detail?.attribute_type)
                  }
                />
              </Grid>
              <Grid item xs={6}>
                <DropDown
                  label="Attribute Operator"
                  placeholder="Select Operator"
                  name="detail.attribute_operator"
                  value={formik.values.detail.attribute_operator}
                  onChange={(e) => {
                    formik.setFieldValue(
                      'detail.attribute_operator',
                      e.target.value
                    );
                  }}
                  helperText={
                    formik.touched.detail?.attribute_operator &&
                    formik.errors.detail?.attribute_operator
                      ? formik.errors.detail?.attribute_operator
                      : null
                  }
                  error={
                    formik.touched.detail?.attribute_operator &&
                    Boolean(formik.errors.detail?.attribute_operator)
                  }
                >
                  {ATTRIBUTE_OPERATORS[
                    formik.values.detail.attribute_type
                  ]?.map((operator) => (
                    <DropdownItem key={operator.value} value={operator.value}>
                      {operator.label}
                    </DropdownItem>
                  ))}
                </DropDown>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  {...formik.getFieldProps('detail.attribute_value')}
                  label="Attribute Value"
                  placeholder="Enter Attribute Value"
                  helperText={
                    formik.touched.detail?.attribute_value &&
                    formik.errors.detail?.attribute_value
                      ? formik.errors.detail?.attribute_value
                      : null
                  }
                  error={
                    formik.touched.detail?.attribute_value &&
                    Boolean(formik.errors.detail?.attribute_value)
                  }
                />
              </Grid>
            </>
          ) : null}
        </Grid>
      ) : null}

      {formik.values.type === 'AssociationRule' ? (
        <Grid item xs={12}>
          <DropDown
            label="Status"
            placeholder="Select Status"
            name="detail.status"
            value={formik.values.detail.status}
            onChange={(e) => {
              formik.setFieldValue('detail.status', e.target.value);
            }}
            helperText={
              formik.touched.detail?.status && formik.errors.detail?.status
                ? formik.errors.detail?.status
                : null
            }
            error={
              formik.touched.detail?.status &&
              Boolean(formik.errors.detail?.status)
            }
          >
            {states?.map((item) => (
              <DropdownItem key={item} value={item}>
                {item}
              </DropdownItem>
            ))}
          </DropDown>
        </Grid>
      ) : null}

      <Grid item xs={12}>
        <Stack direction="row" gap="16px" justifyContent="center">
          <Button onClick={() => handleResetForm()}>Reset</Button>
          <Button onClick={formik.handleSubmit} variant="contained">
            {mode === 'create' ? 'Submit' : 'Update'}
          </Button>
        </Stack>
      </Grid>
    </Grid>
  );
};

CreateEditRuleForm.propTypes = {
  associationTypeList: PropTypes.oneOfType([PropTypes.array]).isRequired,
  createRule: PropTypes.func.isRequired,
  fetchAllStates: PropTypes.func.isRequired,
  getCustomEntityTemplate: PropTypes.func.isRequired,
  handleClose: PropTypes.func.isRequired,
  rule: PropTypes.oneOfType([PropTypes.object]).isRequired,
  updateRule: PropTypes.func.isRequired,
};

export default CreateEditRuleForm;
