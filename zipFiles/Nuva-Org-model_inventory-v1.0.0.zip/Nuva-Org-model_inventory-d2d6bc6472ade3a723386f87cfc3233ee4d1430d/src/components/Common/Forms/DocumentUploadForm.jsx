import PropTypes from 'prop-types';
import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import * as Yup from 'yup';
import { useFormik } from 'formik';
import {
  Box,
  Button,
  Grid,
  IconButton,
  ListItem,
  ListItemIcon,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import { FaFileAlt } from 'react-icons/fa';
import CloseIcon from '@mui/icons-material/Close';
import SwalToast from '../SwalTost';

const DocumentUploadForm = ({
  handleClose = () => {},
  isMultiple = false,
  enitityType = '',
  entityId = '',
  attachDocument = () => {},
}) => {
  const [files, setFiles] = useState([]);
  const { getRootProps, getInputProps } = useDropzone({
    accept: '.doc,.docx,.pdf,.pkl',
    multiple: isMultiple,
    onDrop: (acceptedFiles) => {
      setFiles(acceptedFiles);
    },
  });
  // const handleUpload = () => {
  //   // handle file upload logic here
  //   console.log(files);
  // };

  const formValidationSchema = Yup.object({
    document_name: Yup.string().required('Required'),
    document_author: Yup.string().required('Required'),
    document_description: Yup.string().required('Required'),
  });
  const formikForm = useFormik({
    initialValues: {
      document_name: '',
      document_author: '',
      document_description: '',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      attachDocument({
        file: files[0],
        data: JSON.stringify({
          ...values,
          entity_type: enitityType,
          entity_id: entityId,
        }),
      }).then((res) => {
        if (res) {
          SwalToast({
            icon: 'success',
            title: 'Document attached successfully.',
          });
          formikForm?.handleReset();
          setFiles([]);
        }
        handleClose();
      });
    },
  });

  return (
    <Box>
      <Box
        {...getRootProps({ className: 'dropzone' })}
        style={{
          padding: '1rem',
          borderColor: '#0bb7a7',
          border: 'dashed 2px',
        }}
      >
        <input {...getInputProps()} />
        <Typography align="center">
          {`Drag 'n' drop some files here, or click to select files (.doc,
            .docx, .pdf, .pkl only)`}
        </Typography>
      </Box>
      {/* {files.length > 0 && (
          <Typography variant="body2" gutterBottom>
            {files.length} file(s) selected
          </Typography>
        )} */}

      {files.length ? (
        <Box mt={2} pb={1} className="dropzone-active">
          {files.map((file) => (
            <Box key={file.path}>
              <ListItem>
                <ListItemIcon>
                  <FaFileAlt />
                </ListItemIcon>
                <Box
                  display="flex"
                  alignItems="center"
                  justifyContent="space-between"
                  width="100%"
                >
                  <Typography sx={{ mr: 10 }}>
                    {file.path} - {file.size} bytes
                  </Typography>
                  <IconButton
                    aria-label="close"
                    onClick={() => {
                      setFiles((prev) =>
                        prev.filter((item) => item.path !== file.path)
                      );
                    }}
                  >
                    <CloseIcon />
                  </IconButton>
                </Box>
              </ListItem>
            </Box>
          ))}
        </Box>
      ) : null}
      <Grid container spacing={2} mt={2}>
        <Grid item lg={6}>
          <TextField
            {...formikForm.getFieldProps('document_name')}
            placeholder="Enter document name."
            label="Document name"
            helperText={
              formikForm?.errors?.document_name &&
              formikForm?.touched?.document_name
                ? formikForm.errors.document_name
                : null
            }
            error={
              Boolean(formikForm?.errors?.document_name) &&
              formikForm?.touched?.document_name
            }
          />
        </Grid>
        <Grid item lg={6}>
          <TextField
            {...formikForm.getFieldProps('document_author')}
            placeholder="Enter document author."
            label="Document author"
            helperText={
              formikForm?.errors?.document_author &&
              formikForm?.touched?.document_author
                ? formikForm.errors.document_author
                : null
            }
            error={
              Boolean(formikForm?.errors?.document_author) &&
              formikForm?.touched?.document_author
            }
          />
        </Grid>
        <Grid item lg={6}>
          <TextField
            {...formikForm.getFieldProps('document_description')}
            placeholder="Enter document description."
            label="Document description"
            helperText={
              formikForm?.errors?.document_description &&
              formikForm?.touched?.document_description
                ? formikForm.errors.document_description
                : null
            }
            error={
              Boolean(formikForm?.errors?.document_description) &&
              formikForm?.touched?.document_description
            }
          />
        </Grid>
        <Grid item lg={12}>
          <Stack>
            <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
              <Button
                onClick={() => {
                  formikForm.handleReset();
                  setFiles([]);
                }}
              >
                RESET
              </Button>
              <Button
                variant="contained"
                color="primary"
                disabled={files.length === 0}
                onClick={formikForm.handleSubmit}
              >
                Upload
              </Button>
            </Stack>
          </Stack>
        </Grid>
      </Grid>
    </Box>
  );
};

DocumentUploadForm.propTypes = {
  open: PropTypes.bool.isRequired,
  isMultiple: PropTypes.bool.isRequired,
  handleClose: PropTypes.func.isRequired,
  enitityType: PropTypes.string.isRequired,
  entityId: PropTypes.number.isRequired,
  attachDocument: PropTypes.func.isRequired,
};

export default DocumentUploadForm;
