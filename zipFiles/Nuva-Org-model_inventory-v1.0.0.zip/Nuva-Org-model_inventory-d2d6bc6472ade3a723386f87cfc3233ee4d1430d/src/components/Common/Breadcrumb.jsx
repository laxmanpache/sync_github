import React from 'react';
import { Box, Stack, Breadcrumbs, Typography } from '@mui/material';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { Link, useLocation } from 'react-router-dom';
import { ReactComponent as Home } from '../../assets/Icons/Home.svg';

const Breadcrumb = () => {
  const location = useLocation();
  const paths = location.pathname.split('/').slice(1);
  const pathNames = paths.map((text) => {
    return text
      .split('-')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join('');
  });
  return (
    <Box>
      <Stack spacing={2}>
        <Breadcrumbs
          separator={<NavigateNextIcon fontSize="small" />}
          aria-label="breadcrumb"
        >
          <Link underline="hover" key="1" color="inherit" to="/dashboard">
            <Home />
          </Link>
          {pathNames.map((value, index) => {
            const to = `/${paths.slice(0, index + 1).join('/')}`;
            return index === paths.length - 1 ? (
              <Box>
                <Typography key={to}>{value}</Typography>
              </Box>
            ) : (
              <Box>
                <Link style={{ textDecoration: 'inherit' }} to={to}>
                  <Typography
                    sx={(_theme) => {
                      return {
                        color: _theme.palette.primary.main,
                      };
                    }}
                  >
                    {value}
                  </Typography>
                </Link>
              </Box>
            );
          })}
        </Breadcrumbs>
      </Stack>
    </Box>
  );
};
export default Breadcrumb;
