import React, { useEffect } from 'react';
import {
  Box,
  Dialog,
  IconButton,
  Grid,
  Typography,
  TextField,
  Button,
  Stack,
  Autocomplete,
} from '@mui/material';
import { useFormik } from 'formik';
import moment from 'moment';
import * as Yup from 'yup';
import PropTypes from 'prop-types';
import CloseIcon from '@mui/icons-material/Close';
import DatePicker from '../../DatePicker';
import { DropDown, DropdownItem } from '../../DropDown';
import SwalToast from '../../SwalTost';

const CreateEditAlert = ({
  open,
  entityType,
  entityId,
  allUserList,
  mode,
  handleClose,
  updateAlerts,
  createAlerts,
  selectedAlert,
  getAllAlertList,
}) => {
  const formValidationSchema = Yup.object({
    alert_name: Yup.string().required('Required.'),
    due_date: Yup.string().required('Required.'),
    alert_type: Yup.string().required('Required.'),
    send_mail: Yup.string().required('Required.'),
    description: Yup.string().required('Required.'),
    alert_condition: Yup.object({
      desired_state: Yup.string().required('Required.'),
    }).required('Required.'),
    list_of_user: Yup.array().of(
      Yup.object()
        .shape({ username: Yup.string().required('Required.') })
        .required('Required.')
    ),
  });

  const USER_CONDITION = ['approve', 'reject', 'review'];
  const formikForm = useFormik({
    initialValues: {
      alert_name: '',
      due_date: '',
      alert_type: '',
      send_mail: 'No',
      list_of_user: [],
      alert_condition: {
        desired_state: '',
      },
      description: '',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      if (mode === 'edit') {
        updateAlerts({
          ...values,
          send_mail: values?.send_mail !== 'No',
          entity_type: entityType,
          entity_id: entityId,
          due_date: moment(values?.due_date).format('YYYY-MM-DD'),
        }).then((res) => {
          if (res) {
            SwalToast({
              icon: 'success',
              title: 'Alert updated successfully.',
            });
            getAllAlertList();
          }
        });
      } else {
        createAlerts({
          ...values,
          entity_type: entityType,
          entity_id: entityId,
          send_mail: values?.send_mail !== 'No',
          due_date: moment(values?.due_date).format('YYYY-MM-DD'),
        }).then((res) => {
          if (res) {
            SwalToast({
              icon: 'success',
              title: 'Alert created successfully.',
            });
            getAllAlertList();
          }
        });
      }

      formikForm?.handleReset();
      handleClose(false);
    },
  });
  useEffect(() => {
    if (selectedAlert && mode === 'edit') {
      formikForm.setValues({
        ...selectedAlert,
        send_mail: selectedAlert?.send_mail ? 'Yes' : 'No',
        due_date: new Date(selectedAlert?.due_date)?.toISOString(),
      });
    }
  }, [selectedAlert]);
  return (
    <Dialog
      disableBackdropClick
      onClose={() => {
        handleClose(false);
        formikForm?.handleReset();
      }}
      open={open}
      maxWidth="xs"
      fullWidth={true}
      aria-labelledby="doc-attach-modal"
    >
      <Grid container>
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
            <IconButton
              onClick={() => {
                handleClose();
                formikForm?.handleReset();
              }}
            >
              <CloseIcon />
            </IconButton>
          </Box>
        </Grid>
      </Grid>
      <Grid item xs={12}>
        <Box
          display="flex"
          justifyContent="space-around"
          alignItems="center"
          mb={2}
        >
          <Typography variant="h3">{`${
            mode === 'edit' ? 'Edit' : 'Create'
          } Alert`}</Typography>
        </Box>
      </Grid>
      <Grid container>
        <Grid
          item
          xs={12}
          display="flex"
          justifyContent="space-around"
          alignItems="center"
          container
          spacing={3}
          mt={3}
          width="300px"
        >
          <Grid item xs={12} lg={6}>
            <TextField
              name="alert_name"
              label="Alert name"
              disabled={mode === 'edit'}
              value={formikForm?.values?.alert_name}
              onChange={(e) => {
                formikForm.setFieldValue('alert_name', e.target.value);
              }}
              error={Boolean(
                formikForm?.errors?.alert_name &&
                  formikForm?.touched?.alert_name
              )}
              helperText={
                formikForm.touched.alert_name && formikForm?.errors?.alert_name
                  ? formikForm?.errors?.alert_name
                  : null
              }
            />
          </Grid>
          <Grid item xs={12} lg={6}>
            <DropDown
              label="Select alert type"
              name="alert_type"
              value={formikForm.values.alert_type}
              onChange={(e) => {
                formikForm.setFieldValue('alert_type', e.target.value);
              }}
              helperText={
                formikForm.touched.alert_type && formikForm.errors.alert_type
                  ? formikForm.errors.alert_type
                  : null
              }
              error={
                formikForm.touched.alert_type &&
                Boolean(formikForm.errors.alert_type)
              }
            >
              <DropdownItem value="Lifecycle alert">
                Lifecycle alert
              </DropdownItem>
            </DropDown>
          </Grid>
          <Grid item xs={12} lg={6}>
            <DatePicker
              label="Select due date"
              name="due_date"
              value={moment(formikForm?.values?.due_date)}
              onChange={(date) => {
                formikForm.setFieldValue('due_date', date);
              }}
              onBlur={formikForm.handleBlur}
              helperText={
                formikForm?.errors?.due_date && formikForm?.touched?.due_date
                  ? formikForm?.errors?.due_date
                  : null
              }
              error={
                Boolean(formikForm?.errors?.due_date) &&
                formikForm?.touched?.due_date
              }
            />
          </Grid>
          <Grid item xs={12} lg={6}>
            <DropDown
              label="Send email"
              placeholder="Send email"
              name="send_mail"
              value={formikForm.values.send_mail}
              onChange={(e) => {
                formikForm.setFieldValue('send_mail', e.target.value);
              }}
              helperText={
                formikForm.touched.send_mail && formikForm.errors.send_mail
                  ? formikForm.errors.send_mail
                  : null
              }
              error={
                formikForm.touched.send_mail &&
                Boolean(formikForm.errors.send_mail)
              }
            >
              <DropdownItem value="Yes">Yes</DropdownItem>
              <DropdownItem value="No">No</DropdownItem>
            </DropDown>
          </Grid>
          <Grid item xs={12} lg={6}>
            <DropDown
              label="Desired state"
              placeholder="Desired state"
              name="alert_condition.desired_state"
              value={formikForm.values?.alert_condition?.desired_state}
              onChange={(e) => {
                formikForm.setFieldValue(
                  'alert_condition.desired_state',
                  e.target.value
                );
              }}
              helperText={
                formikForm.touched.alert_condition?.desired_state &&
                formikForm.errors.alert_condition?.desired_state
                  ? formikForm.errors.alert_condition?.desired_state
                  : null
              }
              error={
                formikForm.touched.alert_condition?.desired_state &&
                Boolean(formikForm.errors.alert_condition?.desired_state)
              }
            >
              {USER_CONDITION?.map((state) => {
                return (
                  <DropdownItem key={state} value={state}>
                    {state}
                  </DropdownItem>
                );
              })}
            </DropDown>
          </Grid>
          <Grid item xs={12} lg={6}>
            <TextField
              name="description"
              label="Description"
              value={formikForm?.values?.description}
              onChange={(e) => {
                formikForm.setFieldValue('description', e.target.value);
              }}
              error={Boolean(
                formikForm?.errors?.description &&
                  formikForm?.touched?.description
              )}
              helperText={
                formikForm.touched.description &&
                formikForm?.errors?.description
                  ? formikForm?.errors?.description
                  : null
              }
            />
          </Grid>
          <Grid item xs={12}>
            <Autocomplete
              value={formikForm.values.list_of_user}
              onChange={(event, newValue) => {
                formikForm.setFieldValue('list_of_user', newValue);
              }}
              limitTags={2}
              multiple
              options={allUserList}
              getOptionLabel={(option) => option?.username}
              isOptionEqualToValue={(option, value) =>
                option?.username === value?.username
              }
              fullWidth
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="List of users."
                  placeholder="list_of_user"
                  error={Boolean(
                    formikForm?.errors?.list_of_user &&
                      formikForm?.touched?.list_of_user
                  )}
                  helperText={
                    formikForm.touched.list_of_user &&
                    formikForm?.errors?.list_of_user
                      ? formikForm?.errors?.list_of_user
                      : null
                  }
                />
              )}
            />
          </Grid>
          <Stack direction="row" gap="16px" justifyContent="center" mt={3}>
            <Button onClick={formikForm.handleReset}>Reset</Button>
            <Button onClick={formikForm.handleSubmit} variant="contained">
              {mode === 'create' ? 'Submit' : 'Update'}
            </Button>
          </Stack>
        </Grid>
      </Grid>
    </Dialog>
  );
};
CreateEditAlert.propTypes = {
  handleClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  mode: PropTypes.string.isRequired,
  entityType: PropTypes.string.isRequired,
  entityId: PropTypes.number.isRequired,
  allUserList: PropTypes.oneOfType([PropTypes.array]).isRequired,
  selectedAlert: PropTypes.oneOfType([PropTypes.array]).isRequired,
  updateAlerts: PropTypes.func.isRequired,
  createAlerts: PropTypes.func.isRequired,
  getAllAlertList: PropTypes.func.isRequired,
};
export default CreateEditAlert;
