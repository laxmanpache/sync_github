import React, { useEffect, useState } from 'react';
import {
  Box,
  Dialog,
  IconButton,
  Grid,
  Typography,
  TextField,
  Button,
  Stack,
  //   Autocomplete,
} from '@mui/material';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import PropTypes from 'prop-types';
import CloseIcon from '@mui/icons-material/Close';
import { DropDown, DropdownItem } from '../../DropDown';
import useEntity from '../../../../hooks/Configuration/useEntity';
import useModelInventory from '../../../../hooks/ModelInventory/useModelInventory';
import SwalToast from '../../SwalTost';

const CreateAddAssociation = ({
  open,
  handleClose,
  currentEntityType = 'ModelAssociation',
  entityId,
  getAllAssociation,
}) => {
  const { customEntityList } = useEntity();
  const { createModelFirstStep, createModelThirdStep } = useModelInventory();
  //   const [allTemplateList, setAllTemplateList] = useState([]);
  const [templateList, setTemplateList] = useState([]);
  const formValidationSchema = Yup.object({
    model_name: Yup.string().required('Required'),
    priority: Yup.string().required('Required'),
    entityName: Yup.string().required('Required'),
    association_name: Yup.string().required('Required'),
    entityType: Yup.string().required('Required'),
  });
  const formikForm = useFormik({
    initialValues: {
      model_name: '',
      entityName: '',
      entityType: 'ModelAssociation',
      priority: '',
      association_name: '',
      relation: 'Parent to',
    },
    validationSchema: formValidationSchema,
    onSubmit: (values) => {
      createModelFirstStep(values).then((res) => {
        if (res) {
          createModelThirdStep({
            association_name: values?.association_name,
            association_type: values?.entityType,
            entity_type: currentEntityType,
            entity_id: entityId,
            association_id: res?.data?.ModelEntity?.ModelEntityId,
            relation: values?.relation,
          }).then((resp) => {
            if (resp) {
              SwalToast({
                icon: 'success',
                title: resp?.data?.msg,
              });
              getAllAssociation();
              handleClose();
            }
          });
          SwalToast({
            icon: 'success',
            title: 'Step first created successfully.',
          });
        }
      });

      formikForm.handleReset();
    },
  });
  useEffect(() => {
    customEntityList().then((res) => {
      if (res) {
        // setAllTemplateList(res?.data);
        setTemplateList(
          res?.data?.filter(
            (entity) => entity?.entity_type === 'ModelAssociation'
          )
        );
      }
    });
  }, []);

  return (
    <Dialog
      disableBackdropClick
      onClose={() => {
        handleClose(false);
        formikForm?.handleReset();
      }}
      open={open}
      maxWidth="xs"
      fullWidth={true}
      aria-labelledby="doc-attach-modal"
    >
      <Grid container>
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
            <IconButton
              onClick={() => {
                handleClose();
                formikForm?.handleReset();
              }}
            >
              <CloseIcon />
            </IconButton>
          </Box>
        </Grid>
      </Grid>
      <Grid container rowSpacing={5} xs={12}>
        <Grid item xs={12}>
          <Box
            display="flex"
            justifyContent="space-around"
            alignItems="center"
            mb={2}
          >
            <Typography variant="h3">Create and Add Association</Typography>
          </Box>
        </Grid>
        <Grid
          item
          container
          xs={12}
          display="flex"
          justifyContent="space-around"
          alignItems="center"
          spacing={2}
        >
          <Grid item xs={6}>
            <DropDown
              value={formikForm.values.relation}
              disabled
              label="Relation Option"
            >
              <DropdownItem
                onChange={(event) => {
                  formikForm.setFieldValue('relation', event.target.value);
                }}
                key={3}
                value={formikForm.values.relation}
              >
                Parent to
              </DropdownItem>
            </DropDown>
          </Grid>
          <Grid item xs={6}>
            <DropDown
              label="Type of issue"
              value={formikForm.values.entityType}
              onChange={(event) => {
                // formikForm.setValues({
                //   model_name: '',
                //   entityName: '',
                //   entityType: event.target.value,
                //   priority: '',
                //   association_name: '',
                //   riskRating: '',
                // });
                formikForm.setFieldValue('entityType', event.target.value);
                // setTemplateList(
                //   allTemplateList.filter(
                //     (entity) => entity?.entity_type === event.target.value
                //   )
                // );
              }}
            >
              {/* <DropdownItem key={3} value="ModelInventory">
                ModelInventory
              </DropdownItem> */}
              <DropdownItem key={3} value="ModelAssociation">
                ModelAssociation
              </DropdownItem>
            </DropDown>
          </Grid>
          <Grid item xs={6}>
            <TextField
              name="association_name"
              value={formikForm?.values?.association_name}
              {...formikForm.getFieldProps('association_name')}
              placeholder="Enter association name."
              label="Issue name."
              helperText={
                formikForm?.errors?.association_name &&
                formikForm?.touched?.association_name
                  ? formikForm.errors.association_name
                  : null
              }
              error={
                Boolean(formikForm?.errors?.association_name) &&
                formikForm?.touched?.association_name
              }
            />
          </Grid>

          <Grid item xs={6}>
            <TextField
              name="model_name"
              value={formikForm?.values?.model_name}
              {...formikForm.getFieldProps('model_name')}
              placeholder={
                formikForm?.values?.entityType === 'ModelInventory'
                  ? '"Enter model name."'
                  : 'Enter association name'
              }
              label={
                formikForm?.values?.entityType === 'ModelInventory'
                  ? 'Model Name'
                  : 'Association name'
              }
              helperText={
                formikForm?.errors?.model_name &&
                formikForm?.touched?.model_name
                  ? formikForm.errors.model_name
                  : null
              }
              error={
                Boolean(formikForm?.errors?.model_name) &&
                formikForm?.touched?.model_name
              }
            />
          </Grid>
          <Grid item xs={6}>
            <DropDown
              label="Template name"
              value={formikForm.values.entityName}
              onChange={(event) => {
                formikForm.setFieldValue('entityName', event.target.value);
              }}
              helperText={
                formikForm?.errors?.entityName &&
                formikForm?.touched?.entityName
                  ? formikForm.errors.entityName
                  : null
              }
              error={
                Boolean(formikForm?.errors?.entityName) &&
                formikForm?.touched?.entityName
              }
            >
              {templateList?.map((entity) => {
                return (
                  <DropdownItem key={3} value={entity?.entity_name}>
                    {entity?.entity_name}
                  </DropdownItem>
                );
              })}
            </DropDown>
          </Grid>
          <Grid item xs={6}>
            {/* {formikForm?.values?.entityType === 'ModelInventory' ? (
              <DropDown
                label="Risk rating"
                value={formikForm.values.riskRating}
                onChange={(event) => {
                  formikForm.setFieldValue('riskRating', event.target.value);
                }}
              >
                <DropdownItem key={3} value="Tier-1">
                  Tier-1
                </DropdownItem>
                <DropdownItem key={3} value="Tier-2">
                  Tier-2
                </DropdownItem>
                <DropdownItem key={3} value="Tier-3">
                  Tier-3
                </DropdownItem>
              </DropDown>
            ) : ( */}
            <DropDown
              label="Select priority"
              value={formikForm.values.priority}
              onChange={(event) => {
                formikForm.setFieldValue('priority', event.target.value);
              }}
              helperText={
                formikForm?.errors?.priority && formikForm?.touched?.priority
                  ? formikForm.errors.priority
                  : null
              }
              error={
                Boolean(formikForm?.errors?.priority) &&
                formikForm?.touched?.priority
              }
            >
              <DropdownItem key={3} value="High">
                High
              </DropdownItem>
              <DropdownItem key={3} value="Medium">
                Medium
              </DropdownItem>
              <DropdownItem key={3} value="Low">
                Low
              </DropdownItem>
            </DropDown>
            {/* )} */}
          </Grid>

          <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
            <Button
              onClick={() => {
                formikForm.handleReset();
              }}
            >
              RESET
            </Button>
            <Button onClick={formikForm.handleSubmit} variant="contained">
              SUBMIT
            </Button>
          </Stack>
        </Grid>
      </Grid>
    </Dialog>
  );
};
CreateAddAssociation.propTypes = {
  handleClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  currentEntityType: PropTypes.string.isRequired,
  entityId: PropTypes.number.isRequired,
  getAllAssociation: PropTypes.func.isRequired,
};
export default CreateAddAssociation;
