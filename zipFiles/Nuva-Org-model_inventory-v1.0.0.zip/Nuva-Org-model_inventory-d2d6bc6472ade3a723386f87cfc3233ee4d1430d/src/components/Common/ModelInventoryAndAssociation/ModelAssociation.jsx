/* eslint-disable react/no-unstable-nested-components */
import React from 'react';
import { Box, IconButton, Typography, Grid, Slide } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import { useNavigate } from 'react-router-dom';
import VisibilityIcon from '@mui/icons-material/Visibility';
import PropTypes from 'prop-types';
import moment from 'moment';
import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';
import ReactMuiTableListView from '../ReactMuiTableListView';
import SwalToast from '../SwalTost';

const TABLE_HEADINGS = {
  ChildAssociation: 'Child association',
  BlockedBy: 'Blocked by',
  DuplicateTo: 'Duplicate to',
  RelatedTo: 'Related to',
  ParentAssociation: 'Parent association',
  Blocks: 'Blocks',
};

const AssociationColumns = [
  {
    heading: 'ASSOCIATION ID',
    accessor: 'associated_id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'ASSOCIATION NAME',
    accessor: 'association_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'ASSOCIATION TYPE',
    accessor: 'association_type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CREATED AT',
    accessor: 'created_at',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    Cell: ({ row }) =>
      moment(new Date(row.original.created_at)).format('YYY/DD/MM'),
    width: 200,
  },
  {
    heading: 'CREATED BY',
    accessor: 'created_by',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];
const RowLevelOnHoverAssociationOptions = ({
  containerSx,
  row,
  className,
  removeModelAssociation,
  entityId,
  entityType,
  getAssociationDetails,
  setValue,
}) => {
  const history = useNavigate();
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            onClick={() => {
              if (row?.original?.association_type === 'ModelInventory') {
                history({
                  pathname: `/model-inventory/${row?.original?.associated_id}`,
                  // search: `modelId=${row?.original?.associated_id}`,
                });
                setValue(1);
              } else {
                history({
                  pathname: `/model-association/${row?.original?.associated_id}`,
                  // search: `assId=${row?.original?.associated_id}`,
                });
              }
            }}
            title="View Association details"
          >
            <VisibilityIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            title="Delete Team Association"
            onClick={() => {
              removeModelAssociation({
                entity_type: entityType,
                entity_id: entityId,
                associated_id: row?.original?.associated_id,
                association_type: row?.original?.association_type,
              }).then(() => {
                SwalToast({
                  icon: 'success',
                  title: 'Associated model removed successfully.',
                });
                getAssociationDetails({
                  entityType,
                  entityId,
                });
              });
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverAssociationOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  removeModelAssociation: PropTypes.func.isRequired,
  getAssociationDetails: PropTypes.func.isRequired,
  setValue: PropTypes.func.isRequired,
  entityId: PropTypes.number.isRequired,
  entityType: PropTypes.string.isRequired,
};

const ModelAssociation = ({
  association,
  removeModelAssociation,
  getAssociationDetails,
  setValue,
  entityId,
  entityType,
  value,
}) => {
  return (
    <Box>
      <Slide direction="left" timeout={1000} mountOnEnter in={value === 4}>
        <Box>
          {association
            ? Object.keys(association).map((key) => {
                return association[key].length ? (
                  <Grid key={key} container sx={12} rowGap={2}>
                    <Grid container item xs={12} rowSpacing={1}>
                      <Grid item xs={12}>
                        <Typography variant="subtitle" sx={{ fontWeight: 700 }}>
                          {TABLE_HEADINGS[key]}
                        </Typography>
                      </Grid>
                      <Grid item xs={12}>
                        <ReactMuiTableListView
                          data={
                            association[key]?.length > 0 ? association[key] : []
                          }
                          columns={AssociationColumns}
                          rowLevelOnHoverOptions={({
                            containerSx,
                            row,
                            className,
                          }) => {
                            return (
                              <RowLevelOnHoverAssociationOptions
                                containerSx={containerSx}
                                row={row}
                                className={className}
                                removeModelAssociation={removeModelAssociation}
                                entityId={entityId}
                                entityType={entityType}
                                getAssociationDetails={getAssociationDetails}
                                setValue={setValue}
                              />
                            );
                          }}
                          getHeaderProps={() => ({
                            style: {
                              display: 'flex',
                              alignItems: 'center',
                            },
                          })}
                          getRowProps={() => ({
                            style: {
                              position: 'relative',
                            },
                          })}
                          enableRowSelection={false}
                          pageCount={association[key]?.length}
                          enablePagination={true}
                          initialPageSize={10}
                          rowsPerPageOptions={[5, 10, 15]}
                        />
                      </Grid>
                    </Grid>
                  </Grid>
                ) : null;
              })
            : null}
        </Box>
      </Slide>
    </Box>
  );
};

export default ModelAssociation;

ModelAssociation.propTypes = {
  association: PropTypes.oneOfType([PropTypes.object]).isRequired,
  removeModelAssociation: PropTypes.func.isRequired,
  getAssociationDetails: PropTypes.func.isRequired,
  setValue: PropTypes.func.isRequired,
  entityId: PropTypes.number.isRequired,
  entityType: PropTypes.string.isRequired,
  value: PropTypes.number.isRequired,
};
