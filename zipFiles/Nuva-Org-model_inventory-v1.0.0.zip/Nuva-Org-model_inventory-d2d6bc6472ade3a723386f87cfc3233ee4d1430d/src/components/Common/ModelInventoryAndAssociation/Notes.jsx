import React, { useRef, useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Button,
  Typography,
  TextField,
  Stack,
  Avatar,
} from '@mui/material';
import * as _ from 'lodash';
import moment from 'moment';
import { styled } from '@mui/material/styles';
import PropTypes from 'prop-types';
import SwalToast from '../SwalTost';

const CustomTextField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-input': {
    padding: '10px !important',
  },
  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      borderColor: theme.palette.primary.main,
    },
  },
}));
const StyledButton = styled(Button)(() => ({
  textTransform: 'capitalize',
}));
const StyledCommentActionButton = styled(Button)(() => ({
  textTransform: 'capitalize',
  fontSize: '10px',
  height: 0,
  minWidth: 0,
}));

const Notes = ({
  getAllNotes,
  addNote,
  entityType = 'ModelInventory',
  entityId,
}) => {
  const ref = useRef();
  const [comment, setComment] = useState();
  const [userClick, setUserClick] = useState(null);
  const [allComments, setAllComments] = useState([]);
  const getAllComments = () => {
    getAllNotes({
      entityType,
      entityId,
    }).then((res) => {
      if (res) {
        setAllComments(res?.data?.Notes);
      }
    });
  };
  const AddNewComment = () => {
    const body = {
      entity_type: entityType,
      entity_id: Number(entityId),
      note: comment,
    };
    addNote(body).then(() => {
      SwalToast({
        icon: 'success',
        title: 'Note added successfully.',
      });
      setComment('');
      getAllComments();
      setUserClick(null);
    });
  };
  useEffect(() => {
    getAllComments();
  }, []);

  return (
    <Grid container xs={12}>
      <Grid item xs={12} flexGrow>
        <CustomTextField
          ref={ref}
          value={comment}
          onChange={(e) => {
            setComment(e.target.value);
          }}
          onClick={() => {
            setUserClick(0);
          }}
          placeholder="Add comment ..."
        />
      </Grid>
      <Grid item xs={12} flexGrow>
        {userClick === 0 ? (
          <Stack direction="row" mt={1}>
            <StyledButton
              size="small"
              onClick={() => {
                if (!_.isEmpty(comment)) {
                  AddNewComment();
                }
              }}
            >
              Save
            </StyledButton>
            <StyledButton
              size="small"
              onClick={() => {
                setUserClick(null);
                setComment('');
              }}
            >
              Cancel
            </StyledButton>
          </Stack>
        ) : null}
      </Grid>
      {allComments?.length ? (
        <Grid container item xs={12} mt={2}>
          <Stack spacing={3}>
            {allComments?.map((useComment, index) => {
              return (
                // eslint-disable-next-line react/no-array-index-key
                <Box key={index}>
                  <Stack direction="row" spacing={2} sx={{ display: 'flex' }}>
                    <Avatar
                      sx={{
                        width: 24,
                        height: 24,
                        background: (theme) => theme.palette.primary.main,
                      }}
                    >
                      {useComment?.created_by[0]}
                    </Avatar>
                    <Typography variant="body4">
                      {useComment?.created_by}
                    </Typography>
                    <Typography variant="body4">
                      {moment(new Date(useComment?.created_date)).format(
                        'MMMM Do YYYY, h:mm:ss a'
                      )}
                    </Typography>
                  </Stack>
                  <Box ml={4}>
                    <Typography>{useComment.note}</Typography>
                    <Stack direction="row" mt={1}>
                      <StyledCommentActionButton size="small">
                        Edit
                      </StyledCommentActionButton>
                      <StyledCommentActionButton size="small">
                        delete
                      </StyledCommentActionButton>
                    </Stack>
                  </Box>
                </Box>
              );
            })}
          </Stack>
        </Grid>
      ) : (
        <Box
          display="flex"
          sx={{ height: 'calc(100vh  - 300px)' }}
          flexGrow={1}
          alignItems="center"
          flexDirection="column"
          justifyContent="center"
        >
          <Typography color="text.disabled">No comments present</Typography>
        </Box>
      )}
    </Grid>
  );
};

Notes.propTypes = {
  entityId: PropTypes.number.isRequired,
  entityType: PropTypes.string.isRequired,
  getAllNotes: PropTypes.func.isRequired,
  addNote: PropTypes.func.isRequired,
};
export default Notes;
