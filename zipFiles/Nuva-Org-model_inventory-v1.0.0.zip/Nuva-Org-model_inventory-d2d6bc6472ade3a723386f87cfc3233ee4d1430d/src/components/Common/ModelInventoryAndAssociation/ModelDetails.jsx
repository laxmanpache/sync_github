/* eslint-disable no-nested-ternary */
/* eslint-disable camelcase */
import React, { useEffect, useState } from 'react';
import { Grid, Typography, Divider, IconButton, Box } from '@mui/material';
import propTypes from 'prop-types';
import * as Yup from 'yup';
import EditIcon from '@mui/icons-material/Edit';
import { useFormik } from 'formik';
import SaveIcon from '@mui/icons-material/Save';
import * as _ from 'lodash';
import { AllFields } from '../VaultDynamicFrom';
import SwalToast from '../SwalTost';
import { createYupSchema } from '../../../utils/Utils';

const ModelDetails = ({
  entityId,
  getAttributeDetails,
  entityType = 'ModelInventory',
  createModelSecondStep,
  fromDetails,
}) => {
  const [initialFormValues, setInitialFormValues] = React.useState({});
  const [vaultSchema, setVaultSchema] = React.useState({});
  const [attributeDetails, setAttributeDetails] = useState([]);
  const [editModel, setEditModel] = useState(false);
  const getAttributes = () => {
    getAttributeDetails({
      entityType,
      entityId,
    }).then((res) => {
      if (res) {
        setAttributeDetails(_.isEmpty(res?.data?.data) ? [] : res?.data?.data);
      }
    });
  };
  const initialValues = () => {
    const schema = {};
    const newInitialValues = {};
    fromDetails.forEach((section) => {
      newInitialValues[section.section_name] = {};
      const yepSchema = section?.attributes.reduce(createYupSchema, {});
      schema[section.section_name] = Yup.object().shape(yepSchema);

      section.attributes.forEach((attribute) => {
        newInitialValues[section.section_name][attribute.name] = _.isEmpty(
          attribute?.value
        )
          ? ''
          : attribute?.value;
      });
    });
    setInitialFormValues(newInitialValues);

    setVaultSchema(Yup.object().shape(schema));
    return newInitialValues;
  };
  useEffect(() => {
    initialValues();
    setTimeout(() => {
      const updatedValue = {};
      if (Object?.keys(attributeDetails || {})?.length > 0) {
        /*
        - this code is added for re-initialization
        -once in attributeDetails all template and value will come from backend then need to change this one 
        */
        Object?.keys(attributeDetails)?.forEach((obj) => {
          updatedValue[obj] = {
            ...initialFormValues[obj],
            ...attributeDetails[obj],
          };
        });

        // eslint-disable-next-line no-use-before-define
        formikForm.setValues({ ...updatedValue });
      }
    }, 200);
  }, [editModel]);
  useEffect(() => {
    if (entityId) {
      getAttributes();
    }
  }, [entityId]);
  const formikForm = useFormik({
    initialValues: initialFormValues,
    enableReinitialize: true,
    validationSchema: vaultSchema,
    onSubmit: (values) => {
      const params = {
        entity_id: entityId,
        entity_type: entityType,
      };
      createModelSecondStep({ attributeValue: values }, params).then((res) => {
        if (res) {
          SwalToast({
            icon: 'success',
            title: 'Details updated  successfully.',
          });
          getAttributes();
          setEditModel(false);
        }
      });
    },
  });

  return (
    <Grid container xs={12} spacing={4}>
      {fromDetails?.map((section, index) => {
        return (
          <Grid item xs={12} key={section}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography variant="h3">{section?.section_name}</Typography>
              {index === 0 ? (
                <Box>
                  {!editModel ? (
                    <IconButton
                      title="Edit"
                      onClick={() => {
                        setEditModel(true);
                      }}
                    >
                      <EditIcon color="primary" />
                    </IconButton>
                  ) : (
                    <IconButton
                      title="Save"
                      onClick={() => {
                        formikForm?.handleSubmit();
                      }}
                    >
                      <SaveIcon color="primary" />
                    </IconButton>
                  )}
                </Box>
              ) : null}
            </Box>
            <Divider
              sx={{
                mb: 2,
                backgroundColor: (_theme) => _theme.palette.other.grey1,
              }}
              light
              orientation="horizontal"
            />
            <Grid item container xs={12} spacing={2}>
              {section?.attributes?.map((attribute, i) => {
                return (
                  <Grid
                    container
                    item
                    xs={12}
                    lg={6}
                    display="flex"
                    // eslint-disable-next-line react/no-array-index-key
                    key={i}
                  >
                    <Grid item xs={5} title={attribute?.name}>
                      <Typography
                        overflow="hidden"
                        component="div"
                        textOverflow="ellipsis"
                        sx={{
                          wordBreak: 'break-word',
                          whiteSpace: 'nowrap',
                        }}
                        variant="subtitle1"
                      >{`${attribute?.name} :`}</Typography>
                    </Grid>
                    <Grid item xs={7}>
                      {!editModel ? (
                        <Typography variant="subtitle">
                          {_.isEmpty(
                            attributeDetails[section?.section_name]?.[
                              attribute?.name
                            ]
                          )
                            ? '-'
                            : _.isArray(
                                attributeDetails[section?.section_name]?.[
                                  attribute?.name
                                ]
                              )
                            ? attributeDetails[section?.section_name]?.[
                                attribute?.name
                              ]?.map((item) => {
                                return (
                                  <Typography
                                    key={item?.label}
                                    variant="subtitle"
                                    mr={1}
                                  >
                                    {`${item?.label},`}
                                  </Typography>
                                );
                              })
                            : attributeDetails[section?.section_name]?.[
                                attribute?.name
                              ]}
                        </Typography>
                      ) : (
                        <AllFields
                          attribute={attribute}
                          sectionName={section}
                          type={attribute?.input_control_type}
                          name={`${section?.section_name}.${attribute?.name}`}
                          label={attribute?.label}
                          formikFrom={formikForm}
                          error={
                            Boolean(
                              formikForm?.errors?.[section?.section_name]?.[
                                attribute?.name
                              ]
                            ) &&
                            formikForm?.touched?.[section?.section_name]?.[
                              attribute?.name
                            ]
                          }
                          helperText={
                            formikForm?.errors?.[section?.section_name]?.[
                              attribute?.name
                            ] &&
                            formikForm?.touched?.[section?.section_name]?.[
                              attribute?.name
                            ]
                              ? formikForm.errors?.[section?.section_name]?.[
                                  attribute?.name
                                ]
                              : null
                          }
                          value={
                            formikForm.values?.[section?.section_name]?.[
                              attribute?.name
                            ] ?? ''
                          }
                        />
                      )}
                    </Grid>
                  </Grid>
                );
              })}
            </Grid>
          </Grid>
        );
      })}
    </Grid>
  );
};

export default ModelDetails;

ModelDetails.propTypes = {
  entityId: propTypes.number.isRequired,
  getAttributeDetails: propTypes.func.isRequired,
  entityType: propTypes.string.isRequired,
  createModelSecondStep: propTypes.func.isRequired,
  fromDetails: propTypes.arrayOf(propTypes.oneOfType([propTypes.object]))
    .isRequired,
};
