import React, { useEffect, useState } from 'react';
import { Grid, IconButton, Typography, Box } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import SaveAsIcon from '@mui/icons-material/SaveAs';
import propTypes from 'prop-types';
import moment from 'moment';
import { useFormik } from 'formik';
import { DropDown, DropdownItem } from '../DropDown';
import SwalToast from '../SwalTost';

const Summary = ({
  currentModel,
  summaryLabels,
  allUserList,
  entityType = 'ModelInventory',
  updateModelEntity,
  getModelDetails,
}) => {
  const [editModel, setEditModel] = useState(false);
  const [saveAs, setSaveAs] = useState(false);
  const formikForm = useFormik({
    initialValues: {
      assignedUser: '',
      modelRiskRating: '',
      priority: '',
    },
    onSubmit: (values) => {
      const body = {
        ...currentModel,
        ...values,
        entityType,
        riskRating: values?.modelRiskRating,
        entityId:
          entityType === 'ModelInventory'
            ? currentModel?.model_id
            : currentModel?.association_id,
        entityName: currentModel?.type,
        saveAs,
      };
      updateModelEntity(body).then((res) => {
        if (res) {
          getModelDetails();
          SwalToast({
            icon: 'success',
            title: 'Data updated successfully.',
          });
        }
      });
    },
  });
  useEffect(() => {
    formikForm.setFieldValue('assignedUser', currentModel?.assignedUser);
    formikForm.setFieldValue('modelRiskRating', currentModel?.modelRiskRating);
    formikForm.setFieldValue('priority', currentModel?.priority);
  }, [currentModel]);
  return (
    <Grid container xs={12} spacing={2}>
      <Grid item xs={12} display="flex" justifyContent="space-between">
        <Typography component="h1" variant="h3">
          {`Status : ${currentModel?.status}`}
        </Typography>
        <Box>
          {!editModel ? (
            <IconButton
              title="Edit"
              onClick={() => {
                setEditModel(true);
              }}
            >
              <EditIcon color="primary" />
            </IconButton>
          ) : (
            <>
              <IconButton
                title="Save as"
                onClick={() => {
                  setSaveAs(true);
                  formikForm?.handleSubmit();
                  setEditModel(false);
                }}
              >
                <SaveAsIcon color="primary" />
              </IconButton>
              <IconButton
                title="Save"
                onClick={() => {
                  setSaveAs(false);
                  formikForm?.handleSubmit();
                  setEditModel(false);
                }}
              >
                <SaveIcon color="primary" />
              </IconButton>
            </>
          )}
        </Box>
      </Grid>

      {Object?.keys(currentModel || {})
        ?.filter((item) => item !== 'status')
        .map((attribute, i) => {
          return (
            <Grid
              container
              item
              xs={12}
              lg={6}
              // eslint-disable-next-line react/no-array-index-key
              key={i}
            >
              {summaryLabels[attribute] ? (
                <>
                  <Grid item xs={5}>
                    <Typography component="div" variant="subtitle1">
                      {`${summaryLabels[attribute]} :`}
                    </Typography>
                  </Grid>
                  <Grid item xs={7}>
                    {editModel && ['assignedUser'].includes(attribute) ? (
                      <DropDown
                        label="Assign user"
                        value={formikForm.values.assignedUser}
                        onChange={(event) => {
                          formikForm.setFieldValue(
                            'assignedUser',
                            event.target.value
                          );
                        }}
                      >
                        {allUserList?.map((user) => {
                          return (
                            <DropdownItem key={3} value={user?.user}>
                              {user?.user}
                            </DropdownItem>
                          );
                        })}
                      </DropDown>
                    ) : null}
                    {editModel && ['modelRiskRating'].includes(attribute) ? (
                      <DropDown
                        label="Risk rating"
                        value={formikForm.values.modelRiskRating}
                        onChange={(event) => {
                          formikForm.setFieldValue(
                            'modelRiskRating',
                            event.target.value
                          );
                        }}
                      >
                        <DropdownItem key={3} value="Tier-1">
                          Tier-1
                        </DropdownItem>
                        <DropdownItem key={3} value="Tier-2">
                          Tier-2
                        </DropdownItem>
                        <DropdownItem key={3} value="Tier-3">
                          Tier-3
                        </DropdownItem>
                      </DropDown>
                    ) : null}
                    {editModel && ['priority'].includes(attribute) ? (
                      <DropDown
                        label="Select priority"
                        value={formikForm.values.priority}
                        onChange={(event) => {
                          formikForm.setFieldValue(
                            'priority',
                            event.target.value
                          );
                        }}
                      >
                        <DropdownItem key={3} value="High">
                          High
                        </DropdownItem>
                        <DropdownItem key={3} value="Medium">
                          Medium
                        </DropdownItem>
                        <DropdownItem key={3} value="Low">
                          Low
                        </DropdownItem>
                      </DropDown>
                    ) : null}
                    {editModel &&
                    ['modelRiskRating', 'assignedUser', 'priority'].includes(
                      attribute
                    ) ? null : (
                      <Typography ml={2} variant="subtitle">
                        {['created_at', 'updated_at'].includes(attribute)
                          ? moment(currentModel[attribute]).format('YYYY/MM/DD')
                          : currentModel[attribute]}
                      </Typography>
                    )}
                  </Grid>
                </>
              ) : null}
            </Grid>
          );
        })}
    </Grid>
  );
};

export default Summary;

Summary.propTypes = {
  summaryLabels: propTypes.arrayOf(propTypes.oneOfType([propTypes.object]))
    .isRequired,
  allUserList: propTypes.arrayOf(propTypes.oneOfType([propTypes.object]))
    .isRequired,
  currentModel: propTypes.oneOfType([propTypes.object]).isRequired,
  updateModelEntity: propTypes.func.isRequired,
  getModelDetails: propTypes.func.isRequired,
  entityType: propTypes.string.isRequired,
};
