import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  IconButton,
  Grid,
  Divider,
  Typography,
  Switch,
  Slide,
} from '@mui/material';
import PropTypes from 'prop-types';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import DeleteIcon from '@mui/icons-material/Delete';
import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';
import ReactMuiTableListView from '../ReactMuiTableListView';
import SwalToast from '../SwalTost';
import CreateEditAlert from './Modals/CreateEditAlert';

const ALERTS_COLUMNS = [
  {
    heading: 'ALERT ID',
    accessor: 'alert_id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'ALERT NAME',
    accessor: 'alert_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'ALERT TYPE',
    accessor: 'alert_type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CREATED BY',
    accessor: 'created_by',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'ALERT CONDITION',
    accessor: 'alert_condition.desired_state',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'List OF USERS',
    accessor: 'list_of_user',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    Cell: ({ row }) => {
      return row?.original?.list_of_user?.map((user) => {
        return <Typography key={user}>{`${user?.username} `}</Typography>;
      });
    },
    width: 200,
  },
];
const RowLevelOnHover = ({
  containerSx,
  row,
  entityType,
  className,
  entityId,
  deleteAlert,
  setSelectedAlert,
  setOpen,
  setMode,
  getAllAlertList,
  handleSendEmail,
}) => {
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <Box title={row?.original?.send_mail ? 'Enabled' : 'Disabled'}>
            <Switch
              name="Enable"
              checked={row?.original?.send_mail}
              onChange={(e) => {
                handleSendEmail(e, row?.original);
              }}
            />
          </Box>
          <IconButton
            size="small"
            title="Edit alert."
            onClick={() => {
              setOpen(true);
              setMode('edit');
              setSelectedAlert(row?.original);
            }}
          >
            <BorderColorIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            title="Delete alert."
            onClick={() => {
              deleteAlert({
                entityType,
                entityId,
                alertName: row?.original?.alert_name,
              }).then((res) => {
                if (res) {
                  SwalToast({
                    icon: 'success',
                    title: 'Alert deleted successfully.',
                  });
                  getAllAlertList();
                }
              });
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHover.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  entityType: PropTypes.string.isRequired,
  entityId: PropTypes.number.isRequired,
  deleteAlert: PropTypes.func.isRequired,
  getAllAlertList: PropTypes.func.isRequired,
  setSelectedAlert: PropTypes.func.isRequired,
  setOpen: PropTypes.func.isRequired,
  setMode: PropTypes.func.isRequired,
  handleSendEmail: PropTypes.func.isRequired,
};
const Alerts = ({
  value,
  entityType = 'ModelInventory',
  entityId,
  getAllAlerts,
  deleteAlert,
  allUserList,
  updateAlerts,
  createAlerts,
}) => {
  const [alertList, setAlertList] = useState([]);
  const [selectedAlert, setSelectedAlert] = useState({});
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState('create');
  const getAllAlertList = () => {
    getAllAlerts({ entityType, entityId }).then((res) => {
      if (res) {
        setAlertList(res?.data);
      }
    });
  };
  useEffect(() => {
    getAllAlertList();
  }, []);

  const handleSendEmail = (e, alert) => {
    updateAlerts({
      ...alert,
      send_mail: e.target.checked,
    }).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: 'Alert updated successfully.',
        });
        getAllAlertList();
      }
    });
  };

  return (
    <Grid item container xs={12} rowSpacing={2}>
      <Grid item xs={12} md={12}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Typography variant="h4">Alerts</Typography>
          <Button
            variant="contained"
            onClick={() => {
              setOpen(true);
            }}
          >
            Create Alert
          </Button>
        </Box>
      </Grid>
      <Grid item xs={12}>
        <Divider
          sx={{
            backgroundColor: (_theme) => _theme.palette.other.grey1,
          }}
          light
          orientation="horizontal"
        />
      </Grid>
      <Grid item xs={12}>
        {alertList?.length > 0 ? (
          <Slide direction="left" timeout={1000} mountOnEnter in={value === 8}>
            <Box>
              <ReactMuiTableListView
                data={alertList?.length > 0 ? alertList : []}
                columns={ALERTS_COLUMNS}
                getHeaderProps={() => ({
                  style: {
                    display: 'flex',
                    alignItems: 'center',
                  },
                })}
                getRowProps={() => ({
                  style: {
                    position: 'relative',
                  },
                })}
                // eslint-disable-next-line react/no-unstable-nested-components
                rowLevelOnHoverOptions={({ containerSx, row, className }) => {
                  return (
                    <RowLevelOnHover
                      containerSx={containerSx}
                      row={row}
                      entityId={entityId}
                      className={className}
                      entityType={entityType}
                      deleteAlert={deleteAlert}
                      setSelectedAlert={setSelectedAlert}
                      setOpen={setOpen}
                      setMode={setMode}
                      getAllAlertList={getAllAlertList}
                      handleSendEmail={handleSendEmail}
                    />
                  );
                }}
                enableRowSelection={false}
                pageCount={alertList?.length}
                enablePagination={true}
                initialPageSize={10}
                rowsPerPageOptions={[5, 10, 15]}
              />
            </Box>
          </Slide>
        ) : (
          <Box
            display="flex"
            sx={{ height: 'calc(100vh  - 400px)' }}
            flexGrow={1}
            alignItems="center"
            flexDirection="column"
            justifyContent="center"
          >
            <Typography variant="subtitle1">No data result found.</Typography>
          </Box>
        )}
      </Grid>
      <CreateEditAlert
        open={open}
        handleClose={() => {
          setOpen(false);
          setMode('create');
          setSelectedAlert({});
        }}
        mode={mode}
        selectedAlert={selectedAlert}
        entityType={entityType}
        entityId={entityId}
        allUserList={allUserList}
        updateAlerts={updateAlerts}
        createAlerts={createAlerts}
        getAllAlertList={getAllAlertList}
      />
    </Grid>
  );
};

Alerts.propTypes = {
  allUserList: PropTypes.oneOfType([PropTypes.object]).isRequired,
  entityType: PropTypes.string.isRequired,
  entityId: PropTypes.string.isRequired,
  deleteAlert: PropTypes.func.isRequired,
  getAllAlerts: PropTypes.func.isRequired,
  updateAlerts: PropTypes.func.isRequired,
  createAlerts: PropTypes.func.isRequired,
  value: PropTypes.number.isRequired,
};
export default Alerts;
