// @ts-nocheck
import React from 'react';
import Zoom from '@mui/material/Zoom';

const DialogTransition = React.forwardRef(function Transition(props, ref) {
  return <Zoom in={true} ref={ref} {...props} />;
});

export default DialogTransition;
