/* eslint-disable react/prop-types */
import * as React from 'react';
import Button from '@mui/material/Button';
// eslint-disable-next-line no-unused-vars
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

export default function DropdownMenu({ menuItem, onItemClick }) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const ref = React.useRef(null);
  const handleClose = (item) => {
    setAnchorEl(null);
    setTimeout(() => {
      onItemClick(item);
    }, 500);
  };

  return (
    <div>
      <Button
        ref={ref}
        id={`menu-button-${menuItem?.name}`}
        aria-controls={anchorEl ? `menu-button-${menuItem?.name}` : undefined}
        aria-haspopup="true"
        aria-expanded={anchorEl ? 'true' : undefined}
        variant="text"
        sx={{ whiteSpace: 'nowrap', textTransform: 'capitalize' }}
        disableElevation
        onClick={handleClick}
        endIcon={<KeyboardArrowDownIcon />}
        disabled={menuItem?.disable}
      >
        {menuItem?.name}
      </Button>
      <Menu
        id={`menu-button-${menuItem?.name}`}
        MenuListProps={{
          'aria-labelledby': `menu-button-${menuItem?.name}`,
        }}
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={() => {
          handleClose(menuItem);
        }}
      >
        {menuItem?.children?.map((subMenu) => {
          return (
            <MenuItem
              sx={{ pl: 1.5, pr: 3, width: ref?.current?.offsetWidth }}
              divider={true}
              key={subMenu?.name}
              onClick={() => {
                handleClose(subMenu);
              }}
              disableRipple
            >
              {subMenu?.name}
            </MenuItem>
          );
        })}
      </Menu>
    </div>
  );
}
