const SwalToast = ({ icon: type = 'success', title }) => {
  // @ts-ignore
  window.enqueueSnackbar(title, { variant: type, preventDuplicate: true });
};

export default SwalToast;
