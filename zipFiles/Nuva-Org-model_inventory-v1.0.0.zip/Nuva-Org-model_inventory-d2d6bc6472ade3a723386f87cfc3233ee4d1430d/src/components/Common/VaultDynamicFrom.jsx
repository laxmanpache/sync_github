/* eslint-disable no-use-before-define */
/* eslint-disable camelcase */
/* eslint-disable react/prop-types */
import React, { useEffect } from 'react';
import * as _ from 'lodash';
import { useFormik } from 'formik';
import {
  TextField,
  Box,
  Button,
  Stack,
  Switch,
  Typography,
  FormControl,
  RadioGroup,
  FormLabel,
  FormControlLabel,
  Radio,
  Grid,
} from '@mui/material';
// import convertToYup from 'json-schema-yup-transformer';
import * as Yup from 'yup';
import { createYupSchema } from '../../utils/Utils';

import { DropDown, DropdownItem } from './DropDown';
import Multiselect from './Multiselect';

const AllFields = ({
  attribute,
  name,
  value,
  label,
  formikFrom,
  section,
  sectionName,
  type,
  ...props
}) => {
  switch (type) {
    case 'RADIO':
      return (
        <FormControl>
          <FormLabel id="demo-radio-buttons-group-label">{label}</FormLabel>
          <RadioGroup
            aria-labelledby="demo-radio-buttons-group-label"
            // defaultValue="female"
            onChange={(e) => {
              formikFrom?.setFieldValue(
                `${sectionName?.section_name}.${attribute?.name}`,
                e.target.value
              );
            }}
            {...props}
            value={value}
            row
            name="radio-buttons-group"
          >
            {attribute?.drop_down_options?.length > 0
              ? attribute?.drop_down_options?.map((entity) => {
                  return (
                    <FormControlLabel
                      key={entity}
                      value={entity}
                      control={<Radio />}
                      label={entity}
                    />
                  );
                })
              : null}
          </RadioGroup>
        </FormControl>
      );
    case 'TEXTFIELD':
      return (
        <TextField
          onChange={formikFrom.handleChange}
          name={name}
          type={
            ['Integer', 'Decimal'].includes(attribute?.data_type)
              ? 'number'
              : attribute?.data_type
          }
          label={label}
          value={value}
          {...props}
        />
      );
    case 'CHOICE':
      return (
        <DropDown
          label={label}
          name={name}
          value={value}
          onChange={(e) => {
            formikFrom?.setFieldValue(
              `${sectionName?.section_name}.${attribute?.name}`,
              e.target.value
            );
          }}
          {...props}
        >
          {attribute?.drop_down_options?.length > 0 ? (
            attribute?.drop_down_options?.map((entity) => {
              return (
                <DropdownItem key={3} value={entity}>
                  {entity}
                </DropdownItem>
              );
            })
          ) : (
            <DropdownItem disabled>No options present.</DropdownItem>
          )}
        </DropDown>
      );
    case 'SWITCH':
      return (
        <>
          <Typography
            display="flex"
            justifyContent="center"
            alignItems="center"
          >
            {label}
          </Typography>
          <Stack
            direction="row"
            spacing={1}
            justifyContent="center"
            alignItems="center"
          >
            <Typography>No</Typography>
            <Switch
              name={name}
              checked={value === true}
              onChange={(e) => {
                formikFrom?.setFieldValue(
                  `${sectionName?.section_name}.${attribute?.name}`,
                  e.target.checked
                );
              }}
              //   {...formikForm.getFieldProps('is_unique')}
            />
            <Typography>Yes</Typography>
          </Stack>
        </>
      );
    case 'SINGLE_SELECT':
      return (
        <DropDown
          label={label}
          name={name}
          value={value}
          onChange={(e) => {
            formikFrom?.setFieldValue(
              `${sectionName?.section_name}.${attribute?.name}`,
              e.target.value
            );
          }}
          {...props}
        >
          {attribute?.drop_down_options?.length > 0 ? (
            attribute?.drop_down_options?.map((entity) => {
              return (
                <DropdownItem key={3} value={entity}>
                  {entity}
                </DropdownItem>
              );
            })
          ) : (
            <DropdownItem disabled>No options present.</DropdownItem>
          )}
        </DropDown>
      );
    case 'MULTI_SELECT':
      return (
        <Multiselect
          name={name}
          options={
            attribute?.drop_down_options?.length > 0
              ? attribute?.drop_down_options?.map((entity) => {
                  return { label: entity, value: entity };
                })
              : []
          }
          value={_.isEmpty(value) ? [] : value}
          getOptionLabel={(option) => option?.label}
          isOptionEqualToValue={(option, val) => option?.label === val?.label}
          renderInput={(params) => (
            <TextField {...params} label={label} name={name} {...props} />
          )}
          onChange={(value1) => {
            formikFrom?.setFieldValue(
              `${sectionName?.section_name}.${attribute?.name}`,
              value1
            );
          }}
          {...props}
        />
      );
    default:
  }
};

const VaultDynamicFrom = ({
  fromSchema,
  onFormSubmit,
  attributeDetails = [],
}) => {
  const [initialFormValues, setInitialFormValues] = React.useState({});
  const [vaultSchema, setVaultSchema] = React.useState({});

  // const createValidationSchema = (data11) => {
  //   const formSchema = { type: 'object', properties: {} };
  //   data11?.forEach((section) => {
  //     const sectionSchema = { type: 'object', properties: {} };
  //     const Required = [];
  //     const attributeSchema = {};
  //     section?.attributes?.forEach((attribute) => {
  //       if (!attribute?.is_null) {
  //         Required.push(`${attribute?.name}`);
  //       }
  //       attributeSchema[`${attribute?.name}`] = JSON.parse(
  //         attribute?.yup_schema
  //       );
  //     });
  //     sectionSchema.properties = attributeSchema;
  //     sectionSchema.required = Required;
  //     formSchema.properties[`${section?.section_name}`] = sectionSchema;
  //     formSchema.required = [];
  //   });
  //   try {
  //     const yupSchema = convertToYup(formSchema || {});
  //     return yupSchema;
  //   } catch (error) {
  //     // eslint-disable-next-line no-console
  //     console.log('Form values are invalid', error);
  //   }
  // };
  const initialValues = () => {
    const schema = {};
    const newInitialValues = {};
    fromSchema.forEach((section) => {
      newInitialValues[section.section_name] = {};
      const yepSchema = section?.attributes.reduce(createYupSchema, {});
      schema[section.section_name] = Yup.object().shape(yepSchema);

      section.attributes.forEach((attribute) => {
        newInitialValues[section.section_name][attribute.name] = _.isEmpty(
          attribute?.deafult
        )
          ? attribute?.input_control_type === 'MULTI_SELECT'
            ? []
            : ''
          : attribute?.deafult;
      });
    });
    setInitialFormValues(newInitialValues);

    setVaultSchema(Yup.object().shape(schema));
    return newInitialValues;
  };

  useEffect(() => {
    initialValues();
    // const newInitialValues = {};
    // const yupSchema = createValidationSchema(fromSchema);
    // setVaultSchema(yupSchema);
    // fromSchema.forEach((section) => {
    //   newInitialValues[section.section_name] = {};
    //   section.attributes.forEach((attribute) => {
    //     newInitialValues[section.section_name][attribute.name] = _.isEmpty(
    //       attribute?.deafult
    //     )
    //       ? attribute?.input_control_type === 'MULTI_SELECT'
    //         ? []
    //         : ''
    //       : attribute?.deafult;
    //   });
    // });
    // setInitialFormValues(newInitialValues);
    setTimeout(() => {
      if (Object?.keys(attributeDetails || {})?.length > 0) {
        const updatedValue = {};
        if (Object?.keys(attributeDetails || {})?.length > 0) {
          /*
          - this code is added for re-initialization
          -once in attributeDetails all template and value will come from backend then need to change this one 
          */
          Object?.keys(attributeDetails)?.forEach((obj) => {
            updatedValue[obj] = {
              ...initialFormValues[obj],
              ...attributeDetails[obj],
            };
          });

          // eslint-disable-next-line no-use-before-define
          formik.setValues({ ...updatedValue });
        }
      }
    }, 200);
  }, [fromSchema]);
  const formik = useFormik({
    initialValues: initialFormValues,
    enableReinitialize: true,
    validationSchema: vaultSchema,
    onSubmit: (values) => {
      onFormSubmit(values);
    },
  });
  const resetFormHandler = () => {
    formik.resetForm();
  };

  return (
    <form onSubmit={formik.handleSubmit}>
      {fromSchema?.map((section) => (
        <Box key={section.section_name}>
          <Typography variant="h4" color="initial">
            {section.section_name}
          </Typography>
          <Grid
            item
            xs={12}
            mt={3}
            mb={3}
            display="flex"
            container
            spacing={2}
            wrap="wrap"
          >
            {section.attributes.map((attribute) => {
              return (
                <Grid xs={12} md={6} lg={4} item key={attribute.name}>
                  <AllFields
                    attribute={attribute}
                    sectionName={section}
                    type={attribute?.input_control_type}
                    name={`${section?.section_name}.${attribute?.name}`}
                    label={attribute?.label}
                    formikFrom={formik}
                    error={
                      Boolean(
                        formik?.errors?.[section?.section_name]?.[
                          attribute?.name
                        ]
                      ) &&
                      formik?.touched?.[section?.section_name]?.[
                        attribute?.name
                      ]
                    }
                    helperText={
                      formik?.errors?.[section?.section_name]?.[
                        attribute?.name
                      ] &&
                      formik?.touched?.[section?.section_name]?.[
                        attribute?.name
                      ]
                        ? formik.errors?.[section?.section_name]?.[
                            attribute?.name
                          ]
                        : null
                    }
                    value={
                      formik.values?.[section?.section_name]?.[
                        attribute?.name
                      ] ?? ''
                    }
                  />
                </Grid>
              );
            })}
          </Grid>
        </Box>
      ))}
      <Stack direction="row" spacing={3} justifyContent="center" mt={3}>
        <Button onClick={resetFormHandler}>Reset</Button>
        <Button variant="contained" color="primary" type="submit">
          {Object?.keys(attributeDetails || {})?.length > 0 ? 'SUBMIT' : 'Next'}
        </Button>
      </Stack>
    </form>
  );
};

export { VaultDynamicFrom, AllFields };
