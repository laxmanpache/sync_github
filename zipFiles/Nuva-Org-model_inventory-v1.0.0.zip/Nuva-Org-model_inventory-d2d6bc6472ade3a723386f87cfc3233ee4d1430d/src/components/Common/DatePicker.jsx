/* eslint-disable react/no-unstable-nested-components */
import PropTypes from 'prop-types';
import { TextField } from '@mui/material';
import {
  DatePicker as MuiDatePicker,
  LocalizationProvider,
} from '@mui/x-date-pickers';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';

const DatePicker = ({ error, helperText, ...props }) => {
  return (
    <LocalizationProvider dateAdapter={AdapterMoment}>
      <MuiDatePicker
        {...props}
        components={{
          TextField: (fieldProps) => (
            <TextField {...fieldProps} error={error} helperText={helperText} />
          ),
        }}
      />
    </LocalizationProvider>
  );
};

DatePicker.propTypes = {
  error: PropTypes.bool.isRequired,
  helperText: PropTypes.string.isRequired,
};

export default DatePicker;
