/* eslint-disable camelcase */
import * as Yup from 'yup';
import * as _ from 'lodash';

const createYupSchema = (schema, config) => {
  const {
    name,
    data_type,
    is_null,
    input_control_type,
    yup_schema = [],
  } = config;
  // old created model and association breaking this reason added condition
  if (!_.isArray(yup_schema)) {
    return schema;
  }
  let dataType;
  if (['Character'].includes(data_type)) {
    dataType = 'string';
  } else if (['Integer', 'Decimal'].includes(data_type)) {
    dataType = 'number';
  } else if (data_type === 'Date') {
    dataType = 'date';
  }
  if (input_control_type === 'MULTI_SELECT') {
    dataType = 'array';
  }
  if (!Yup[dataType]) {
    return schema;
  }
  let validator = Yup[dataType]();
  if (is_null) {
    validator = validator.nullable();
  }
  yup_schema?.forEach((validation) => {
    const { params, type } = validation;
    if (!validator[type]) {
      return;
    }

    validator = validator[type](...params);
  });
  // eslint-disable-next-line no-param-reassign
  schema[name] = validator;
  return schema;
};

export { createYupSchema };
