/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import { Box, Button, IconButton, Typography } from '@mui/material';
import { useSearchParams } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import CreateEntitySection from '../../components/Configuration/CreateEntitySection';
import AddAttribute from '../../components/Configuration/AddAttribute';

const data = [
  {
    id: 1,
    name: 'Test sec',
    child: [
      {
        id: 1,
        name: 'no 1of item',
      },
      {
        id: 2,
        name: 'no 2 of item',
      },
      {
        id: 3,
        name: 'no 3 of item',
      },
    ],
  },
];
const EditEntityTemplate = () => {
  const [searchParams] = useSearchParams();
  const IS_SECTION_PRESENT = true;
  const [open, setOpen] = useState(false);
  const handleClose = () => {
    setOpen(!open);
  };
  useEffect(() => {
    console.log(searchParams.get('eid'));
  }, []);

  const moveItem = React.useCallback((dragPath, dropPath) => {
    console.log('Inside of callback');
    console.log(dragPath, dropPath);
  }, []);
  return (
    <Box height="100%">
      <Box
        sx={{
          display: 'flex',
          height: '100%',
          flexDirection: 'column',
        }}
      >
        <Box display="flex" justifyContent="space-between" mb={2}>
          <IconButton
            onClick={() => {
              window.history.back();
            }}
          >
            <ArrowBackIcon />
          </IconButton>
          <Button
            variant="contained"
            onClick={() => {
              setOpen(true);
            }}
          >
            AddAttribute
          </Button>
        </Box>
        <Box mt={4}>
          {IS_SECTION_PRESENT ? (
            <Box
              sx={{
                display: 'flex',
                height: '100%',
                alignItems: 'center',
                justifyContent: 'space-around',
              }}
            >
              <Box width="700px" border={1}>
                {data?.map((entitySection, i) => {
                  return (
                    // eslint-disable-next-line react/no-array-index-key
                    <Box key={i}>
                      <Typography variant="h6">
                        <Typography variant="h6" display="inline">
                          {i + 1}
                          &nbsp;
                        </Typography>
                        {entitySection?.name}
                      </Typography>
                      <Box sx={{ marginLeft: '25px' }}>
                        <DndProvider backend={HTML5Backend}>
                          {entitySection?.child?.map((child, ii) => {
                            return (
                              // eslint-disable-next-line react/no-array-index-key
                              <Box key={ii}>
                                <DragNode
                                  index={`${i + 1}.${ii + 1}`}
                                  ii={ii}
                                  child={child}
                                  moveItem={moveItem}
                                />
                              </Box>
                            );
                          })}
                        </DndProvider>
                      </Box>
                    </Box>
                  );
                })}
              </Box>
            </Box>
          ) : (
            <Box
              sx={{
                display: 'flex',
                height: '100%',
                alignItems: 'center',
                justifyContent: 'space-around',
              }}
            >
              <CreateEntitySection />
            </Box>
          )}
        </Box>
        <AddAttribute open={open} handleClose={handleClose} />
      </Box>
    </Box>
  );
};

export default EditEntityTemplate;

// eslint-disable-next-line react/prop-types
const DragNode = ({ index, ii, child, moveItem }) => {
  const ref = React.useRef(null);
  const [{ isDragging }, drag] = useDrag({
    item: { child, index, ii },
    type: 'NODE',
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  });
  const [{ isOver }, drop] = useDrop({
    accept: 'NODE',
    item: {
      name: 'dfsd',
    },
    drop: (item, monitor) => {
      if (!ref.current) return;
      if (!monitor.getDropResult()) {
        moveItem(item.index, index);
      }
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  });
  drag(drop(ref));
  return (
    <Box
      sx={{
        '&:hover': {
          border: '1px solid',
        },
      }}
    >
      <Box
        textOverflow="ellipsis"
        maxWidth="100%"
        width="fit-content"
        overflow="hidden"
        onClick={{}}
        ref={ref}
        sx={{ opacity: isDragging ? 0.5 : 1 }}
      >
        <Typography noWrap>{`${index} ${child?.name}`}</Typography>
      </Box>
    </Box>
  );
};
