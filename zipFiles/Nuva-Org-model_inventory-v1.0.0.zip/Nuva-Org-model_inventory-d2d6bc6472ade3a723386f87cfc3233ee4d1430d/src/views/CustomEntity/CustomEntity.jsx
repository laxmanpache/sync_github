import React, { useState } from 'react';
import { Box, Grid, Typography, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';

import CreateCustomEntityModal from '../../components/Configuration/CreateCustomEntityModal';

const CustomEntity = () => {
  const [openCreateEntityModal, setOpenCreateEntityModal] = useState(false);
  const history = useNavigate();
  const handleClose = () => {
    setOpenCreateEntityModal(!openCreateEntityModal);
  };
  return (
    <Box>
      <Grid container>
        <Grid
          container
          item
          display="flex"
          justifyContent="space-between"
          xs={12}
        >
          <Box>
            <Typography variant="h2"> Custom Entity</Typography>
          </Box>
          <Box>
            <Button variant="contained" onClick={handleClose}>
              Create Template
            </Button>
          </Box>
        </Grid>
      </Grid>
      <CreateCustomEntityModal
        open={openCreateEntityModal}
        handleClose={(eid = 4) => {
          setOpenCreateEntityModal(!openCreateEntityModal);
          history({
            pathname: '/custom-entity/entity',
            search: `eid=${eid}`,
          });
        }}
        setOpenCreateEntityModal={setOpenCreateEntityModal}
      />
    </Box>
  );
};

export default CustomEntity;
