import React from 'react';

const ModelValidation = () => {
  return <div>ModelValidation</div>;
};

export default ModelValidation;
