/* eslint-disable no-unused-vars */
/* eslint-disable react/no-unstable-nested-components */
import React, { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  Button,
  IconButton,
  Typography,
  Slide,
} from '@mui/material';
import PropTypes from 'prop-types';
import DeleteIcon from '@mui/icons-material/Delete';
import { useNavigate, useSearchParams } from 'react-router-dom';
import VisibilityIcon from '@mui/icons-material/Visibility';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';
import moment from 'moment';
import * as _ from 'lodash';
import Breadcrumb from '../../components/Common/Breadcrumb';
import useEntity from '../../hooks/Configuration/useEntity';
import useModelInventory from '../../hooks/ModelInventory/useModelInventory';
import ReactMuiTableListView from '../../components/Common/ReactMuiTableListView';
import SwalToast from '../../components/Common/SwalTost';
import CreateAssociationModal from '../../components/ModelAssociation/CreateAssociationModal';
import DocumentUploadModal from '../../components/Common/Modals/DocumentUploadModal';
import DeleteModal from '../../components/Common/Modals/DeleteModal';
import SearchTextField from '../../components/Common/SearchTextField';

const columns = [
  {
    heading: 'ID',
    accessor: 'unique_id',
    Cell: ({ row }) => {
      if (row?.original?.unique_id) {
        return row?.original?.unique_id;
      }
      return '-';
    },
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'ASSOCIATION NAME',
    accessor: 'association_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'STATUS',
    accessor: 'status',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 150,
  },
  {
    heading: 'TYPE',
    accessor: 'type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'ASSIGNED USER',
    accessor: 'assignedUser',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'PRIORITY',
    accessor: 'priority',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 150,
  },

  {
    heading: 'CREATED BY',
    accessor: 'created_by',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CREATED DATE',
    accessor: 'created_at',
    Cell: ({ row }) => {
      if (row?.original?.created_at?.includes('/')) {
        return row?.original?.created_at;
      }
      return moment(row?.original?.created_at).format('DD/MM/YYYY');
    },
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];

const RowLevelOnHoverOptions = ({
  containerSx,
  row,
  className,
  deleteModel,
  setAddDocument,
  setAssociationId,
}) => {
  const history = useNavigate();
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            onClick={() => {
              setAssociationId(row?.original?.association_id);
              setAddDocument(true);
            }}
            title="Add document"
          >
            <AttachFileIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            onClick={() => {
              history({
                pathname: `/model-association/${row?.original?.association_id}`,
              });
            }}
            title="View model details"
          >
            <VisibilityIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            title="Delete model"
            onClick={() => {
              deleteModel(row?.original?.association_id);
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  deleteModel: PropTypes.func.isRequired,
  setAddDocument: PropTypes.func.isRequired,
  setAssociationId: PropTypes.func.isRequired,
};

const ModelAssociation = () => {
  const [searchParams] = useSearchParams();

  const { customEntityList, getCustomEntityTemplate } = useEntity();
  const {
    createModelFirstStep,
    createModelSecondStep,
    getAllModelEntity,
    createModelThirdStep,
    createModelForthStep,
    allModelList,
    setAllModelList,
    deleteModelEntity,
    getAllUsers,
    attachDocument,
    getSearchList,
  } = useModelInventory();
  const [open, setOpen] = useState(false);
  const [addDocument, setAddDocument] = useState(false);
  const [associationId, setAssociationId] = useState(null);
  const [allUserList, setAllUserList] = useState([]);
  const [entityList, setEntityList] = useState([]);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedEntityIdForDelete, setSelectedEntityIdForDelete] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');

  const getModelDetails = () => {
    getAllModelEntity({ entityType: 'ModelAssociation' }).then((res) => {
      setAllModelList(res?.data?.modelEntity);
    });
  };

  const fetchData = () => {
    if (searchTerm.trim().length > 0) {
      getSearchList({ text: searchTerm, entityType: 'ModelAssociation' }).then(
        (res) => {
          setAllModelList(res.data);
        }
      );
    } else {
      getModelDetails();
    }
  };

  const debouncedFetchData = _.debounce(fetchData, 500);

  useEffect(() => {
    debouncedFetchData();
    return () => {
      debouncedFetchData.cancel();
    };
  }, [searchTerm.trim()]);

  useEffect(() => {
    getAllModelEntity({ entityType: 'ModelAssociation' });
    customEntityList().then((res) => {
      if (res) {
        setEntityList(
          res?.data?.filter(
            (entity) => entity?.entity_type === 'ModelAssociation'
          )
        );
      }
    });
    getAllUsers().then((res) => {
      if (res) {
        setAllUserList(res?.data);
      }
    });
  }, []);

  const deleteModel = (entityId = 0) => {
    setSelectedEntityIdForDelete(entityId);
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
  };

  const deleteConfirm = () => {
    deleteModelEntity({
      entityType: 'ModelAssociation',
      entityId: selectedEntityIdForDelete,
    }).then((res) => {
      if (res) {
        getAllModelEntity({ entityType: 'ModelAssociation' });
        SwalToast({
          icon: 'success',
          title: 'Association deleted successfully.',
        });
        closeDeleteModal();
      }
    });
  };

  return (
    <Box sx={{ background: (theme) => theme.palette.primary }}>
      <Grid container xs={12} rowGap={2}>
        <Grid item xs={12} display="flex" justifyContent="space-between">
          <Box>
            <Breadcrumb />
          </Box>
          <Button
            variant="contained"
            onClick={() => {
              setOpen(true);
            }}
          >
            Create Association
          </Button>
        </Grid>
        <Grid item xs={12} flexDirection="column" justifyContent="space-evenly">
          <Box mb={2}>
            <SearchTextField
              value={searchTerm}
              onChange={(e) => setSearchTerm(e?.target?.value)}
              placeholder="Search"
            />
          </Box>
          <Box
            display="flex"
            flexDirection="row"
            sx={{
              height: `calc(100vh - 310px)`,
            }}
          >
            <Box
              display="flex"
              flexGrow={1}
              flexDirection="column"
              overflow="auto"
            >
              {allModelList?.length > 0 ? (
                <Slide direction="left" timeout={1000} mountOnEnter in={true}>
                  <Box>
                    <ReactMuiTableListView
                      data={
                        allModelList?.length > 0
                          ? allModelList?.filter((association) =>
                              searchParams?.get('templateName')
                                ? association.type ===
                                  searchParams?.get('templateName')
                                : true
                            )
                          : []
                      }
                      columns={columns}
                      rowLevelOnHoverOptions={({
                        containerSx,
                        row,
                        className,
                      }) => {
                        return (
                          <RowLevelOnHoverOptions
                            containerSx={containerSx}
                            row={row}
                            className={className}
                            deleteModel={deleteModel}
                            setAssociationId={setAssociationId}
                            setAddDocument={setAddDocument}
                          />
                        );
                      }}
                      getHeaderProps={() => ({
                        style: {
                          display: 'flex',
                          alignItems: 'center',
                        },
                      })}
                      getRowProps={() => ({
                        style: {
                          position: 'relative',
                        },
                      })}
                      enableRowSelection={false}
                      pageCount={allModelList?.length}
                      enablePagination={true}
                      initialPageSize={10}
                      rowsPerPageOptions={[5, 10, 15]}
                    />
                  </Box>
                </Slide>
              ) : (
                <Box
                  display="flex"
                  style={{ height: 'calc(100vh  - 500px)' }}
                  flexGrow={1}
                  alignItems="center"
                  flexDirection="column"
                  justifyContent="center"
                >
                  <Typography variant="subtitle1">
                    No data result found.
                  </Typography>
                </Box>
              )}
            </Box>
          </Box>
        </Grid>
      </Grid>
      <CreateAssociationModal
        open={open}
        setOpen={setOpen}
        entityList={entityList}
        typeOfEntity="ModelAssociation"
        createModelFirstStep={createModelFirstStep}
        getCustomEntityTemplate={getCustomEntityTemplate}
        createModelSecondStep={createModelSecondStep}
        getAllModelEntity={getAllModelEntity}
        createModelThirdStep={createModelThirdStep}
        createModelForthStep={createModelForthStep}
        allUserList={allUserList}
        attachDocument={attachDocument}
      />
      <DocumentUploadModal
        open={addDocument}
        handleClose={() => {
          setAddDocument(false);
        }}
        isMultiple={false}
        enitityType="ModelAssociation"
        entityId={associationId}
        attachDocument={attachDocument}
      />
      <DeleteModal
        open={isDeleteModalOpen}
        handleClose={closeDeleteModal}
        deleteConfirm={deleteConfirm}
        alertLabelText="Do you want to delete this Association?"
      />
    </Box>
  );
};

export default ModelAssociation;
