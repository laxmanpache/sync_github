/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
/* eslint-disable react/no-unstable-nested-components */
import React, { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  Button,
  Typography,
  Divider,
  Tabs,
  Tab,
  TextField,
  IconButton,
  Stack,
  Slide,
} from '@mui/material';
import * as _ from 'lodash';
import { useSelector } from 'react-redux';
import InputAdornment from '@mui/material/InputAdornment';
import SearchIcon from '@mui/icons-material/Search';
import { useNavigate, useParams } from 'react-router-dom';
import { styled } from '@mui/material/styles';
import DeleteIcon from '@mui/icons-material/Delete';
import PropTypes from 'prop-types';
import moment from 'moment';
import useMediaQuery from '@mui/material/useMediaQuery';
import VisibilityIcon from '@mui/icons-material/Visibility';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';

import { useTheme } from '@emotion/react';
import Breadcrumb from '../../components/Common/Breadcrumb';
import { TabPanel } from '../../components/Common/Tabs';
import useModelInventory from '../../hooks/ModelInventory/useModelInventory';
import ReactMuiTableListView from '../../components/Common/ReactMuiTableListView';
import AddTeamMember from '../../components/ModelAssociation/AddTeamMember';
import AddAssociationModal from '../../components/ModelAssociation/AddAssociationModal';
// import EditModelAttributesDetails from '../../components/ModelAssociation/EditModelAttributeDetaisl';
import useEntity from '../../hooks/Configuration/useEntity';
import SwalToast from '../../components/Common/SwalTost';
import DocumentUploadModal from '../../components/Common/Modals/DocumentUploadModal';
import Notes from '../../components/Common/ModelInventoryAndAssociation/Notes';
import ModelDetails from '../../components/Common/ModelInventoryAndAssociation/ModelDetails';
import Summary from '../../components/Common/ModelInventoryAndAssociation/Summary';
import Alerts from '../../components/Common/ModelInventoryAndAssociation/Alerts';
import ModelAssociation from '../../components/Common/ModelInventoryAndAssociation/ModelAssociation';
import CreateAddAssociation from '../../components/Common/ModelInventoryAndAssociation/Modals/CreateAddAssociation';
import DeleteModal from '../../components/Common/Modals/DeleteModal';

const ActionTab = styled(Tab)(({ theme }) => ({
  minHeight: '25px',
  marginBottom: '5px',
  display: 'flex',
  justifyContent: 'flex-start',
  padding: '8px',
  color: theme.palette.primary.main,
  '&.Mui-selected': {
    backgroundColor: theme.palette.primary.main,
    borderRadius: '3px',
    color: `${theme.palette.text.light} !important`,
  },
}));
const ActionTabPanel = styled(TabPanel)(() => ({
  padding: '24px',
  paddingTop: '0px',
  width: '100%',
}));
const CustomTextField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-input': {
    padding: '10px !important',
  },
  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      borderColor: theme.palette.primary.main,
    },
  },
}));

const columns = [
  {
    heading: 'USER',
    accessor: 'user',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'TYPE',
    accessor: 'type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'ROLE',
    accessor: 'role',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'EMAIL',
    accessor: 'user_email',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];
const AssociationColumns = [
  {
    heading: 'ASSOCIATION ID',
    accessor: 'associated_id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'ASSOCIATION NAME',
    accessor: 'association_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'ASSOCIATION TYPE',
    accessor: 'association_type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CREATED BY',
    accessor: 'created_at',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
    Cell: ({ row }) =>
      moment(new Date(row.original.created_at)).format('YYY/DD/MM'),
  },
  {
    heading: 'CREATED BY',
    accessor: 'created_by',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];
const ModelHistoryColumns = [
  {
    // Make an expander cell
    Header: () => null, // No header
    id: 'expander', // It needs an ID
    // eslint-disable-next-line react/prop-types
    Cell: ({ row }) => (
      // Use Cell to render an expander for each row.
      // We can use the getToggleRowExpandedProps prop-getter
      // to build the expander.
      <span {...row.getToggleRowExpandedProps()}>
        {row.isExpanded ? (
          <KeyboardArrowDownIcon />
        ) : (
          <KeyboardArrowRightIcon />
        )}
      </span>
    ),
  },
  {
    heading: 'MODEL ID',
    accessor: 'entity_id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'MODEL TYPE',
    accessor: 'entity_type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'ACTION',
    accessor: 'action',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CHANGED DATE',
    accessor: 'modification_date',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
    Cell: ({ row }) =>
      moment(new Date(row.original.modification_date)).format('YYYY/DD/MM'),
  },
];
const SUMMARY_LABELS = {
  type: 'Type',
  assignedUser: 'Assigned User',
  association_name: 'Association Name',
  association_id: 'Association Id',
  created_at: 'Created At',
  updated_at: 'Updated At',
  created_by: 'Created By',
  updated_by: 'Updated By',
  description: 'Description',
  priority: 'Priority',
};

// eslint-disable-next-line no-unused-vars
const RowLevelOnHoverOptions = ({
  containerSx,
  row,
  className,
  removeTeamMember,
  assId,
  getTeamDetails,
}) => {
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          {row?.original?.role !== 'Primary Owner' ? (
            <IconButton
              size="small"
              title="Remove team member"
              onClick={() => {
                removeTeamMember({
                  entity_type: 'ModelInventory',
                  entity_id: assId,
                  username: row?.original?.user,
                  role: row?.original?.role,
                }).then(() => {
                  getTeamDetails({
                    entityType: 'ModelInventory',
                    entityId: assId,
                  });
                  SwalToast({
                    icon: 'success',
                    title: 'Team member removed successfully.',
                  });
                });
              }}
            >
              <DeleteIcon color="primary" />
            </IconButton>
          ) : null}
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  assId: PropTypes.number.isRequired,
  removeTeamMember: PropTypes.func.isRequired,
  getTeamDetails: PropTypes.func.isRequired,
};
const RowLevelOnHoverAssociationOptions = ({
  containerSx,
  row,
  className,
  removeModelAssociation,
  assId,
  getAssociationDetails,
  setValue,
}) => {
  const history = useNavigate();
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            onClick={() => {
              history({
                pathname: `/model-association/${row?.original?.associated_id}`,
                // search: `assId=${row?.original?.associated_id}`,
              });
              setValue(1);
            }}
            title="View model details"
          >
            <VisibilityIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            title="Delete Team Association"
            onClick={() => {
              removeModelAssociation({
                entity_type: 'ModelInventory',
                entity_id: assId,
                associated_id: row?.original?.associated_id,
                association_type: row?.original?.association_type,
              }).then(() => {
                SwalToast({
                  icon: 'success',
                  title: 'Association removed successfully.',
                });
                getAssociationDetails({
                  entityType: 'ModelAssociation',
                  entityId: assId,
                });
              });
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverAssociationOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  removeModelAssociation: PropTypes.func.isRequired,
  getAssociationDetails: PropTypes.func.isRequired,
  setValue: PropTypes.func.isRequired,
  assId: PropTypes.number.isRequired,
};
const SUB_HISTORY_COLUMNS = [
  {
    heading: 'CHANGED FIELD',
    accessor: 'feild',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'PREVIOUS VALUE',
    accessor: 'previous_value',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
    Cell: ({ row }) => (
      <span>
        {_.isEmpty(row?.original?.previous_value)
          ? '-'
          : row?.original?.previous_value}
      </span>
    ),
  },
  {
    heading: 'CURRENT VALUE',
    accessor: 'current_value',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];
const RowLevelOnHoverDocumentOptions = ({
  containerSx,
  row,
  className,
  deleteAttchedDocument,
  entityId,
  entityType,
}) => {
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            title="View attached document"
            onClick={() => {
              window.open(row?.original?.fileurl, '_blank');
            }}
          >
            <VisibilityIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            title="Delete attached document"
            onClick={() => {
              deleteAttchedDocument({
                documentId: row?.original?.document_id,
                entityId,
                entityType,
              }).then(() => {
                SwalToast({
                  icon: 'success',
                  title: 'Associated model removed successfully.',
                });
              });
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverDocumentOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  deleteAttchedDocument: PropTypes.func.isRequired,
  entityId: PropTypes.number.isRequired,
  entityType: PropTypes.string.isRequired,
};
const DocumentColumns = [
  {
    heading: 'DOCUMENT ID',
    accessor: 'document_id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'DOCUMENT NAME',
    accessor: 'document_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'DOCUMENT DESCRIPTION',
    accessor: 'document_description',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'DOCUMENT AUTHOR',
    accessor: 'document_author',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'UPLOADED AT',
    accessor: 'uploaded_at',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    Cell: ({ row }) =>
      moment(new Date(row.original.uploaded_at)).format('YYYY/DD/MM'),
    width: 200,
  },
  {
    heading: 'Version',
    accessor: 'version',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
];
const EditModelAssociation = () => {
  const theme = useTheme();
  const { getCustomEntityTemplate } = useEntity();
  const { userData } = useSelector((state) => state.users);
  const {
    getAttributeDetails,
    getTeamDetails,
    teamDetails,
    getAllModelEntity,
    createModelThirdStep,
    getAssociationDetails,
    associationDetails,
    createModelSecondStep,
    addSingleTeamMember,
    getAllUsers,
    sendForApproval,
    getAllRoles,
    removeTeamMember,
    removeModelAssociation,
    getSingleEntityDetails,
    deleteModelEntity,
    getHistory,
    fetchDocumentsList,
    documentsList,
    attachDocument,
    deleteAttchedDocument,
    getAllNotes,
    addNote,
    getAllAlerts,
    deleteAlert,
    updateAlerts,
    createAlerts,
    updateModelEntity,
  } = useModelInventory();
  const isMd = useMediaQuery(theme.breakpoints.down('md'));
  // const [attributeDetails, setAttributeDetails] = useState([]);
  const [fromDetails, setFormDetails] = useState([]);
  const [AddMember, setAddMember] = useState(false);
  const [addAssociation, setAddAssociation] = useState(false);
  const [addDocument, setAddDocument] = useState(false);
  const [currentModel, setCurrentModel] = useState({});
  // const [editModelDetails, setEditModelDetails] = useState(false);
  const [allUserList, setAllUserList] = useState([]);
  const [allUserRoles, setAllUserRoles] = useState([]);
  const [modelHistory, setModelHistory] = useState([]);
  const [createAndAddAssociation, setCreateAndAddAssociation] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedEntityIdForDelete, setSelectedEntityIdForDelete] = useState(0);
  const [value, setValue] = useState(1);

  const history = useNavigate();
  const { assId } = useParams();

  const getAssoDetails = () => {
    getSingleEntityDetails({
      entityType: 'ModelAssociation',
      entityId: Number(assId),
    }).then((res) => {
      if (res) {
        setCurrentModel(res?.data?.modelEntity);
      }
    });
  };

  React.useMemo(() => {
    getAssoDetails();

    getAllUsers().then((res) => {
      if (res) {
        setAllUserList(res?.data);
      }
    });
    getAllRoles().then((res) => {
      if (res) {
        setAllUserRoles(res?.data);
      }
    });
    fetchDocumentsList({
      entityType: 'ModelAssociation',
      entityId: Number(assId),
    });
  }, [assId]);

  useEffect(() => {
    if (currentModel?.type)
      getCustomEntityTemplate({
        entityName: currentModel?.type,
      }).then((resp) => {
        if (resp) {
          setFormDetails(resp?.data?.Entity?.[currentModel?.type]?.sections);
        }
      });
    getHistory({
      entityType: 'ModelAssociation',
      entityId: Number(assId),
    }).then((res) => {
      if (res) {
        setModelHistory(res?.data?.history);
      }
    });
  }, [currentModel]);
  useEffect(() => {
    if (assId) {
      // getAttributeDetails({
      //   entityType: 'ModelAssociation',
      //   entityId: assId,
      // }).then((res) => {
      //   if (res) {
      //     setAttributeDetails(res?.data?.data);
      //   }
      // });
      getTeamDetails({
        entityType: 'ModelAssociation',
        entityId: assId,
      });
      getAssociationDetails({
        entityType: 'ModelAssociation',
        entityId: assId,
      });
    }
  }, [assId]);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const SendModelForNextStage = (status) => {
    sendForApproval({
      entity_id: assId,
      entity_type: 'ModelAssociation',
      approved: status,
    }).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: `Model ${status ? 'approved' : 'rejected'} Successfully.`,
        });
      }
    });
  };

  const deleteModel = (entityId = 0) => {
    setSelectedEntityIdForDelete(entityId);
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
  };

  const deleteConfirm = () => {
    deleteModelEntity({
      entityType: 'ModelAssociation',
      entityId: selectedEntityIdForDelete,
    }).then((res) => {
      if (res) {
        getAllModelEntity({ entityType: 'ModelAssociation' });
        history({
          pathname: '/model-association',
        });
        SwalToast({
          icon: 'success',
          title: 'Association deleted successfully.',
        });
        closeDeleteModal();
      }
    });
  };

  const renderRowSubComponent = React.useCallback(
    ({ row }) => (
      <Box
        width="100%"
        mt={2}
        mb={2}
        p={2}
        borderRadius={2}
        sx={{
          borderWidth: 1,
          borderStyle: 'solid',
          borderColor: theme.palette.primary.main,
        }}
      >
        <ReactMuiTableListView
          data={
            row?.original?.changes?.length > 0 ? row?.original?.changes : []
          }
          columns={SUB_HISTORY_COLUMNS}
          getHeaderProps={() => ({
            style: {
              display: 'flex',
              alignItems: 'center',
            },
          })}
          rowLevelOnHoverOptions={() => <span />}
          getRowProps={() => ({
            style: {
              position: 'relative',
            },
          })}
          enableRowSelection={false}
          initialPageSize={7}
          rowsPerPageOptions={[5, 7, 10, 15]}
        />
      </Box>
    ),
    []
  );

  return (
    <Box>
      <Grid container xs={12} rowGap={2}>
        <Grid item xs={12} display="flex" justifyContent="space-between">
          <Box>
            <Breadcrumb />
          </Box>
        </Grid>
        <Grid item xs={12} display="flex" flexDirection="column">
          <Box
            sx={{ height: `calc(100vh - 235px)` }}
            display="flex"
            overflow="hidden"
            flexDirection={isMd ? 'column' : 'row'}
          >
            <Box pr={1} overflow="auto">
              <Tabs
                value={value}
                onChange={handleChange}
                orientation={isMd ? 'horizontal' : 'vertical'}
                variant="scrollable"
                sx={() => {
                  return {
                    border: 'none',
                    '& .MuiTabs-indicator ': {
                      display: 'none',
                    },
                  };
                }}
              >
                <Typography mt={1} mb={2} mr={1}>
                  Actions
                </Typography>
                <ActionTab title="Summary" label="Summary" />
                <ActionTab title="Details" label="Details" />
                <ActionTab title="Preview" label="Preview" />
                <ActionTab title="Association" label="Association" />
                <ActionTab title="Team" label="Team" />
                <ActionTab title="Notes" label="Notes" />
                <ActionTab title="History" label="History" />
                <ActionTab label="Alerts" title="Alerts" />
              </Tabs>
            </Box>
            <Divider
              sx={{
                backgroundColor: (_theme) => _theme.palette.other.grey1,
              }}
              mr={2}
              orientation={isMd ? 'horizontal' : 'vertical'}
            />

            <Box
              display="flex"
              flex={1}
              flexDirection="column"
              mt={isMd ? 3 : 0}
              sx={{ overflow: 'auto' }}
            >
              <ActionTabPanel height="100%" value={value} index={1} sx={{}}>
                <Box display="flex">
                  <Summary
                    summaryLabels={SUMMARY_LABELS}
                    currentModel={currentModel}
                    allUserList={teamDetails?.team_member}
                    entityType="ModelAssociation"
                    updateModelEntity={updateModelEntity}
                    getModelDetails={getAssoDetails}
                  />
                  <Box>
                    {userData?.username === currentModel?.assignedUser ? (
                      <Stack
                        mt={10}
                        direction="row"
                        display="flex"
                        position="fixed"
                        bottom={25}
                        right={25}
                        justifyContent="flex-end"
                        spacing={3}
                      >
                        <Button
                          variant="outlined"
                          onClick={() => {
                            deleteModel(currentModel?.model_id);
                          }}
                        >
                          DELETE
                        </Button>

                        {/* <Button
                          variant="outlined"
                          onClick={() => {
                            setEditModelDetails(true);
                          }}
                        >
                          EDIT
                        </Button> */}
                        {currentModel.status !== 'Draft' ? (
                          <>
                            <Button
                              variant="outlined"
                              onClick={() => {
                                SendModelForNextStage(false);
                              }}
                            >
                              DISCARD
                            </Button>
                            <Button
                              variant="outlined"
                              onClick={() => {
                                SendModelForNextStage(true);
                              }}
                            >
                              PROCEED
                            </Button>
                          </>
                        ) : (
                          <Button
                            variant="outlined"
                            onClick={() => {
                              SendModelForNextStage(true);
                            }}
                          >
                            SEND FOR APPROVAL
                          </Button>
                        )}
                        <Button variant="contained">SYNC WITH NIMBUS</Button>
                      </Stack>
                    ) : null}
                  </Box>
                </Box>
              </ActionTabPanel>
              <ActionTabPanel value={value} index={2}>
                {value === 2 ? (
                  <ModelDetails
                    getAttributeDetails={getAttributeDetails}
                    entityId={assId}
                    entityType="ModelAssociation"
                    fromDetails={fromDetails}
                    createModelSecondStep={createModelSecondStep}
                  />
                ) : null}
              </ActionTabPanel>
              <ActionTabPanel value={value} index={3}>
                <Grid container item xs={12} spacing={4}>
                  <Grid container item xs={12} spacing={2}>
                    <Grid item xs={7} sm={8} md={9} lg={10} xl={10} flexGrow>
                      <CustomTextField
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton>
                                <SearchIcon />
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                        sx={{}}
                        placeholder="Search filter"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={5}
                      sm={4}
                      md={3}
                      lg={2}
                      xl={2}
                      display="flex"
                      justifyContent="flex-end"
                    >
                      <Button
                        variant="contained"
                        onClick={() => {
                          setAddDocument((data) => !data);
                        }}
                        sx={{ whiteSpace: 'nowrap' }}
                      >
                        Add Document
                      </Button>
                    </Grid>
                  </Grid>
                  <Grid item xs={12}>
                    {documentsList?.length > 0 ? (
                      <Slide
                        direction="left"
                        timeout={1000}
                        mountOnEnter
                        in={value === 3}
                      >
                        <Box>
                          <ReactMuiTableListView
                            data={
                              documentsList?.length > 0 ? documentsList : []
                            }
                            columns={DocumentColumns}
                            rowLevelOnHoverOptions={({
                              containerSx,
                              row,
                              className,
                            }) => {
                              return (
                                <RowLevelOnHoverDocumentOptions
                                  containerSx={containerSx}
                                  row={row}
                                  className={className}
                                  deleteAttchedDocument={deleteAttchedDocument}
                                  entityType="ModelAssociation"
                                  entityId={assId}
                                />
                              );
                            }}
                            getHeaderProps={() => ({
                              style: {
                                display: 'flex',
                                alignItems: 'center',
                              },
                            })}
                            getRowProps={() => ({
                              style: {
                                position: 'relative',
                              },
                            })}
                            enableRowSelection={false}
                            pageCount={associationDetails?.Association?.length}
                            enablePagination={true}
                            initialPageSize={10}
                            rowsPerPageOptions={[5, 10, 15]}
                          />
                        </Box>
                      </Slide>
                    ) : (
                      <Box
                        display="flex"
                        style={{ height: 'calc(100vh  - 300px)' }}
                        flexGrow={1}
                        alignItems="center"
                        flexDirection="column"
                        justifyContent="center"
                      >
                        <Typography variant="subtitle1">
                          No data result found.
                        </Typography>
                      </Box>
                    )}
                  </Grid>
                </Grid>
              </ActionTabPanel>
              <ActionTabPanel value={value} index={4} sx={{}}>
                <Grid container item xs={12} spacing={4}>
                  <Grid container item xs={12} spacing={2}>
                    <Grid item xs={3} sm={4} md={5} lg={7} xl={8} flexGrow>
                      <CustomTextField
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton>
                                <SearchIcon />
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                        sx={{}}
                        placeholder="Search filter"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={9}
                      sm={8}
                      md={7}
                      lg={5}
                      xl={4}
                      display="flex"
                      justifyContent="flex-end"
                    >
                      <Button
                        variant="contained"
                        onClick={() => {
                          setCreateAndAddAssociation(!createAndAddAssociation);
                        }}
                        sx={{ whiteSpace: 'nowrap', marginRight: '10px' }}
                      >
                        Create & Add Association
                      </Button>
                      <Button
                        variant="contained"
                        onClick={() => {
                          setAddAssociation(!addAssociation);
                        }}
                        sx={{ whiteSpace: 'nowrap' }}
                      >
                        Link Association
                      </Button>
                    </Grid>
                  </Grid>
                  <Grid item xs={12}>
                    <ModelAssociation
                      value={value}
                      association={associationDetails?.Association}
                      setValue={setValue}
                      removeModelAssociation={removeModelAssociation}
                      getAssociationDetails={getAssociationDetails}
                      entityId={Number(assId)}
                      entityType="ModelAssociation"
                    />
                  </Grid>
                </Grid>
              </ActionTabPanel>
              <ActionTabPanel value={value} index={5} sx={{}}>
                <Grid container item xs={12} spacing={4}>
                  <Grid container item xs={12} spacing={2}>
                    <Grid item xs={7} sm={8} md={9} lg={10} xl={10} flexGrow>
                      <CustomTextField
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton>
                                <SearchIcon />
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                        sx={{}}
                        placeholder="Search filter"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={5}
                      sm={4}
                      md={3}
                      lg={2}
                      xl={2}
                      display="flex"
                      justifyContent="flex-end"
                    >
                      <Button
                        variant="contained"
                        onClick={() => {
                          setAddMember(!AddMember);
                        }}
                        sx={{ whiteSpace: 'nowrap' }}
                      >
                        Add Member
                      </Button>
                    </Grid>
                  </Grid>
                  <Grid item xs={12}>
                    <Slide
                      direction="left"
                      timeout={1000}
                      mountOnEnter
                      in={value === 5}
                    >
                      <Box>
                        <ReactMuiTableListView
                          data={
                            teamDetails?.team_member?.length
                              ? teamDetails?.team_member
                              : []
                          }
                          columns={columns}
                          rowLevelOnHoverOptions={({
                            containerSx,
                            row,
                            className,
                          }) => {
                            return (
                              <RowLevelOnHoverOptions
                                containerSx={containerSx}
                                row={row}
                                className={className}
                                removeTeamMember={removeTeamMember}
                                assId={Number(assId)}
                                getTeamDetails={getTeamDetails}
                              />
                            );
                          }}
                          getHeaderProps={() => ({
                            style: {
                              display: 'flex',
                              alignItems: 'center',
                            },
                          })}
                          getRowProps={() => ({
                            style: {
                              position: 'relative',
                            },
                          })}
                          enableRowSelection={false}
                          pageCount={teamDetails?.team_member?.length}
                          enablePagination={true}
                          initialPageSize={10}
                          rowsPerPageOptions={[5, 10, 15]}
                        />
                      </Box>
                    </Slide>
                  </Grid>
                </Grid>
              </ActionTabPanel>
              <ActionTabPanel value={value} index={6} sx={{ padding: '24px' }}>
                <Notes
                  getAllNotes={getAllNotes}
                  addNote={addNote}
                  entityType="ModelAssociation"
                  entityId={assId}
                />
              </ActionTabPanel>
              <ActionTabPanel value={value} index={7} sx={{ padding: '24px' }}>
                <Grid item container xs={12} rowSpacing={2}>
                  <Grid item xs={12} md={10}>
                    <Typography variant="h4">Model History</Typography>
                  </Grid>
                  <Grid item xs={12} md={10}>
                    <Divider
                      sx={{
                        backgroundColor: (_theme) => _theme.palette.other.grey1,
                      }}
                      light
                      orientation="horizontal"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Slide
                      direction="left"
                      timeout={1000}
                      mountOnEnter
                      in={value === 7}
                    >
                      <Box>
                        <ReactMuiTableListView
                          data={modelHistory?.length > 0 ? modelHistory : []}
                          columns={ModelHistoryColumns}
                          rowLevelOnHoverOptions={({
                            containerSx,
                            row,
                            className,
                          }) => {
                            return null;
                          }}
                          getHeaderProps={() => ({
                            style: {
                              display: 'flex',
                              alignItems: 'center',
                            },
                          })}
                          getRowProps={() => ({
                            style: {
                              position: 'relative',
                            },
                          })}
                          renderRowSubComponent={renderRowSubComponent}
                          enableRowSelection={false}
                          pageCount={modelHistory?.length}
                          enablePagination={true}
                          initialPageSize={10}
                          rowsPerPageOptions={[5, 10, 15]}
                        />
                      </Box>
                    </Slide>
                  </Grid>
                </Grid>
              </ActionTabPanel>
              <ActionTabPanel value={value} index={8} sx={{ padding: '24px' }}>
                <Alerts
                  value={value}
                  getAllAlerts={getAllAlerts}
                  entityType="ModelAssociation"
                  entityId={Number(assId)}
                  deleteAlert={deleteAlert}
                  allUserList={allUserList}
                  updateAlerts={updateAlerts}
                  createAlerts={createAlerts}
                />
              </ActionTabPanel>
            </Box>
          </Box>
        </Grid>
      </Grid>
      <AddTeamMember
        open={AddMember}
        handleClose={() => {
          setAddMember(false);
        }}
        entityId={Number(assId)}
        addSingleTeamMember={addSingleTeamMember}
        allUserList={allUserList}
        allUserRoles={allUserRoles}
        getAssoTeamDetails={() => {
          getTeamDetails({
            entityType: 'ModelAssociation',
            entityId: assId,
          });
        }}
      />
      <CreateAddAssociation
        open={createAndAddAssociation}
        handleClose={() => {
          setCreateAndAddAssociation(false);
        }}
        entityId={Number(assId)}
        getAssociationDetails={getAssociationDetails}
        currentEntityType="ModelAssociation"
        getAllAssociation={() => {
          getAssociationDetails({
            entityType: 'ModelAssociation',
            entityId: assId,
          });
        }}
      />
      <AddAssociationModal
        open={addAssociation}
        handleClose={() => {
          setAddAssociation(false);
        }}
        getAllModelEntity={getAllModelEntity}
        createModelThirdStep={createModelThirdStep}
        entityId={Number(assId)}
        getAllAssociation={() => {
          getAssociationDetails({
            entityType: 'ModelAssociation',
            entityId: assId,
          });
        }}
      />
      {/* <EditModelAttributesDetails
        open={editModelDetails}
        attributeDetails={attributeDetails}
        handleClose={() => {
          setEditModelDetails(!editModelDetails);
        }}
        createModelSecondStep={createModelSecondStep}
        entityId={Number(assId)}
        fromDetails={fromDetails}
      /> */}
      <DocumentUploadModal
        open={addDocument}
        handleClose={() => {
          setAddDocument(false);
        }}
        isMultiple={false}
        enitityType="ModelAssociation"
        entityId={Number(assId)}
        attachDocument={attachDocument}
      />
      <DeleteModal
        open={isDeleteModalOpen}
        handleClose={closeDeleteModal}
        deleteConfirm={deleteConfirm}
        alertLabelText="Do you want to delete this Association?"
      />
    </Box>
  );
};

export default EditModelAssociation;
