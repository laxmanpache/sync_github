/* eslint-disable react/no-unstable-nested-components */
import React, { useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Button,
  IconButton,
  Typography,
  Slide,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import DeleteIcon from '@mui/icons-material/Delete';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import PropTypes from 'prop-types';

import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';
import CreateCustomEntityModal from '../../components/Configuration/CreateCustomEntityModal';
import Breadcrumb from '../../components/Common/Breadcrumb';
import ReactMuiTableListView from '../../components/Common/ReactMuiTableListView';
import useEntity from '../../hooks/Configuration/useEntity';
import useWorkflow from '../../hooks/Configuration/useWorkflow';
import SwalToast from '../../components/Common/SwalTost';
import SearchTextField from '../../components/Common/SearchTextField';
import DeleteModal from '../../components/Common/Modals/DeleteModal';

const columns = [
  {
    heading: ' TEMPLATE NAME',
    accessor: 'entity_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'TEMPLATE TYPE',
    accessor: 'entity_type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'WORKFLOW NAME',
    accessor: 'workflow',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'DESCRIPTION',
    accessor: 'description',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];

const RowLevelOnHoverOptions = ({
  containerSx,
  row,
  className,
  deleteTemplateHandler,
}) => {
  const history = useNavigate();
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            onClick={() => {
              history({
                pathname: '/configuration/create-template',
                search: `eid=${row?.original?.entity_name}`,
              });
            }}
            title="Edit template"
          >
            <BorderColorIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            title="Delete Template"
            onClick={() => {
              deleteTemplateHandler(row?.original?.entity_name);
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};

RowLevelOnHoverOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  deleteTemplateHandler: PropTypes.func.isRequired,
};

const TemplateList = () => {
  const {
    customEntityList,
    createCustomEntity,
    attachWorkflow,
    deleteTemplate,
  } = useEntity();
  const { getWorkflowList } = useWorkflow();

  const [entityList, setEntityList] = useState([]);
  const [workflowList, setWorkflowList] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [openCreateEntityModal, setOpenCreateEntityModal] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedWorkflowForDelete, setSelectedWorkflowForDelete] = useState(0);

  const history = useNavigate();

  const fetchEntityList = () => {
    customEntityList().then((res) => {
      if (res) {
        setEntityList(res?.data);
      }
    });
  };

  useEffect(() => {
    fetchEntityList();
    getWorkflowList().then((res) => {
      if (res) {
        setWorkflowList(res?.data);
      }
    });
  }, []);

  const deleteTemplateHandler = (entityName) => {
    setSelectedWorkflowForDelete(entityName);
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
  };

  const deleteConfirm = () => {
    deleteTemplate({ entityName: selectedWorkflowForDelete }).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: 'Template deleted successfully.',
        });
        fetchEntityList();
        closeDeleteModal();
      }
    });
  };

  const handleClose = () => {
    setOpenCreateEntityModal(!openCreateEntityModal);
  };

  const BreadcrumbsMenu = [
    { id: 1, name: 'Configuration', path: '/configuration' },
    { id: 2, name: 'Template List' },
  ];

  return (
    <Box>
      <Grid container spacing={1}>
        <Grid item display="flex" justifyContent="space-between" xs={12}>
          <Box>
            <Breadcrumb BreadcrumbsMen={BreadcrumbsMenu} />
          </Box>
          <Box>
            <Button variant="contained" onClick={handleClose}>
              CREATE TEMPLATE
            </Button>
          </Box>
        </Grid>
        <Grid item xs={12}>
          {entityList?.length > 0 ? (
            <Box mt={1} mb={1}>
              <SearchTextField
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
              />
            </Box>
          ) : null}
        </Grid>
        <Grid item xs={12}>
          {entityList?.length > 0 ? (
            <Slide direction="left" timeout={1000} mountOnEnter in={true}>
              <Box
                width="100%"
                sx={{ height: 'calc(100vh  - 310px)', overflow: 'scroll' }}
              >
                <ReactMuiTableListView
                  data={entityList?.length > 0 ? entityList : []}
                  columns={columns}
                  rowLevelOnHoverOptions={({ containerSx, row, className }) => {
                    return (
                      <RowLevelOnHoverOptions
                        containerSx={containerSx}
                        row={row}
                        className={className}
                        deleteTemplateHandler={deleteTemplateHandler}
                      />
                    );
                  }}
                  getHeaderProps={() => ({
                    style: {
                      display: 'flex',
                      alignItems: 'center',
                    },
                  })}
                  getRowProps={() => ({
                    style: {
                      position: 'relative',
                    },
                  })}
                  enableRowSelection={false}
                  pageCount={entityList?.length}
                  enablePagination={true}
                  initialPageSize={10}
                  rowsPerPageOptions={[5, 10, 15]}
                  initialGlobalFilter={searchTerm}
                />
              </Box>
            </Slide>
          ) : (
            <Box
              display="flex"
              sx={{ height: 'calc(100vh  - 300px)' }}
              flexGrow={1}
              alignItems="center"
              flexDirection="column"
              justifyContent="center"
            >
              <Typography variant="subtitle1">No data result found.</Typography>
            </Box>
          )}
        </Grid>
      </Grid>
      <CreateCustomEntityModal
        open={openCreateEntityModal}
        handleClose={(eid) => {
          setOpenCreateEntityModal(!openCreateEntityModal);
          if (eid !== 0 && typeof eid === 'string') {
            fetchEntityList();
            history({
              pathname: '/configuration/create-template',
              search: `eid=${eid}`,
            });
          }
        }}
        workflowList={workflowList}
        attachWorkflow={attachWorkflow}
        createCustomEntity={createCustomEntity}
        setOpenCreateEntityModal={setOpenCreateEntityModal}
      />
      <DeleteModal
        open={isDeleteModalOpen}
        handleClose={closeDeleteModal}
        deleteConfirm={deleteConfirm}
        alertLabelText="Do you want to delete this Template?"
      />
    </Box>
  );
};

export default TemplateList;
