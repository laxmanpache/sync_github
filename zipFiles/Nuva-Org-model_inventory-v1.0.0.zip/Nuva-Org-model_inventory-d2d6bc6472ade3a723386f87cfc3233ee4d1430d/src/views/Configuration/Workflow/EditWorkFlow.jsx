import React, { useState, useRef, useCallback } from 'react';
import { Box, Grid, Button, Stack } from '@mui/material';
import ReactFlow, {
  MiniMap,
  updateEdge,
  addEdge,
  MarkerType,
  Background,
  Controls,
  applyNodeChanges,
  applyEdgeChanges,
} from 'reactflow';
import 'reactflow/dist/style.css';
import * as _ from 'lodash';
import { useSearchParams } from 'react-router-dom';

import Breadcrumb from '../../../components/Common/Breadcrumb';
import { WorkflowNode } from '../../../components/Common/ReactFlow/NodeTypes';
import CustomEdge from '../../../components/Common/ReactFlow/CustomEdge';
import CreateNode from '../../../components/Configuration/Workflow/CreateNode';
import useWorkflow from '../../../hooks/Configuration/useWorkflow';
import SwalToast from '../../../components/Common/SwalTost';
import EditWorkflowNode from '../../../components/Configuration/Workflow/EditWorkflowNode';
import useRules from '../../../hooks/RulesAndReports/useRules';

const BreadcrumbsMenu = [
  { id: 1, name: 'Configuration', path: '/configuration' },
  { id: 2, name: 'Workflow' },
];

const edgeOptions = {
  animated: true,
  style: {
    stroke: 'black',
  },
  markerEnd: {
    type: MarkerType.ArrowClosed,
    color: 'black',
  },
};
const connectionLineStyle = { stroke: 'black' };
const DEFAULT_NODES = [
  {
    id: 'Draft',
    data: {
      label: 'Draft',
    },
    position: {
      x: 69.33333333333331,
      y: 9.999999999999972,
    },
    label: 'Draft',
    description: 'Draft Node',
    type: 'workflowNode',
    nodeId: 'Draft',
    sourcePosition: 'right',
    targetPosition: 'left',
    nodeDisplayName: 'Draft',
  },
];

const EditWorkFlow = () => {
  // eslint-disable-next-line no-unused-vars
  const { compileWorkflow, updateWorkflow, getSingleWorkflow, getAllRoles } =
    useWorkflow();
  const { fetchRules, allRules } = useRules();
  const [searchParams] = useSearchParams();
  const [nodes, setNodes] = useState(DEFAULT_NODES);
  const [edges, setEdges] = useState([]);
  const [isShowNodeEditModal, setIsShowNodeEditModal] = useState(false);
  const [currentWorkflow, setCurrentWorkflow] = useState();
  const [nodeData, setNodeData] = useState({});
  const [createNode, setCreateNode] = useState(false);
  const edgeUpdateSuccessful = useRef(true);
  const [allUserRoles, setAllUserRoles] = useState([]);
  React.useEffect(() => {
    getSingleWorkflow({ workflowType: searchParams.get('workflowType') }).then(
      (res) => {
        setCurrentWorkflow(res?.data);
        setNodes(res?.data?.flow_display?.node || DEFAULT_NODES);
        setEdges(res?.data?.flow_display?.connection || []);
      }
    );
    getAllRoles().then((res) => {
      if (res) {
        setAllUserRoles(res?.data);
      }
    });
    fetchRules();
  }, [searchParams]);

  const onNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );
  const onEdgesChange = useCallback(
    (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    []
  );

  const onCompileFlow = (nodesDetails, edgesDetails) => {
    const body = {
      node: nodesDetails,
      connection: edgesDetails,
      workflow_id: currentWorkflow?.id,
      workflow_label: currentWorkflow?.label,
    };
    compileWorkflow(body).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: 'Workflow compiled successfully.',
        });

        updateWorkflow({
          label: currentWorkflow?.label,
          description: currentWorkflow?.description,
          flowDisplay: body,
        }).then(() => {
          SwalToast({
            icon: 'success',
            title: 'Workflow updated successfully.',
          });
        });
      }
    });
  };

  const onConnect = useCallback(
    (parms) => {
      const newParams = _.clone(parms);
      newParams.rules_id = [];
      newParams.toassignRole =
        parms?.target === 'Rejected' ? 'Primary Owner' : 'Approver';
      newParams.onApprove = parms?.target === 'Approved';
      newParams.type = 'custom';
      newParams.data = { text: parms?.target };
      setEdges((els) => addEdge(newParams, els));
    },
    [edges]
  );

  const onEdgeUpdateEnd = useCallback((_a, edge) => {
    if (!edgeUpdateSuccessful.current) {
      setEdges((eds) => eds.filter((e) => e.id !== edge.id));
    }
    edgeUpdateSuccessful.current = true;
  }, []);

  /**
   * @function onEdgeUpdate
   * @description  this function is trigger when Edge will updated.
   */
  const onEdgeUpdate = useCallback((oldEdge, newConnection) => {
    edgeUpdateSuccessful.current = true;
    setEdges((els) => updateEdge(oldEdge, newConnection, els));
  }, []);

  const onNodeClick = (event, node) => {
    setIsShowNodeEditModal(true);
    setNodeData(_.clone(node));
  };
  /**
   * @function onEdgeUpdateStart
   * @description  this function is trigger when we will start updating of Edge
   */
  const onEdgeUpdateStart = useCallback(() => {
    edgeUpdateSuccessful.current = false;
  }, []);
  const nodeTypes = React.useMemo(
    () => ({ workflowNode: WorkflowNode }),
    [WorkflowNode]
  );
  const edgeTypes = {
    custom: CustomEdge,
  };
  const defaultViewport = { x: 0, y: 0, zoom: 1.5 };
  return (
    <Box>
      <Grid container spacing={1}>
        <Grid
          container
          item
          display="flex"
          justifyContent="space-between"
          xs={12}
        >
          <Box>
            <Breadcrumb BreadcrumbsMen={BreadcrumbsMenu} />
          </Box>
          <Stack direction="row" spacing={3}>
            <Button
              variant="contained"
              onClick={() => {
                onCompileFlow(nodes, edges);
              }}
            >
              Compile workflow
            </Button>
            <Button
              variant="contained"
              onClick={() => {
                setCreateNode(true);
              }}
            >
              Create Node
            </Button>
          </Stack>
        </Grid>
        <Grid item container xs={12}>
          <Box width="100%" height="69vh">
            <ReactFlow
              defaultNodes={nodes}
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              defaultEdges={edges}
              onConnect={onConnect}
              onEdgesChange={onEdgesChange}
              onEdgeUpdateEnd={onEdgeUpdateEnd}
              onEdgeUpdateStart={onEdgeUpdateStart}
              onEdgeUpdate={onEdgeUpdate}
              nodeTypes={nodeTypes}
              edgeTypes={edgeTypes}
              onNodeClick={onNodeClick}
              defaultEdgeOptions={edgeOptions}
              defaultZoom={1}
              maxZoom={1.5}
              fitView
              style={{
                backgroundColor: (theme) => theme.palette.other.white,
              }}
              connectionLineStyle={connectionLineStyle}
              defaultViewport={defaultViewport}
            >
              <Background
                variant="lines"
                gap={20}
                size={0.4}
                style={{ color: (theme) => theme.palette.primary.main }}
              />
              <MiniMap nodeStrokeWidth={3} />
              <Controls />
            </ReactFlow>
          </Box>
        </Grid>
      </Grid>
      <CreateNode
        open={createNode}
        handleClose={() => {
          setCreateNode(!createNode);
        }}
        setNodes={setNodes}
        nodes={nodes}
      />
      {isShowNodeEditModal ? (
        <EditWorkflowNode
          open={isShowNodeEditModal}
          handleClose={() => {
            setIsShowNodeEditModal(false);
          }}
          nodeData={nodeData}
          allEdges={edges}
          setEdges={setEdges}
          setNodes={setNodes}
          allUserRoles={allUserRoles}
          rules={allRules}
        />
      ) : null}
    </Box>
  );
};

export default EditWorkFlow;
