/* eslint-disable react/no-unstable-nested-components */
import React, { useEffect } from 'react';
import {
  Box,
  Grid,
  Button,
  IconButton,
  Typography,
  Slide,
} from '@mui/material';
import PropTypes from 'prop-types';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import { useNavigate } from 'react-router-dom';

import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';
import Breadcrumb from '../../../components/Common/Breadcrumb';
import ReactMuiTableListView from '../../../components/Common/ReactMuiTableListView';
import CreateWorkflowModal from '../../../components/Configuration/Workflow/CreateWorkflowModal';
import useWorkflow from '../../../hooks/Configuration/useWorkflow';
import SearchTextField from '../../../components/Common/SearchTextField';

const columns = [
  {
    heading: 'ID',
    accessor: 'id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'WORKFLOW NAME',
    accessor: 'label',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'DESCRIPTION',
    accessor: 'description',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];

const RowLevelOnHoverOptions = ({ containerSx, row, className }) => {
  const history = useNavigate();
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            onClick={() => {
              history({
                pathname: '/configuration/edit-workflow',
                search: `workflowType=${row?.original?.label}`,
              });
            }}
            title="Edit Workflow"
          >
            <BorderColorIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
};

const WorkFlowList = () => {
  const { createWorkflow, getWorkflowList } = useWorkflow();
  const [createWorkflowModal, setCreateWorkflowModal] = React.useState(false);
  const [workflowList, setWorkFlowList] = React.useState([]);
  const [searchTerm, setSearchTerm] = React.useState('');

  useEffect(() => {
    getWorkflowList().then((res) => {
      if (res) {
        setWorkFlowList(res?.data);
      }
    });
  }, []);

  const BreadcrumbsMenu = [{ id: 1, name: 'ModelInventory' }];
  return (
    <Box>
      <Grid container xs={12} spacing={2}>
        <Grid item xs={12} display="flex" justifyContent="space-between">
          <Box>
            <Breadcrumb BreadcrumbsMen={BreadcrumbsMenu} />
          </Box>
          <Button
            variant="contained"
            onClick={() => {
              setCreateWorkflowModal(true);
            }}
          >
            Create Workflow
          </Button>
        </Grid>
        <Grid item xs={12}>
          {workflowList?.length > 0 ? (
            <Box mt={1}>
              <SearchTextField
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
              />
            </Box>
          ) : null}
        </Grid>
        <Grid item xs={12}>
          {workflowList?.length > 0 ? (
            <Slide direction="left" timeout={1000} mountOnEnter in={true}>
              <Box
                width="100%"
                sx={{ height: 'calc(100vh  - 310px)', overflow: 'scroll' }}
              >
                <ReactMuiTableListView
                  data={workflowList?.length > 0 ? workflowList : []}
                  columns={columns}
                  rowLevelOnHoverOptions={({ containerSx, row, className }) => {
                    return (
                      <RowLevelOnHoverOptions
                        containerSx={containerSx}
                        row={row}
                        className={className}
                      />
                    );
                  }}
                  getHeaderProps={() => ({
                    style: {
                      display: 'flex',
                      alignItems: 'center',
                    },
                  })}
                  getRowProps={() => ({
                    style: {
                      position: 'relative',
                    },
                  })}
                  enableRowSelection={false}
                  pageCount={workflowList?.length}
                  enablePagination={true}
                  initialPageSize={10}
                  rowsPerPageOptions={[5, 10, 15]}
                  initialGlobalFilter={searchTerm}
                />
              </Box>
            </Slide>
          ) : (
            <Box
              display="flex"
              sx={{ height: 'calc(100vh  - 300px)' }}
              flexGrow={1}
              alignItems="center"
              flexDirection="column"
              justifyContent="center"
            >
              <Typography variant="subtitle1">No data result found.</Typography>
            </Box>
          )}
        </Grid>
      </Grid>
      <CreateWorkflowModal
        open={createWorkflowModal}
        handleClose={() => {
          setCreateWorkflowModal(false);
        }}
        createWorkflow={createWorkflow}
      />
    </Box>
  );
};

export default WorkFlowList;
