import React from 'react';

const Configuration = () => {
  return <div>Configuration</div>;
};

export default Configuration;
