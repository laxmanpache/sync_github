import React, { useState, useEffect } from 'react';
import { Box, Button, IconButton, Typography, Fab } from '@mui/material';
import { useSearchParams } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import CloseIcon from '@mui/icons-material/Close';
import AddIcon from '@mui/icons-material/Add';

import CreateEntitySection from '../../components/Configuration/CreateEntitySection';
import AddAttribute from '../../components/Configuration/AddAttribute';
import CreateSectionModal from '../../components/Configuration/CreateSectionModal';
import useEntity from '../../hooks/Configuration/useEntity';
import SwalToast from '../../components/Common/SwalTost';

const CreateEditTemplate = () => {
  const {
    createSection,
    deleteSection,
    getCustomEntityTemplate,
    addAttribute,
    deleteAttribute,
  } = useEntity();
  const [searchParams] = useSearchParams();
  const [open, setOpen] = useState(false);
  const [openSectionModal, setOpenSectionModal] = useState(false);
  const [selectedSectionName, setSelectedSectioName] = useState(null);
  const [customEntityTemplate, setCustomEntityTemplate] = useState([]);
  const [hover, setHover] = useState(false);
  const handleClose = () => {
    setOpen(!open);
    setSelectedSectioName(null);
  };
  const handleCloseSectionModal = () => {
    setOpenSectionModal(!openSectionModal);
  };
  const getCustomEntityTemp = (entityName) => {
    getCustomEntityTemplate({ entityName }).then((res) => {
      if (res) {
        setCustomEntityTemplate(res?.data);
      }
    });
  };
  const removeAttribute = (attributeName, sectionName) => {
    deleteAttribute({ attributeName, sectionName }).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: 'Attribute deleted successfully.',
        });
        getCustomEntityTemp(searchParams.get('eid'));
      }
    });
  };
  const removeSection = (sectionName) => {
    deleteSection({ sectionName, entityName: searchParams.get('eid') }).then(
      (res) => {
        if (res) {
          SwalToast({
            icon: 'success',
            title: 'Section deleted successfully.',
          });
          getCustomEntityTemp(searchParams.get('eid'));
        }
      }
    );
  };

  useEffect(() => {
    if (searchParams.get('eid')) {
      getCustomEntityTemp(searchParams.get('eid'));
    }
  }, [searchParams]);
  return (
    <Box height="100%">
      <Box
        sx={{
          display: 'flex',
          height: '100%',
          flexDirection: 'column',
        }}
      >
        <Box display="flex" justifyContent="space-between" mb={2}>
          <IconButton
            onClick={() => {
              window.history.back();
            }}
            color="primary"
          >
            <ArrowBackIcon />
          </IconButton>
          <Button
            variant="contained"
            onClick={() => {
              setOpenSectionModal(true);
            }}
          >
            Add Section
          </Button>
        </Box>
        <Box mt={4}>
          {searchParams.get('eid') &&
          customEntityTemplate?.Entity?.[searchParams.get('eid')]?.sections
            ?.length > 0 ? (
            <Box
              sx={{
                display: 'flex',
                height: '100%',
                alignItems: 'center',
                justifyContent: 'space-around',
              }}
            >
              <Box width="100%" ml="30%" p={1} pr={0}>
                {customEntityTemplate?.Entity?.[
                  searchParams.get('eid')
                ]?.sections?.map((entitySection, i) => {
                  return (
                    // eslint-disable-next-line react/no-array-index-key
                    <Box key={i} mb={1}>
                      <Box display="flex" justifyContent="space-between">
                        <Box sx={{ display: 'flex' }}>
                          <Typography variant="h6" mr={2}>
                            <Typography variant="h6" display="inline">
                              {i + 1}
                              &nbsp;
                            </Typography>
                            {entitySection?.section_name}
                          </Typography>
                          <Fab
                            onClick={() => {
                              removeSection(entitySection?.section_name);
                            }}
                            color="primary"
                            size="small"
                            variant="contained"
                          >
                            <CloseIcon />
                          </Fab>
                        </Box>
                        {[0, undefined].includes(
                          entitySection?.attributes?.length
                        ) ? (
                          <Button
                            onClick={() => {
                              setSelectedSectioName(
                                entitySection?.section_name
                              );
                              setOpen(true);
                            }}
                          >
                            <Fab
                              color="primary"
                              size="small"
                              variant="contained"
                              sx={{
                                marginRight: '10px',
                              }}
                            >
                              <AddIcon />
                            </Fab>
                            Add Attribute
                          </Button>
                        ) : null}
                      </Box>
                      <Box sx={{ marginLeft: '25px' }} p={1} pr={0}>
                        {entitySection?.attributes.map((child, ii) => {
                          return (
                            <Box
                              // eslint-disable-next-line react/no-array-index-key
                              key={ii}
                              width="100%"
                              sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                              }}
                            >
                              <Box
                                onMouseOver={() => setHover(ii)}
                                onMouseOut={() => setHover(null)}
                                sx={(_theme) => {
                                  return {
                                    display: 'flex',
                                    background: _theme.palette.text.light1,
                                    justifyContent: 'space-between',
                                    borderRadius: 1,
                                    width: '50%',
                                    overflow: 'hidden',
                                    // flex: 1,
                                    '&:hover': {
                                      border: `1px solid ${_theme.palette.primary.main}`,
                                    },
                                  };
                                }}
                                p={1}
                                mb={1}
                              >
                                <Typography>{child?.name}</Typography>
                                {hover === ii ? (
                                  <Fab
                                    onClick={() => {
                                      removeAttribute(
                                        child?.name,
                                        entitySection?.section_name
                                      );
                                    }}
                                    color="primary"
                                    size="small"
                                    variant="contained"
                                  >
                                    <CloseIcon fontSize="small" />
                                  </Fab>
                                ) : null}
                              </Box>
                              {entitySection?.attributes?.length === ii + 1 ? (
                                <Button
                                  onClick={() => {
                                    setSelectedSectioName(
                                      entitySection?.section_name
                                    );
                                    setOpen(true);
                                  }}
                                >
                                  <Fab
                                    color="primary"
                                    size="small"
                                    variant="contained"
                                    sx={{
                                      marginRight: '10px',
                                    }}
                                  >
                                    <AddIcon />
                                  </Fab>
                                  Add Attribute
                                </Button>
                              ) : null}
                            </Box>
                          );
                        })}
                      </Box>
                    </Box>
                  );
                })}
              </Box>
            </Box>
          ) : (
            <Box
              sx={{
                display: 'flex',
                height: '100%',
                alignItems: 'center',
                justifyContent: 'space-around',
              }}
            >
              <CreateEntitySection
                entityType={searchParams.get('eid')}
                createSection={createSection}
                getCustomEntityTemp={getCustomEntityTemp}
              />
            </Box>
          )}
        </Box>
        {selectedSectionName ? (
          <AddAttribute
            open={open}
            handleClose={handleClose}
            addAttribute={addAttribute}
            selectedSectionName={selectedSectionName}
            entityType={searchParams.get('eid')}
            getCustomEntityTemp={getCustomEntityTemp}
          />
        ) : null}
        <CreateSectionModal
          open={openSectionModal}
          handleClose={handleCloseSectionModal}
          entityType={searchParams.get('eid')}
          createSection={createSection}
          getCustomEntityTemp={getCustomEntityTemp}
        />
      </Box>
    </Box>
  );
};

export default CreateEditTemplate;
