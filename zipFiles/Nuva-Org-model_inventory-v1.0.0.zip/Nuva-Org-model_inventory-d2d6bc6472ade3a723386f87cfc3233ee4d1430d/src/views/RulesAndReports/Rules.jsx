/* eslint-disable react/no-unstable-nested-components */
import {
  Box,
  Button,
  Grid,
  Typography,
  IconButton,
  Slide,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';
import Breadcrumb from '../../components/Common/Breadcrumb';
import ReactMuiTableListView from '../../components/Common/ReactMuiTableListView';
import useRules from '../../hooks/RulesAndReports/useRules';
import CreateEditRuleModal from '../../components/Common/Modals/CreateEditRuleModal';
import useEntity from '../../hooks/Configuration/useEntity';
import useWorkflow from '../../hooks/Configuration/useWorkflow';
import SwalToast from '../../components/Common/SwalTost';
import SearchTextField from '../../components/Common/SearchTextField';
import DeleteModal from '../../components/Common/Modals/DeleteModal';

const RowLevelOnHoverOptions = ({
  containerSx,
  row,
  className,
  handleEditRule,
  handleDeleteRule,
}) => {
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            onClick={() => {
              handleEditRule(row.original);
            }}
            title="Edit rule details"
          >
            <EditIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            title="Rule model"
            onClick={() => {
              handleDeleteRule(row.original);
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};

RowLevelOnHoverOptions.propTypes = {
  className: PropTypes.string.isRequired,
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  handleEditRule: PropTypes.func.isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  handleDeleteRule: PropTypes.func.isRequired,
};

const columns = [
  {
    heading: 'RULE ID',
    accessor: 'id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'RULE NAME',
    accessor: 'label',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'TYPE',
    accessor: 'type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'Entity TYPE',
    accessor: 'detail.entity_type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'ASSOCIATION TYPE',
    accessor: 'detail.association_type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];

const Rules = () => {
  const { fetchRules, allRules, updateRule, createRule, deleteRule } =
    useRules();

  const [associationTypeList, setAssociationTypeList] = useState([]);
  const [open, setOpen] = useState(false);
  const [activeRule, setActiveRule] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedRuleForDelete, setSelectedRuleForDelete] = useState(0);

  const { customEntityList, getCustomEntityTemplate } = useEntity();
  const { fetchAllStates } = useWorkflow();
  const BreadcrumbsMenu = [{ id: 1, name: 'Rules' }];

  const handleEditRule = (rule) => {
    setActiveRule(rule);
    setOpen(true);
  };

  const handleCreateRule = () => {
    setActiveRule(() => null);
    setOpen(() => true);
  };

  const handleDeleteRule = (rule) => {
    setSelectedRuleForDelete(rule);
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
  };

  const deleteConfirm = () => {
    deleteRule(selectedRuleForDelete).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: 'Rule deleted successfully',
        });
        closeDeleteModal();
      }
    });
  };

  useEffect(() => {
    fetchRules();
    customEntityList().then((res) => {
      if (res) {
        setAssociationTypeList(res?.data ?? []);
      }
    });
  }, []);

  return (
    <Box>
      <Grid container xs={12} rowSpacing={2}>
        <Grid item xs={12} display="flex" justifyContent="space-between">
          <Box>
            <Breadcrumb BreadcrumbsMen={BreadcrumbsMenu} />
          </Box>
          <Button variant="contained" onClick={handleCreateRule}>
            Create Rule
          </Button>
        </Grid>
        <Grid item xs={12}>
          {allRules?.length > 0 ? (
            <Box mt={1}>
              <SearchTextField
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search"
              />
            </Box>
          ) : null}
        </Grid>
        <Grid item xs={12}>
          {allRules?.length > 0 ? (
            <Slide direction="left" timeout={1000} mountOnEnter in={true}>
              <Box
                width="100%"
                sx={{ height: 'calc(100vh  - 310px)' }}
                overflow="scroll"
              >
                <ReactMuiTableListView
                  data={allRules?.length > 0 ? allRules : []}
                  columns={columns}
                  rowLevelOnHoverOptions={({ containerSx, row, className }) => (
                    <RowLevelOnHoverOptions
                      containerSx={containerSx}
                      row={row}
                      className={className}
                      handleEditRule={handleEditRule}
                      handleDeleteRule={handleDeleteRule}
                    />
                  )}
                  getHeaderProps={() => ({
                    style: {
                      display: 'flex',
                      alignItems: 'center',
                    },
                  })}
                  getRowProps={() => ({
                    style: {
                      position: 'relative',
                    },
                  })}
                  enableRowSelection={false}
                  pageCount={allRules?.length}
                  enablePagination={true}
                  initialPageSize={10}
                  rowsPerPageOptions={[5, 10, 15]}
                  initialGlobalFilter={searchTerm}
                />
              </Box>
            </Slide>
          ) : (
            <Box
              display="flex"
              sx={{ height: 'calc(100vh  - 300px)' }}
              flexGrow={1}
              alignItems="center"
              flexDirection="column"
              justifyContent="center"
            >
              <Typography variant="subtitle1">No data result found.</Typography>
            </Box>
          )}

          <CreateEditRuleModal
            open={open}
            handleClose={() => {
              setOpen(() => false);
              setTimeout(() => {
                setActiveRule(null);
              }, 100);
            }}
            rule={activeRule}
            createRule={createRule}
            updateRule={updateRule}
            associationTypeList={associationTypeList}
            fetchAllStates={fetchAllStates}
            getCustomEntityTemplate={getCustomEntityTemplate}
          />
          <DeleteModal
            open={isDeleteModalOpen}
            handleClose={closeDeleteModal}
            deleteConfirm={deleteConfirm}
            alertLabelText="Do you want to delete this rule?"
          />
        </Grid>
      </Grid>
    </Box>
  );
};

export default Rules;
