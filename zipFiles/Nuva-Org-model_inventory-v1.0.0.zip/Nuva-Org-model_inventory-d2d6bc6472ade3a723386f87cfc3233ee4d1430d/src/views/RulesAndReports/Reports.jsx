import React, { useState } from 'react';
import { Box, Grid, Button, Stack } from '@mui/material';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import moment from 'moment';
import { CSVLink } from 'react-csv';
import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';
import { useResizeDetector } from 'react-resize-detector';
import Breadcrumb from '../../components/Common/Breadcrumb';
import { DropDown, DropdownItem } from '../../components/Common/DropDown';
import useModelInventory from '../../hooks/ModelInventory/useModelInventory';
import ReactMuiTableListView from '../../components/Common/ReactMuiTableListView';
import DatePicker from '../../components/Common/DatePicker';

const BreadcrumbsMenu = [{ id: 1, name: 'Reports' }];

const Reports = () => {
  const [filterList, setFilterList] = useState([]);
  const { getAllModelEntity } = useModelInventory();
  const { ref, height } = useResizeDetector();

  const getDataList = (values) => {
    getAllModelEntity({ entityType: values?.entityType }).then((res) => {
      setFilterList(
        res?.data?.modelEntity?.filter((attri) => {
          return (
            new Date(attri?.created_at) >= new Date(values?.fromDate) &&
            new Date(attri?.created_at) <= new Date(values?.toDate)
          );
        })
      );
    });
  };

  const validationSchema = Yup.object({
    entityType: Yup.string().required('Required'),
    fromDate: Yup.string().required('Required'),
    toDate: Yup.string().required('Required'),
  });

  const formikForm = useFormik({
    initialValues: {
      entityType: '',
      fromDate: '',
      toDate: '',
    },
    validationSchema,
    onSubmit: (values) => {
      getDataList(values);
    },
  });
  const columns = [
    {
      heading: 'ID',
      accessor:
        formikForm?.values?.entityType === 'ModelInventory'
          ? 'model_id'
          : 'association_id',
      Header: ReactMuiTableColumnHeaderTextEllipsis,
      width: 100,
    },
    {
      heading: 'NAME',
      accessor:
        formikForm?.values?.entityType === 'ModelInventory'
          ? 'model_name'
          : 'association_name',
      Header: ReactMuiTableColumnHeaderTextEllipsis,
      width: 200,
    },
    {
      heading: 'STATUS',
      accessor: 'status',
      Header: ReactMuiTableColumnHeaderTextEllipsis,
      width: 200,
    },
    {
      heading: 'CREATED AT',
      accessor: 'created_at',
      Header: ReactMuiTableColumnHeaderTextEllipsis,
      width: 200,
      Cell: ({ row }) =>
        moment(new Date(row.original.created_at)).format('YYYY/DD/MM'),
    },
    {
      heading: 'UPDATED AT',
      accessor: 'updated_at',
      Header: ReactMuiTableColumnHeaderTextEllipsis,
      width: 200,
      Cell: ({ row }) =>
        moment(new Date(row.original.updated_at)).format('YYYY/DD/MM'),
    },
  ];
  const HEADERS = [
    {
      label:
        formikForm?.values?.entityType === 'ModelInventory'
          ? 'Model ID'
          : 'Association Id',
      key:
        formikForm?.values?.entityType === 'ModelInventory'
          ? 'model_id'
          : 'association_id',
    },
    {
      label:
        formikForm?.values?.entityType === 'ModelInventory'
          ? 'Model Name'
          : 'Association Name',
      key:
        formikForm?.values?.entityType === 'ModelInventory'
          ? 'model_name'
          : 'association_name',
    },
    { label: 'Status', key: 'status' },
    { label: 'Created At', key: 'created_at' },
    { label: 'Updated At', key: 'updated_at' },
    { label: 'Assign User', key: 'assignedUser' },
    { label: 'Status', key: 'status' },
    { label: 'Priority', key: 'priority' },
    { label: 'Template type', key: 'type' },
    { label: 'Description', key: 'description' },
    { label: 'Updated By', key: 'updated_by' },
  ];
  return (
    <Box sx={{ background: (theme) => theme.palette.primary }}>
      <Grid container xs={12} rowSpacing={4}>
        <Grid item xs={12}>
          <Breadcrumb BreadcrumbsMen={BreadcrumbsMenu} />
        </Grid>

        <Grid item xs={12}>
          <Box
            width="100%"
            sx={{ height: 'calc(100vh  - 250px)' }}
            overflow="scroll"
          >
            <Grid item xs={12} ref={ref}>
              <Stack direction="column" spacing={3} maxWidth={1000} mt={3}>
                <Grid container xs={12} spacing={2}>
                  <Grid item xs={12} lg={4}>
                    <DropDown
                      label="Entity type"
                      value={formikForm.values.entityType}
                      onChange={(event) => {
                        formikForm.setFieldValue(
                          'entityType',
                          event.target.value
                        );
                      }}
                      onBlur={formikForm.handleBlur}
                      helperText={
                        formikForm?.errors?.entityType &&
                        formikForm?.touched?.entityType
                          ? formikForm?.errors?.entityType
                          : null
                      }
                      error={
                        Boolean(formikForm?.errors?.entityType) &&
                        formikForm?.touched?.entityType
                      }
                    >
                      <DropdownItem key={3} value="ModelInventory">
                        ModelInventory
                      </DropdownItem>
                      <DropdownItem key={3} value="ModelAssociation">
                        ModelAssociation
                      </DropdownItem>
                    </DropDown>
                  </Grid>
                  <Grid item xs={12} lg={4}>
                    <DatePicker
                      label="Select from date"
                      name="fromDate"
                      value={formikForm.values.fromDate}
                      onChange={(date) => {
                        formikForm.setFieldValue('fromDate', date);
                      }}
                      onBlur={formikForm.handleBlur}
                      helperText={
                        formikForm?.errors?.fromDate &&
                        formikForm?.touched?.fromDate
                          ? formikForm?.errors?.fromDate
                          : null
                      }
                      error={
                        Boolean(formikForm?.errors?.fromDate) &&
                        formikForm?.touched?.fromDate
                      }
                    />
                  </Grid>
                  <Grid item xs={12} lg={4}>
                    <DatePicker
                      label="Select to date"
                      name="toDate"
                      value={formikForm.values.toDate}
                      onChange={(date) => {
                        formikForm.setFieldValue('toDate', date);
                      }}
                      onBlur={formikForm.handleBlur}
                      helperText={
                        formikForm?.errors?.toDate &&
                        formikForm?.touched?.toDate
                          ? formikForm?.errors?.toDate
                          : null
                      }
                      error={
                        Boolean(formikForm?.errors?.toDate) &&
                        formikForm?.touched?.toDate
                      }
                    />
                  </Grid>
                </Grid>
                <Stack
                  direction="row"
                  spacing={3}
                  justifyContent="center"
                  mt={3}
                >
                  <Button
                    onClick={() => {
                      setFilterList([]);
                      formikForm.handleReset();
                    }}
                  >
                    RESET
                  </Button>
                  <Button onClick={formikForm.handleSubmit} variant="contained">
                    SUBMIT
                  </Button>
                </Stack>
              </Stack>
            </Grid>
            <Grid item xs={12}>
              {filterList?.length > 0 ? (
                <>
                  <Box display="flex" justifyContent="flex-end">
                    <CSVLink
                      data={filterList}
                      filename="model_inventory_report.csv"
                      style={{ textDecoration: 'none' }}
                      headers={HEADERS}
                    >
                      <Button variant="outlined"> Download CSV</Button>
                    </CSVLink>
                  </Box>
                  <Box
                    mt={3}
                    width="100%"
                    sx={{ height: `calc(100vh - 250px - ${height})` }}
                    overflow="scroll"
                  >
                    <ReactMuiTableListView
                      data={filterList?.length > 0 ? filterList : []}
                      columns={columns}
                      rowLevelOnHoverOptions={() => {
                        return null;
                      }}
                      getHeaderProps={() => ({
                        style: {
                          display: 'flex',
                          alignItems: 'center',
                        },
                      })}
                      getRowProps={() => ({
                        style: {
                          position: 'relative',
                        },
                      })}
                      enableRowSelection={false}
                      pageCount={filterList?.length}
                      enablePagination={true}
                      initialPageSize={10}
                      rowsPerPageOptions={[5, 10, 15]}
                    />
                  </Box>
                </>
              ) : null}
            </Grid>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Reports;
