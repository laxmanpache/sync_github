import React, { useState } from 'react';
import {
  Grid,
  Box,
  TextField,
  InputAdornment,
  IconButton,
  Stack,
  Button,
  Typography,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { useFormik } from 'formik';

import * as Yup from 'yup';
import useAuth from '../../hooks/Auth/useAuth';
import LoginCarousel from './LoginCarousel';

const Login = () => {
  const [checked, setChecked] = useState(false);
  const navigate = useNavigate();
  const [hidden, setHidden] = useState(true);
  const { login } = useAuth();
  const changeHidden = () => {
    setHidden(!hidden);
  };
  const loginForm = useFormik({
    initialValues: {
      username: '',
      password: '',
    },
    enableReinitialize: true,
    validationSchema: Yup.object({
      username: Yup.string().required('Required'),
      password: Yup.string().required('Required'),
    }),
    onSubmit: (values) => {
      login(values)
        .then(() => {
          navigate('/dashboard');
          // SwalToast({
          //   icon: 'success',
          //   title: 'User Login  successfully.',
          // });
        })
        .catch((err) => {
          // eslint-disable-next-line no-console
          console.log(err);
        });
    },
  });
  return (
    <Grid
      container
      sx={{
        position: 'absolute',
        width: '100%',
        minWidth: '400px',
        minHeight: '100vh',
        overflow: 'auto',
      }}
    >
      <Grid container item xs={12} md={6.5}>
        <LoginCarousel />
      </Grid>
      <Grid
        item
        xs={12}
        md={5.5}
        container
        px={10}
        sx={{ background: (theme) => theme.palette.primary.dark }}
      >
        <Grid
          item
          xs={6}
          flexDirection="column"
          alignItems="center"
          mx="auto"
          my="auto"
        >
          {/* <Box>
            <Typography
              sx={{ color: (theme) => theme.palette.text.light }}
              variant="h1"
            >
              Welcome
            </Typography>
          </Box> */}
          <Grid item xs={12}>
            <Typography
              variant="h2"
              sx={{ color: (theme) => theme.palette.text.light }}
            >
              Login
            </Typography>
            <Stack direction="column" spacing={3}>
              <Box mb={3} mt={2}>
                <TextField
                  required
                  id="username"
                  type="text"
                  name="username"
                  variant="filled"
                  autoComplete="off"
                  label="Username"
                  value={loginForm.values.username}
                  onChange={loginForm.handleChange}
                  helperText={
                    loginForm.errors.username && loginForm.touched.username
                      ? loginForm.errors.username
                      : null
                  }
                  error={Boolean(
                    loginForm.errors.username && loginForm.touched.username
                      ? loginForm.errors.username
                      : null
                  )}
                />
              </Box>
              <Box mb={2}>
                <TextField
                  required
                  id="password"
                  label="Password"
                  type={!hidden ? 'text' : 'password'}
                  variant="filled"
                  value={loginForm.values.password}
                  onChange={loginForm.handleChange}
                  autoComplete="off"
                  helperText={
                    loginForm.errors.password && loginForm.touched.password
                      ? loginForm.errors.password
                      : null
                  }
                  error={Boolean(
                    loginForm.errors.password && loginForm.touched.password
                      ? loginForm.errors.password
                      : null
                  )}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          color="primary"
                          aria-label="toggle password visibility"
                          onClick={changeHidden}
                          edge="end"
                          size="large"
                        >
                          {!hidden ? <Visibility /> : <VisibilityOff />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              </Box>
              <Stack direction="row" justifyContent="space-between">
                <Box item style={{ display: 'flex', alignItems: 'center' }}>
                  <input
                    type="checkbox"
                    name="remember"
                    id="remember"
                    checked={checked}
                    onChange={() => {
                      setChecked(!checked);
                    }}
                    style={{ marginLeft: '8px', marginRight: '8px' }}
                  />
                  <Typography
                    display="inline"
                    htmlFor="remember"
                    variant="body2"
                    sx={{
                      cursor: 'pointer',
                      color: (theme) => theme.palette.text.light,
                    }}
                  >
                    Remember me
                  </Typography>
                </Box>
                <Typography
                  variant="body2"
                  sx={{
                    cursor: 'pointer',
                    color: (theme) => theme.palette.text.light,
                  }}
                >
                  Forgot Password?
                </Typography>
              </Stack>
              <Stack justifyContent="center" alignItems="center">
                <Box
                  display="flex"
                  sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}
                >
                  <Button
                    variant="contained"
                    size="large"
                    onClick={() => {
                      loginForm.handleSubmit();
                    }}
                    sx={{
                      background: (theme) => theme.palette.primary.contrastText,
                      color: (theme) => theme.palette.primary.dark,
                      width: '100%',
                      '&:hover': {
                        backgroundColor: '#ffff',
                      },
                    }}
                  >
                    LOGIN
                  </Button>
                </Box>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default Login;
