/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable react/no-unstable-nested-components */
import React, { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  Button,
  IconButton,
  Typography,
  Divider,
  TextField,
  Stack,
  ListItemButton,
  Slide,
  Checkbox,
  FormControl,
  FormControlLabel,
  Input,
  ListSubheader,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  Switch,
  TextareaAutosize,
} from '@mui/material';
import PropTypes from 'prop-types';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import * as _ from 'lodash';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import DeleteIcon from '@mui/icons-material/Delete';
import { useNavigate, useSearchParams } from 'react-router-dom';
import VisibilityIcon from '@mui/icons-material/Visibility';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';
import { QueryBuilder } from 'react-querybuilder';
import moment from 'moment';
import { ThemeProvider } from '@mui/material/styles';
import { QueryBuilderMaterial } from '@react-querybuilder/material';
import DragIndicator from '@mui/icons-material/DragIndicator';
import ClearIcon from '@mui/icons-material/Clear';

import Breadcrumb from '../../components/Common/Breadcrumb';
import CreateModel from '../../components/ModelInventory/CreateModel';
import useEntity from '../../hooks/Configuration/useEntity';
import useModelInventory from '../../hooks/ModelInventory/useModelInventory';
import ReactMuiTableListView from '../../components/Common/ReactMuiTableListView';
import SwalToast from '../../components/Common/SwalTost';
import 'react-querybuilder/dist/query-builder.css';
import './custom-styles.css';
import DocumentUploadModal from '../../components/Common/Modals/DocumentUploadModal';
import useDashboard from '../../hooks/ModelInventory/useDashboard';
import { ReactQueryBuilderTheme } from '../../Theme/useCurrentTheme';
import DeleteModal from '../../components/Common/Modals/DeleteModal';
import SearchTextfield from '../../components/Common/SearchTextField';

const fields = [
  {
    name: 'model_name',
    label: 'Modal Name',
    type: 'string',
    operators: [
      { name: '!=', label: '!=' },
      { name: '=', label: '=' },
    ],
  },
  {
    name: 'status',
    label: 'Status',
    type: 'string',
    operators: [
      { name: '!=', label: '!=' },
      { name: '=', label: '=' },
    ],
  },
  {
    name: 'model_id',
    label: 'Modal Id',
    type: 'number',
    operators: [
      { name: '>=', label: '>=' },
      { name: '<=', label: '<=' },
      { name: '<', label: '<' },
      { name: '>', label: '>' },
      { name: '!=', label: '!=' },
      { name: '=', label: '=' },
    ],
  },
  {
    name: 'created_by',
    label: 'Created By',
    type: 'string',
    operators: [
      { name: '!=', label: '!=' },
      { name: '=', label: '=' },
    ],
  },
  {
    name: 'updated_by',
    label: 'Updated By',
    type: 'string',
    operators: [
      { name: '!=', label: '!=' },
      { name: '=', label: '=' },
    ],
  },
  {
    name: 'assignedUser',
    label: 'Assigned User',
    type: 'string',
    operators: [
      { name: '!=', label: '!=' },
      { name: '=', label: '=' },
    ],
  },
  {
    name: 'updated_by',
    label: 'Updated By',
    type: 'string',
    operators: [
      { name: '!=', label: '!=' },
      { name: '=', label: '=' },
    ],
  },
  {
    name: 'type',
    label: 'Type',
    type: 'string',
    operators: [
      { name: '!=', label: '!=' },
      { name: '=', label: '=' },
    ],
  },
  {
    name: 'description',
    label: 'Description',
    type: 'string',
    operators: [
      { name: '!=', label: '!=' },
      { name: '=', label: '=' },
    ],
  },
  {
    name: 'created_at',
    label: 'Created Date',
    type: 'date',
    operators: [
      { name: '<', label: '<' },
      { name: '>', label: '>' },
    ],
  },
  {
    name: 'updated_at',
    label: 'Updated At',
    type: 'date',
    operators: [
      { name: '<', label: '<' },
      { name: '>', label: '>' },
    ],
  },
];

const initialQuery = {
  combinator: 'and',
  rules: [{ field: 'status', operator: '!=', value: '' }],
};

const columns = [
  {
    heading: 'ID',
    accessor: 'unique_id',
    Cell: ({ row }) => {
      if (row?.original?.unique_id) {
        return row?.original?.unique_id;
      }
      return '-';
    },
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'MODEL NAME',
    accessor: 'model_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 150,
  },
  {
    heading: 'STATUS',
    accessor: 'status',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 150,
  },
  {
    heading: 'TYPE',
    accessor: 'type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'RISK RATING',
    accessor: 'modelRiskRating',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'CREATED BY',
    accessor: 'created_by',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 150,
  },
  {
    heading: 'CREATED DATE',
    accessor: 'created_at',
    Cell: ({ row }) => {
      if (row?.original?.created_at?.includes('/')) {
        return row?.original?.created_at;
      }
      return moment(row?.original?.created_at).format('DD/MM/YYYY');
    },
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 150,
  },
  {
    heading: 'ASSIGNED USER',
    accessor: 'assignedUser',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 150,
  },
];

const RowLevelOnHoverOptions = ({
  containerSx,
  row,
  className,
  deleteModel,
  setModelId,
  setAddDocument,
}) => {
  const history = useNavigate();
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            onClick={() => {
              setModelId(row?.original?.model_id);
              setAddDocument(true);
            }}
            title="Add document"
          >
            <AttachFileIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            onClick={() => {
              history({
                pathname: `/model-inventory/${row?.original?.model_id}`,
              });
            }}
            title="View model details"
          >
            <VisibilityIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            title="Delete model"
            onClick={() => {
              deleteModel(row?.original?.model_id);
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  deleteModel: PropTypes.func.isRequired,
  setModelId: PropTypes.func.isRequired,
  setAddDocument: PropTypes.func.isRequired,
};

const muiComponents = {
  Button,
  Checkbox,
  DragIndicator,
  FormControl,
  FormControlLabel,
  Input,
  ListSubheader,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  Switch,
  TextareaAutosize,
};

const ModelInventory = () => {
  const { customEntityList, getCustomEntityTemplate } = useEntity();
  const [query, setQuery] = useState(initialQuery);
  const [filterOpen, setFilterOpen] = useState(true);
  const {
    createModelFirstStep,
    createModelSecondStep,
    getAllModelEntity,
    createModelThirdStep,
    createModelForthStep,
    attachDocument,
    deleteModelEntity,
    saveFilter,
    getAllUsers,
    deleteFilter,
    editFilter,
    getSearchList,
  } = useModelInventory();

  const [open, setOpen] = useState(false);
  const [addDocument, setAddDocument] = useState(false);
  const [modelId, setModelId] = useState(null);
  const [allUserList, setAllUserList] = useState([]);
  const [userModelList, setUserModelList] = useState([]);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [entityList, setEntityList] = useState([]);
  const [filterMode, setFilterMode] = useState('create');
  const [addFilter, setAddFilter] = useState(false);

  const [filters, setFilters] = useState([]);
  const [selectedEntityIdForDelete, setSelectedEntityIdForDelete] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchParams] = useSearchParams();
  const { getFilter } = useDashboard();

  useEffect(() => {
    setFilterOpen(searchParams.get('filter') || false);
  }, [searchParams]);

  const getModelDetails = () => {
    getAllModelEntity({ entityType: 'ModelInventory' }).then((res) => {
      setUserModelList(res?.data?.modelEntity);
    });
  };

  const getFilterList = () => {
    getFilter().then((res) => {
      setFilters(res?.data);
    });
  };

  const fetchData = () => {
    if (searchTerm.trim().length > 0) {
      getSearchList({ text: searchTerm, entityType: 'ModelInventory' }).then(
        (res) => {
          setUserModelList(res.data);
        }
      );
    } else {
      getModelDetails();
    }
  };

  const debouncedFetchData = _.debounce(fetchData, 500);

  useEffect(() => {
    debouncedFetchData();
    return () => {
      debouncedFetchData.cancel();
    };
  }, [searchTerm.trim()]);

  useEffect(() => {
    getModelDetails();
    customEntityList().then((res) => {
      if (res) {
        setEntityList(
          res?.data?.filter(
            (entity) => entity?.entity_type === 'ModelInventory'
          )
        );
      }
    });
    getAllUsers().then((res) => {
      if (res) {
        setAllUserList(res?.data);
      }
    });

    getFilterList();
  }, []);

  const deleteModel = (entityId = 0) => {
    setSelectedEntityIdForDelete(entityId);
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
  };

  const deleteConfirm = () => {
    deleteModelEntity({
      entityType: 'ModelInventory',
      entityId: selectedEntityIdForDelete,
    }).then((res) => {
      if (res) {
        getModelDetails();
        SwalToast({
          icon: 'success',
          title: 'Model deleted successfully.',
        });
        closeDeleteModal();
      }
    });
  };

  const validationSchema = Yup.object().shape({
    filterName: Yup.string().required('Required.'),
    filterDescription: Yup.string().required('Required.'),
  });

  const formikForm = useFormik({
    initialValues: {
      filterName: '',
      filterDescription: '',
    },
    validationSchema,
    onSubmit: () => {
      const body = {
        filterName: formikForm.values.filterName,
        filterDescription: formikForm.values.filterDescription,
        condition: query,
        entityType: 'ModelInventory',
      };
      if (filterMode === 'create') {
        saveFilter(body).then((res) => {
          if (res) {
            setAddFilter(false);
            getFilterList();
            SwalToast({
              icon: 'success',
              title: 'Filter saved successfully.',
            });
          }
        });
      } else {
        editFilter(body).then((res) => {
          if (res) {
            setAddFilter(false);
            getFilterList();
            SwalToast({
              icon: 'success',
              title: 'Filter updated successfully.',
            });
          }
        });
      }
      setFilterMode('create');
      setQuery(initialQuery);
      formikForm.resetForm();
    },
  });

  const onEditFilter = (values) => {
    formikForm.setFieldValue('filterName', values?.filterName);
    formikForm.setFieldValue('filterDescription', values?.filterDescription);
    setQuery(values?.condition || []);
    setAddFilter(!addFilter);
    setFilterMode('edit');
  };

  const deleteSelectedFilter = (values) => {
    deleteFilter({ filterName: values?.filterName }).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: res?.data?.msg,
        });
        getFilterList();
      }
    });
  };

  const filteredData = query
    ? userModelList.filter((person) => {
        const { rules } = query;
        return rules?.length
          ? rules.reduce((acc, rule) => {
              const { field, value, operator } = rule;
              switch (operator) {
                case 'contains':
                  return (
                    acc &&
                    person[field].toLowerCase().includes(value.toLowerCase())
                  );
                case '>=':
                  return acc && person[field] >= value;
                case '<=':
                  return acc && person[field] <= value;
                case '!=':
                  return acc && person[field] !== value;
                case '=':
                  return acc && person[field] === value;
                case '>':
                  return acc && person[field] > value;
                case '<':
                  return acc && person[field] < value;
                case 'in':
                  return acc && value.includes(person[field]);
                case 'not_in':
                  return acc && !value.includes(person[field]);
                default:
                  return acc;
              }
            }, true)
          : true;
      })
    : userModelList;

  return (
    <Box sx={{ background: (theme) => theme.palette.primary }}>
      <Grid container xs={12} rowGap={2}>
        <Grid
          container
          item
          xs={12}
          display="flex"
          justifyContent="space-between"
        >
          <Box>
            <Breadcrumb />
          </Box>
          <Button
            variant="contained"
            onClick={() => {
              setOpen(true);
            }}
          >
            Create Model
          </Button>
        </Grid>
        <Grid item xs={12} flexDirection="column" justifyContent="space-evenly">
          <Box
            display="flex"
            flexDirection="row"
            sx={{
              height: `calc(100vh - 250px)`,
            }}
          >
            <Box
              display="flex"
              flexDirection="column"
              sx={{ overflowY: 'auto' }}
              maxWidth={filterOpen ? '400px' : '100px'}
            >
              <Grid item container rowGap={2}>
                <Grid item xs={12}>
                  <Box display="flex" alignItems="center">
                    <Typography variant="h6">Filters</Typography>
                    <IconButton
                      onClick={() => {
                        setAddFilter(false);
                        setFilterOpen((prev) => !prev);
                      }}
                    >
                      {!filterOpen ? (
                        <KeyboardArrowRightIcon
                          sx={{
                            color: (theme) => theme.palette.primary.main,
                          }}
                        />
                      ) : (
                        <KeyboardArrowDownIcon
                          sx={{
                            color: (theme) => theme.palette.primary.main,
                          }}
                        />
                      )}
                    </IconButton>
                  </Box>
                </Grid>
                <Grid item container display={!filterOpen && 'none'}>
                  {addFilter ? (
                    <Grid item container rowGap={2}>
                      <Grid item xs="auto">
                        <ThemeProvider theme={ReactQueryBuilderTheme}>
                          <QueryBuilderMaterial muiComponents={muiComponents}>
                            <QueryBuilder
                              style={{
                                '& .rule-operators': {
                                  background: 'red',
                                  width: '300px',
                                },
                              }}
                              fields={fields}
                              onQueryChange={(q) => setQuery(q)}
                              query={query}
                              controlElements={{
                                addGroupAction: () => <></>,
                                removeRuleAction: ({
                                  handleOnClick,
                                  ...props
                                }) => (
                                  <IconButton
                                    color="primary"
                                    aria-label="upload picture"
                                    component="label"
                                    size="small"
                                    sx={{ p: 0 }}
                                    onClick={handleOnClick}
                                    {...props}
                                  >
                                    <ClearIcon fontSize="small" />
                                  </IconButton>
                                ),
                              }}
                            />
                          </QueryBuilderMaterial>
                        </ThemeProvider>
                      </Grid>
                      <Grid item container xs={12} spacing={2} pr={2.5}>
                        <Grid item xs={12}>
                          <TextField
                            disabled={filterMode === 'edit'}
                            label="Filter name"
                            name="filterName"
                            placeholder="enter filter name"
                            onBlur={formikForm.handleBlur}
                            {...formikForm.getFieldProps('filterName')}
                            error={
                              formikForm.touched.filterName &&
                              Boolean(formikForm.errors.filterName)
                            }
                            helperText={
                              formikForm?.touched.filterName &&
                              formikForm?.errors?.filterName
                            }
                          />
                        </Grid>
                        <Grid item xs={12}>
                          <TextField
                            label="Filter description"
                            name="filterDescription"
                            placeholder="enter filter description"
                            onBlur={formikForm.handleBlur}
                            {...formikForm.getFieldProps('filterDescription')}
                            error={
                              formikForm.touched.filterDescription &&
                              Boolean(formikForm.errors.filterDescription)
                            }
                            helperText={
                              formikForm?.touched.filterDescription &&
                              formikForm?.errors?.filterDescription
                            }
                          />
                        </Grid>
                      </Grid>
                      <Grid item xs={12}>
                        <Button
                          onClick={formikForm.handleSubmit}
                          type="submit"
                          variant="contained"
                          color="primary"
                        >
                          Save Filter
                        </Button>
                      </Grid>
                    </Grid>
                  ) : (
                    <Grid item container xs={12} mr={2}>
                      <Grid item xs={12}>
                        <Button
                          sx={{ width: '100%' }}
                          variant="outlined"
                          onClick={() => {
                            setAddFilter(!addFilter);
                          }}
                        >
                          Add Filter
                        </Button>
                      </Grid>
                      {filters?.length > 0 ? (
                        <>
                          <Grid item xs={12}>
                            <List sx={{ width: '100%' }}>
                              <ListItem>
                                <Grid container>
                                  <Grid item xs={3}>
                                    <Typography
                                      color="primary"
                                      variant="body"
                                      sx={{ whiteSpace: 'nowrap' }}
                                    >
                                      Filter Name
                                    </Typography>
                                  </Grid>
                                </Grid>
                              </ListItem>
                            </List>
                          </Grid>

                          {filters?.map((item) => {
                            return (
                              <Grid key={item?.filterName} item xs={12}>
                                <ListItem
                                  alignItems="flex-start"
                                  sx={{ paddingX: 0 }}
                                >
                                  <ListItemButton
                                    sx={{
                                      height: 'inherit',
                                    }}
                                  >
                                    <>
                                      <Typography
                                        sx={{ display: 'inline' }}
                                        component="span"
                                        variant="body2"
                                        color="text.primary"
                                      >
                                        {item?.filterName}
                                      </Typography>
                                    </>

                                    <Stack
                                      direction="row"
                                      spacing={3}
                                      className="list-item-button-hover-actions-right"
                                    >
                                      <IconButton
                                        size="small"
                                        title="Delete filter."
                                      >
                                        <DeleteIcon
                                          onClick={() => {
                                            deleteSelectedFilter(item);
                                          }}
                                          color="primary"
                                          alt="add"
                                          height={24}
                                          width={24}
                                        />
                                      </IconButton>
                                      <IconButton title="Edit filter.">
                                        <BorderColorIcon
                                          onClick={() => {
                                            onEditFilter(item);
                                          }}
                                          color="primary"
                                          alt="edit"
                                          height={24}
                                          width={24}
                                        />
                                      </IconButton>
                                    </Stack>
                                  </ListItemButton>
                                </ListItem>
                                <Divider orientation="horizontal" />
                              </Grid>
                            );
                          })}
                        </>
                      ) : (
                        <Box
                          display="flex"
                          style={{ height: 'calc(100vh  - 500px)' }}
                          flexGrow={1}
                          alignItems="center"
                          flexDirection="column"
                          justifyContent="center"
                        >
                          <Typography variant="subtitle1">
                            No filter available.
                          </Typography>
                        </Box>
                      )}
                    </Grid>
                  )}
                </Grid>
              </Grid>
            </Box>
            <Divider orientation="vertical" flexItem />
            <Box
              display="flex"
              flexGrow={1}
              ml={2}
              flexDirection="column"
              overflow="auto"
            >
              <Box mb={2}>
                <SearchTextfield
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e?.target?.value)}
                  placeholder="Search"
                />
              </Box>
              <Box
                display="flex"
                flexGrow={1}
                flexDirection="column"
                overflow="auto"
              >
                {filteredData?.length > 0 ? (
                  <Slide direction="left" timeout={1000} mountOnEnter in={true}>
                    <Box>
                      <ReactMuiTableListView
                        data={filteredData?.length > 0 ? filteredData : []}
                        columns={columns}
                        rowLevelOnHoverOptions={({
                          containerSx,
                          row,
                          className,
                        }) => {
                          return (
                            <RowLevelOnHoverOptions
                              containerSx={containerSx}
                              row={row}
                              className={className}
                              deleteModel={deleteModel}
                              setModelId={setModelId}
                              setAddDocument={setAddDocument}
                            />
                          );
                        }}
                        getHeaderProps={() => ({
                          style: {
                            display: 'flex',
                            alignItems: 'center',
                          },
                        })}
                        getRowProps={() => ({
                          style: {
                            position: 'relative',
                          },
                        })}
                        enableRowSelection={false}
                        pageCount={filteredData?.length}
                        enablePagination={true}
                        initialPageSize={10}
                        rowsPerPageOptions={[5, 10, 15]}
                      />
                    </Box>
                  </Slide>
                ) : (
                  <Box
                    display="flex"
                    style={{ height: 'calc(100vh  - 500px)' }}
                    flexGrow={1}
                    alignItems="center"
                    flexDirection="column"
                    justifyContent="center"
                  >
                    <Typography variant="subtitle1">
                      No data result found.
                    </Typography>
                  </Box>
                )}
              </Box>
            </Box>
          </Box>
        </Grid>
      </Grid>
      <CreateModel
        open={open}
        setOpen={setOpen}
        entityList={entityList}
        typeOfEntity="ModelInventory"
        createModelFirstStep={createModelFirstStep}
        getCustomEntityTemplate={getCustomEntityTemplate}
        createModelSecondStep={createModelSecondStep}
        getAllModelEntity={getAllModelEntity}
        createModelThirdStep={createModelThirdStep}
        createModelForthStep={createModelForthStep}
        attachDocument={attachDocument}
        allUserList={allUserList}
        getModelDetails={getModelDetails}
      />
      <DocumentUploadModal
        open={addDocument}
        handleClose={() => {
          setAddDocument(false);
        }}
        isMultiple={false}
        enitityType="ModelInventory"
        entityId={modelId}
        attachDocument={attachDocument}
      />
      <DeleteModal
        open={isDeleteModalOpen}
        handleClose={closeDeleteModal}
        deleteConfirm={deleteConfirm}
        alertLabelText="Do you want to delete this model?"
      />
    </Box>
  );
};

export default ModelInventory;
