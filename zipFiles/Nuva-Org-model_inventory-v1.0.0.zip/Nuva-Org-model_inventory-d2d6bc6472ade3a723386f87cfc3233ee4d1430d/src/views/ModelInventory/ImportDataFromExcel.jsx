import React from 'react';

const ImportDataFromExcel = () => {
  return <div>ImportDataFromExcel</div>;
};

export default ImportDataFromExcel;
