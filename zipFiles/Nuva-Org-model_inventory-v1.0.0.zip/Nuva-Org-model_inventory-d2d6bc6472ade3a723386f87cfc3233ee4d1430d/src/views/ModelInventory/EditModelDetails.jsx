/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
/* eslint-disable react/no-unstable-nested-components */
import React, { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  Button,
  Typography,
  Divider,
  Tabs,
  Tab,
  TextField,
  IconButton,
  Stack,
  Slide,
} from '@mui/material';
import { useSelector } from 'react-redux';
import * as _ from 'lodash';
import InputAdornment from '@mui/material/InputAdornment';
import SearchIcon from '@mui/icons-material/Search';
import { useNavigate, useParams } from 'react-router-dom';
import { styled } from '@mui/material/styles';
import DeleteIcon from '@mui/icons-material/Delete';
import PropTypes from 'prop-types';
import useMediaQuery from '@mui/material/useMediaQuery';
import VisibilityIcon from '@mui/icons-material/Visibility';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';
import { useTheme } from '@emotion/react';
import moment from 'moment';
import Breadcrumb from '../../components/Common/Breadcrumb';
import { TabPanel } from '../../components/Common/Tabs';
import useModelInventory from '../../hooks/ModelInventory/useModelInventory';
import ReactMuiTableListView from '../../components/Common/ReactMuiTableListView';
import AddTeamMember from '../../components/ModelInventory/AddTeamMember';
import AddAssociationModal from '../../components/ModelInventory/AddAssociationModal';
// import EditModelAttributesDetails from '../../components/ModelInventory/EditModelAttributesDetails';
import useEntity from '../../hooks/Configuration/useEntity';
import SwalToast from '../../components/Common/SwalTost';
import DocumentUploadModal from '../../components/Common/Modals/DocumentUploadModal';
import Notes from '../../components/Common/ModelInventoryAndAssociation/Notes';
import ModelDetails from '../../components/Common/ModelInventoryAndAssociation/ModelDetails';
import Summary from '../../components/Common/ModelInventoryAndAssociation/Summary';
import Alerts from '../../components/Common/ModelInventoryAndAssociation/Alerts';
import ModelAssociation from '../../components/Common/ModelInventoryAndAssociation/ModelAssociation';
import CreateAddAssociation from '../../components/Common/ModelInventoryAndAssociation/Modals/CreateAddAssociation';
import DeleteModal from '../../components/Common/Modals/DeleteModal';

const AntTab = styled(Tab)(({ theme }) => ({
  minHeight: '25px',
  marginBottom: '5px',
  display: 'flex',
  justifyContent: 'flex-start',
  padding: '8px',
  color: theme.palette.primary.main,
  '&.Mui-selected': {
    backgroundColor: theme.palette.primary.main,
    borderRadius: '3px',
    color: `${theme.palette.text.light} !important`,
  },
}));
const AntTabPanel = styled(TabPanel)(() => ({
  padding: '24px',
  paddingTop: '0px',
  width: '100%',
}));
const CustomTextField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-input': {
    padding: '10px !important',
  },
  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      borderColor: theme.palette.primary.main,
    },
  },
}));

const columns = [
  {
    heading: 'USER',
    accessor: 'user',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'TYPE',
    accessor: 'model_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
    Cell: 'Model Developer',
  },
  {
    heading: 'ROLE',
    accessor: 'role',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'EMAIL',
    accessor: 'user_email',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];

const DocumentColumns = [
  {
    heading: 'DOCUMENT ID',
    accessor: 'document_id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'DOCUMENT NAME',
    accessor: 'document_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'DOCUMENT DESCRIPTION',
    accessor: 'document_description',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'DOCUMENT AUTHOR',
    accessor: 'document_author',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'UPLOADED AT',
    accessor: 'uploaded_at',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
    Cell: ({ row }) =>
      moment(new Date(row.original.uploaded_at)).format('YYYY/DD/MM'),
  },
  {
    heading: 'Version',
    accessor: 'version',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
];

const ModelHistoryColumns = [
  {
    // Make an expander cell
    Header: () => null, // No header
    id: 'expander', // It needs an ID
    // eslint-disable-next-line react/prop-types
    Cell: ({ row }) => (
      // Use Cell to render an expander for each row.
      // We can use the getToggleRowExpandedProps prop-getter
      // to build the expander.
      <span {...row.getToggleRowExpandedProps()}>
        {row.isExpanded ? (
          <KeyboardArrowDownIcon />
        ) : (
          <KeyboardArrowRightIcon />
        )}
      </span>
    ),
  },
  {
    heading: 'MODEL ID',
    accessor: 'entity_id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'MODEL TYPE',
    accessor: 'entity_type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'ACTION',
    accessor: 'action',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CHANGED DATE',
    accessor: 'modification_date',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
    Cell: ({ row }) =>
      moment(new Date(row.original.modification_date)).format('YYYY/DD/MM'),
  },
];

const SUMMARY_LABELS = {
  type: 'Type',
  assignedUser: 'Assigned User',
  model_name: 'Model Name',
  model_id: 'Model Id',
  created_at: 'Created At',
  updated_at: 'Updated At',
  created_by: 'Created By',
  updated_by: 'Updated By',
  description: 'Description',
  modelRiskRating: 'Model Risk Rating',
};

// eslint-disable-next-line no-unused-vars
const RowLevelOnHoverOptions = ({
  containerSx,
  row,
  className,
  removeTeamMember,
  modelId,
  getTeamDetails,
}) => {
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          {row?.original?.role !== 'Primary Owner' ? (
            <IconButton
              size="small"
              title="Remove team member"
              onClick={() => {
                removeTeamMember({
                  entity_type: 'ModelInventory',
                  entity_id: modelId,
                  username: row?.original?.user,
                  role: row?.original?.role,
                }).then(() => {
                  getTeamDetails({
                    entityType: 'ModelInventory',
                    entityId: modelId,
                  });
                  SwalToast({
                    icon: 'success',
                    title: 'Team member removed successfully.',
                  });
                });
              }}
            >
              <DeleteIcon color="primary" />
            </IconButton>
          ) : null}
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  modelId: PropTypes.number.isRequired,
  removeTeamMember: PropTypes.func.isRequired,
  getTeamDetails: PropTypes.func.isRequired,
};

const RowLevelOnHoverDocumentOptions = ({
  containerSx,
  row,
  className,
  deleteAttchedDocument,
  entityId,
  entityType,
}) => {
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            title="View attached document"
            onClick={() => {
              window.open(row?.original?.fileurl, '_blank');
            }}
          >
            <VisibilityIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            title="Delete attached document"
            onClick={() => {
              deleteAttchedDocument({
                documentId: row?.original?.document_id,
                entityId,
                entityType,
              }).then(() => {
                SwalToast({
                  icon: 'success',
                  title: 'Associated model removed successfully.',
                });
              });
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverDocumentOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  deleteAttchedDocument: PropTypes.func.isRequired,
  entityId: PropTypes.number.isRequired,
  entityType: PropTypes.string.isRequired,
};

const SUB_HISTORY_COLUMNS = [
  {
    heading: 'CHANGED FIELD',
    accessor: 'feild',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'PREVIOUS VALUE',
    accessor: 'previous_value',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
    Cell: ({ row }) => (
      <span>
        {_.isEmpty(row?.original?.previous_value)
          ? '-'
          : row?.original?.previous_value}
      </span>
    ),
  },
  {
    heading: 'CURRENT VALUE',
    accessor: 'current_value',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    Cell: ({ row }) => {
      return (
        <span>
          {_.isArray(row?.original?.current_value)
            ? row?.original?.current_value?.map((item) => {
                return (
                  <Typography key={item?.label} variant="subtitle" mr={1}>
                    {`${item?.label},`}
                  </Typography>
                );
              })
            : row?.original?.previous_value}
        </span>
      );
    },
    width: 200,
  },
];

const EditModelDetails = () => {
  const theme = useTheme();
  const { getCustomEntityTemplate } = useEntity();
  const { userData } = useSelector((state) => state.users);
  const {
    getAttributeDetails,
    getTeamDetails,
    teamDetails,
    getAllModelEntity,
    createModelThirdStep,
    getAssociationDetails,
    associationDetails,
    createModelSecondStep,
    addSingleTeamMember,
    getAllUsers,
    sendForApproval,
    getAllRoles,
    removeTeamMember,
    removeModelAssociation,
    deleteModelEntity,
    fetchDocumentsList,
    documentsList,
    attachDocument,
    deleteAttchedDocument,
    getHistory,
    getAllNotes,
    addNote,
    getAllAlerts,
    deleteAlert,
    updateAlerts,
    createAlerts,
    updateModelEntity,
  } = useModelInventory();
  const isMd = useMediaQuery(theme.breakpoints.down('md'));
  // const [attributeDetails, setAttributeDetails] = useState([]);
  const [fromDetails, setFormDetails] = useState([]);
  const [AddMember, setAddMember] = useState(false);
  const [addAssociation, setAddAssociation] = useState(false);
  const [createAndAddAssociation, setCreateAndAddAssociation] = useState(false);
  const [addDocument, setAddDocument] = useState(false);
  const [currentModel, setCurrentModel] = useState({});
  // const [editModelDetails, setEditModelDetails] = useState(false);
  const [allUserList, setAllUserList] = useState([]);
  const [allUserRoles, setAllUserRoles] = useState([]);
  const [modelHistory, setModelHistory] = useState([]);
  const [value, setValue] = useState(1);
  const [teamFilter, setTeamFilter] = useState('');
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedEntityIdForDelete, setSelectedEntityIdForDelete] = useState(0);

  const history = useNavigate();
  const { modelId } = useParams();

  const getModelDetails = () => {
    getAllModelEntity({ entityType: 'ModelInventory' }).then((res) => {
      if (res) {
        setCurrentModel(
          res?.data?.modelEntity?.filter(
            (model) => model?.model_id === Number(modelId)
          )[0]
        );
      }
    });
  };

  React.useMemo(() => {
    getModelDetails();
    getAllUsers().then((res) => {
      if (res) {
        setAllUserList(res?.data);
      }
    });
    getAllRoles().then((res) => {
      if (res) {
        setAllUserRoles(res?.data);
      }
    });
  }, [modelId]);

  useEffect(() => {
    if (currentModel?.type)
      getCustomEntityTemplate({
        entityName: currentModel?.type,
      }).then((resp) => {
        if (resp) {
          setFormDetails(resp?.data?.Entity?.[currentModel?.type]?.sections);
        }
      });
    getHistory({
      entityType: 'ModelInventory',
      entityId: Number(modelId),
    }).then((res) => {
      if (res) {
        setModelHistory(res?.data?.history);
      }
    });
  }, [currentModel]);

  useEffect(() => {
    if (modelId) {
      // getAttributeDetails({
      //   entityType: 'ModelInventory',
      //   entityId: modelId,
      // }).then((res) => {
      //   if (res) {
      //     setAttributeDetails(res?.data?.data);
      //   }
      // });
      getTeamDetails({
        entityType: 'ModelInventory',
        entityId: modelId,
      });
      getAssociationDetails({
        entityType: 'ModelInventory',
        entityId: modelId,
      });
      fetchDocumentsList({
        entityType: 'ModelInventory',
        entityId: modelId,
      });
    }
  }, [modelId]);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const deleteModel = (entityId = 0) => {
    setSelectedEntityIdForDelete(entityId);
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
  };

  const deleteConfirm = () => {
    deleteModelEntity({
      entityType: 'ModelInventory',
      entityId: selectedEntityIdForDelete,
    }).then((res) => {
      if (res) {
        getAllModelEntity({ entityType: 'ModelInventory' });
        history({
          pathname: '/model-inventory',
        });
        SwalToast({
          icon: 'success',
          title: 'Model deleted successfully.',
        });
      }
    });
  };

  const SendModelForNextStage = (status) => {
    sendForApproval({
      entity_id: modelId,
      entity_type: 'ModelInventory',
      approved: status,
    }).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: `Model ${status ? 'approved' : 'rejected'} Successfully.`,
        });
      }
    });
  };

  const renderRowSubComponent = React.useCallback(
    ({ row }) => (
      <Box
        width="100%"
        mt={2}
        mb={2}
        p={2}
        borderRadius={2}
        sx={{
          borderWidth: 1,
          borderStyle: 'solid',
          borderColor: theme.palette.primary.main,
        }}
      >
        <ReactMuiTableListView
          data={
            row?.original?.changes?.length > 0 ? row?.original?.changes : []
          }
          columns={SUB_HISTORY_COLUMNS}
          getHeaderProps={() => ({
            style: {
              display: 'flex',
              alignItems: 'center',
            },
          })}
          rowLevelOnHoverOptions={() => <span />}
          getRowProps={() => ({
            style: {
              position: 'relative',
            },
          })}
          enableRowSelection={false}
          initialPageSize={7}
          rowsPerPageOptions={[5, 7, 10, 15]}
        />
      </Box>
    ),
    []
  );

  return (
    <Box>
      <Grid container xs={12} rowGap={2}>
        <Grid item xs={12} display="flex" justifyContent="space-between">
          <Box>
            <Breadcrumb />
          </Box>
        </Grid>
        <Grid item xs={12} display="flex" flexDirection="column">
          <Box
            sx={{ height: `calc(100vh - 235px)` }}
            display="flex"
            overflow="hidden"
            flexDirection={isMd ? 'column' : 'row'}
          >
            <Box pr={1} overflow="auto">
              <Tabs
                value={value}
                onChange={handleChange}
                orientation={isMd ? 'horizontal' : 'vertical'}
                variant="scrollable"
                sx={() => {
                  return {
                    border: 'none',
                    '& .MuiTabs-indicator ': {
                      display: 'none',
                    },
                  };
                }}
              >
                <Typography mt={1} mb={2} mr={1}>
                  Actions
                </Typography>
                <AntTab title="Summary" label="Summary" />
                <AntTab title="Details" label="Details" />
                <AntTab title="Preview" label="Preview" />
                <AntTab title="Association" label="Association" />
                <AntTab title="Team" label="Team" />
                <AntTab title="Notes" label="Notes" />
                <AntTab title="History" label="History" />
                <AntTab title="Alerts" label="Alerts" />
              </Tabs>
            </Box>
            <Divider
              sx={{
                backgroundColor: (_theme) => _theme.palette.other.grey1,
              }}
              mr={2}
              orientation={isMd ? 'horizontal' : 'vertical'}
            />
            <Box
              display="flex"
              flex={1}
              flexDirection="column"
              mt={isMd ? 3 : 0}
              sx={{ overflow: 'auto' }}
            >
              <AntTabPanel value={value} index={1}>
                <Box display="flex">
                  <Summary
                    summaryLabels={SUMMARY_LABELS}
                    currentModel={currentModel}
                    allUserList={teamDetails?.team_member}
                    entityType="ModelInventory"
                    updateModelEntity={updateModelEntity}
                    getModelDetails={getModelDetails}
                  />
                  <Box>
                    {userData?.username === currentModel?.assignedUser ? (
                      <Stack
                        mt={10}
                        direction="row"
                        display="flex"
                        position="fixed"
                        bottom={25}
                        right={25}
                        justifyContent="flex-end"
                        spacing={3}
                      >
                        <Button
                          variant="outlined"
                          onClick={() => {
                            deleteModel(currentModel?.model_id);
                          }}
                        >
                          DELETE
                        </Button>

                        {/* <Button
                          variant="outlined"
                          onClick={() => {
                            setEditModelDetails(true);
                          }}
                        >
                          EDIT
                        </Button> */}
                        {currentModel.status !== 'Draft' ? (
                          <>
                            <Button
                              variant="outlined"
                              onClick={() => {
                                SendModelForNextStage(false);
                              }}
                            >
                              DISCARD
                            </Button>
                            <Button
                              variant="outlined"
                              onClick={() => {
                                SendModelForNextStage(true);
                              }}
                            >
                              PROCEED
                            </Button>
                          </>
                        ) : (
                          <Button
                            variant="outlined"
                            onClick={() => {
                              SendModelForNextStage(true);
                            }}
                          >
                            SEND FOR APPROVAL
                          </Button>
                        )}
                        <Button variant="contained">SYNC WITH NIMBUS</Button>
                      </Stack>
                    ) : null}
                  </Box>
                </Box>
              </AntTabPanel>
              <AntTabPanel value={value} index={2}>
                {value === 2 ? (
                  <ModelDetails
                    getAttributeDetails={getAttributeDetails}
                    entityId={modelId}
                    entityType="ModelInventory"
                    fromDetails={fromDetails}
                    createModelSecondStep={createModelSecondStep}
                  />
                ) : null}
              </AntTabPanel>
              <AntTabPanel value={value} index={3}>
                <Grid container item xs={12} spacing={4}>
                  <Grid container item xs={12} spacing={2}>
                    <Grid item xs={7} sm={8} md={9} lg={10} xl={10} flexGrow>
                      <CustomTextField
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton>
                                <SearchIcon />
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                        sx={{}}
                        placeholder="Search filter"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={5}
                      sm={4}
                      md={3}
                      lg={2}
                      xl={2}
                      display="flex"
                      justifyContent="flex-end"
                    >
                      <Button
                        variant="contained"
                        onClick={() => {
                          setAddDocument((data) => !data);
                        }}
                        sx={{ whiteSpace: 'nowrap' }}
                      >
                        Add Document
                      </Button>
                    </Grid>
                  </Grid>
                  <Grid item xs={12}>
                    {documentsList?.length > 0 ? (
                      <Slide
                        direction="left"
                        timeout={1000}
                        mountOnEnter
                        in={value === 3}
                      >
                        <Box>
                          <ReactMuiTableListView
                            data={
                              documentsList?.length > 0 ? documentsList : []
                            }
                            columns={DocumentColumns}
                            rowLevelOnHoverOptions={({
                              containerSx,
                              row,
                              className,
                            }) => {
                              return (
                                <RowLevelOnHoverDocumentOptions
                                  containerSx={containerSx}
                                  row={row}
                                  className={className}
                                  deleteAttchedDocument={deleteAttchedDocument}
                                  entityType="ModelInventory"
                                  entityId={modelId}
                                />
                              );
                            }}
                            getHeaderProps={() => ({
                              style: {
                                display: 'flex',
                                alignItems: 'center',
                              },
                            })}
                            getRowProps={() => ({
                              style: {
                                position: 'relative',
                              },
                            })}
                            enableRowSelection={false}
                            pageCount={documentsList?.length}
                            enablePagination={true}
                            initialPageSize={10}
                            rowsPerPageOptions={[5, 10, 15]}
                          />
                        </Box>
                      </Slide>
                    ) : (
                      <Box
                        display="flex"
                        style={{ height: 'calc(100vh  - 300px)' }}
                        flexGrow={1}
                        alignItems="center"
                        flexDirection="column"
                        justifyContent="center"
                      >
                        <Typography variant="subtitle1">
                          No data result found.
                        </Typography>
                      </Box>
                    )}
                  </Grid>
                </Grid>
              </AntTabPanel>
              <AntTabPanel value={value} index={4} sx={{}}>
                <Grid container item xs={12} spacing={4}>
                  <Grid container item xs={12} spacing={2}>
                    <Grid item xs={3} sm={4} md={5} lg={7} xl={8} flexGrow>
                      <CustomTextField
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton>
                                <SearchIcon />
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                        sx={{}}
                        placeholder="Search filter"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={9}
                      sm={8}
                      md={7}
                      lg={5}
                      xl={4}
                      display="flex"
                      justifyContent="flex-end"
                    >
                      <Button
                        variant="contained"
                        onClick={() => {
                          setCreateAndAddAssociation(!createAndAddAssociation);
                        }}
                        sx={{ whiteSpace: 'nowrap', marginRight: '10px' }}
                      >
                        Create & Add Association
                      </Button>
                      <Button
                        variant="contained"
                        onClick={() => {
                          setAddAssociation(!addAssociation);
                        }}
                        sx={{ whiteSpace: 'nowrap' }}
                      >
                        Link Association
                      </Button>
                    </Grid>
                  </Grid>
                  <Grid item xs={12}>
                    <ModelAssociation
                      association={associationDetails?.Association}
                      value={value}
                      setValue={setValue}
                      removeModelAssociation={removeModelAssociation}
                      getAssociationDetails={getAssociationDetails}
                      entityId={Number(modelId)}
                      entityType="ModelInventory"
                    />
                  </Grid>
                </Grid>
              </AntTabPanel>
              <AntTabPanel value={value} index={5} sx={{}}>
                <Grid container item xs={12} spacing={4}>
                  <Grid container item xs={12} spacing={2}>
                    <Grid item xs={7} sm={8} md={9} lg={10} xl={10} flexGrow>
                      <CustomTextField
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton>
                                <SearchIcon />
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                        sx={{}}
                        value={teamFilter}
                        onChange={(e) => {
                          setTeamFilter(e?.target?.value);
                        }}
                        placeholder="Search filter"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={5}
                      sm={4}
                      md={3}
                      lg={2}
                      xl={2}
                      display="flex"
                      justifyContent="flex-end"
                    >
                      <Button
                        variant="contained"
                        onClick={() => {
                          setAddMember(!AddMember);
                        }}
                        sx={{ whiteSpace: 'nowrap' }}
                      >
                        Add Member
                      </Button>
                    </Grid>
                  </Grid>
                  <Grid item xs={12}>
                    <Slide
                      direction="left"
                      timeout={1000}
                      mountOnEnter
                      in={value === 5}
                    >
                      <Box>
                        <ReactMuiTableListView
                          data={
                            teamDetails?.team_member?.length
                              ? teamDetails?.team_member
                              : []
                          }
                          columns={columns}
                          rowLevelOnHoverOptions={({
                            containerSx,
                            row,
                            className,
                          }) => {
                            return (
                              <RowLevelOnHoverOptions
                                containerSx={containerSx}
                                row={row}
                                className={className}
                                removeTeamMember={removeTeamMember}
                                modelId={Number(modelId)}
                                getTeamDetails={getTeamDetails}
                              />
                            );
                          }}
                          getHeaderProps={() => ({
                            style: {
                              display: 'flex',
                              alignItems: 'center',
                            },
                          })}
                          getRowProps={() => ({
                            style: {
                              position: 'relative',
                            },
                          })}
                          enableRowSelection={false}
                          pageCount={teamDetails?.team_member?.length}
                          enablePagination={true}
                          initialPageSize={10}
                          initialGlobalFilter={teamFilter}
                          rowsPerPageOptions={[5, 10, 15]}
                        />
                      </Box>
                    </Slide>
                  </Grid>
                </Grid>
              </AntTabPanel>
              <AntTabPanel value={value} index={6} sx={{ padding: '24px' }}>
                <Notes
                  getAllNotes={getAllNotes}
                  addNote={addNote}
                  entityType="ModelInventory"
                  entityId={modelId}
                />
              </AntTabPanel>
              <AntTabPanel value={value} index={7} sx={{ padding: '24px' }}>
                <Grid container item xs={12} rowSpacing={2}>
                  <Grid item xs={12} md={10}>
                    <Typography variant="h4">Model History</Typography>
                  </Grid>
                  <Grid item xs={12} md={10}>
                    <Divider
                      sx={{
                        backgroundColor: (_theme) => _theme.palette.other.grey1,
                      }}
                      light
                      orientation="horizontal"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Slide
                      direction="left"
                      timeout={1000}
                      mountOnEnter
                      in={value === 7}
                    >
                      <Box>
                        <ReactMuiTableListView
                          data={modelHistory?.length > 0 ? modelHistory : []}
                          columns={ModelHistoryColumns}
                          rowLevelOnHoverOptions={({
                            containerSx,
                            row,
                            className,
                          }) => {
                            return null;
                          }}
                          getHeaderProps={() => ({
                            style: {
                              display: 'flex',
                              alignItems: 'center',
                            },
                          })}
                          getRowProps={() => ({
                            style: {
                              position: 'relative',
                            },
                          })}
                          renderRowSubComponent={renderRowSubComponent}
                          enableRowSelection={false}
                          pageCount={modelHistory?.length}
                          enablePagination={true}
                          initialPageSize={10}
                          rowsPerPageOptions={[5, 10, 15]}
                        />
                      </Box>
                    </Slide>
                  </Grid>
                </Grid>
              </AntTabPanel>
              <AntTabPanel value={value} index={8} sx={{ padding: '24px' }}>
                <Alerts
                  value={value}
                  getAllAlerts={getAllAlerts}
                  entityType="ModelInventory"
                  entityId={modelId}
                  deleteAlert={deleteAlert}
                  allUserList={allUserList}
                  updateAlerts={updateAlerts}
                  createAlerts={createAlerts}
                />
              </AntTabPanel>
            </Box>
          </Box>
        </Grid>
      </Grid>

      <AddTeamMember
        open={AddMember}
        handleClose={() => {
          setAddMember(false);
        }}
        entityId={Number(modelId)}
        addSingleTeamMember={addSingleTeamMember}
        allUserList={allUserList}
        allUserRoles={allUserRoles}
        getAllTeamDetails={() => {
          getTeamDetails({
            entityType: 'ModelInventory',
            entityId: modelId,
          });
        }}
      />
      <CreateAddAssociation
        open={createAndAddAssociation}
        handleClose={() => {
          setCreateAndAddAssociation(false);
        }}
        entityId={Number(modelId)}
        getAssociationDetails={getAssociationDetails}
        currentEntityType="ModelInventory"
        getAllAssociation={() => {
          getAssociationDetails({
            entityType: 'ModelInventory',
            entityId: modelId,
          });
        }}
      />
      <AddAssociationModal
        open={addAssociation}
        handleClose={() => {
          setAddAssociation(false);
        }}
        getAllModelEntity={getAllModelEntity}
        createModelThirdStep={createModelThirdStep}
        entityId={Number(modelId)}
        getAllAssociation={() => {
          getAssociationDetails({
            entityType: 'ModelInventory',
            entityId: modelId,
          });
        }}
      />
      {/* <EditModelAttributesDetails
        open={editModelDetails}
        attributeDetails={attributeDetails}
        handleClose={() => {
          setEditModelDetails(!editModelDetails);
        }}
        createModelSecondStep={createModelSecondStep}
        entityId={Number(modelId)}
        fromDetails={fromDetails}
      /> */}
      <DocumentUploadModal
        open={addDocument}
        handleClose={() => {
          setAddDocument(false);
        }}
        isMultiple={false}
        enitityType="ModelInventory"
        entityId={Number(modelId)}
        attachDocument={attachDocument}
      />
      <DeleteModal
        open={isDeleteModalOpen}
        handleClose={closeDeleteModal}
        deleteConfirm={deleteConfirm}
        alertLabelText="Do you want to delete this model?"
      />
    </Box>
  );
};

export default EditModelDetails;
