/* eslint-disable no-unused-vars */
/* eslint-disable react/no-unstable-nested-components */
import React, { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  Button,
  Typography,
  Divider,
  Tabs,
  Tab,
  TextField,
  IconButton,
  Stack,
} from '@mui/material';
import { useSelector } from 'react-redux';
import InputAdornment from '@mui/material/InputAdornment';
import SearchIcon from '@mui/icons-material/Search';
import { useSearchParams } from 'react-router-dom';
import { styled } from '@mui/material/styles';
import DeleteIcon from '@mui/icons-material/Delete';
import PropTypes from 'prop-types';
import useMediaQuery from '@mui/material/useMediaQuery';
import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';

import { useTheme } from '@emotion/react';
import Breadcrumb from '../../components/Common/Breadcrumb';
import { TabPanel } from '../../components/Common/Tabs';
import useModelInventory from '../../hooks/ModelInventory/useModelInventory';
import ReactMuiTableListView from '../../components/Common/ReactMuiTableListView';
import AddTeamMember from '../../components/ModelInventory/AddTeamMember';
import AddAssociationModal from '../../components/ModelInventory/AddAssociationModal';
import EditModelAttributesDetails from '../../components/ModelInventory/EditModelAttributesDetails';
import useEntity from '../../hooks/Configuration/useEntity';
import SwalToast from '../../components/Common/SwalTost';

const AntTab = styled(Tab)(({ theme }) => ({
  minHeight: '25px',
  marginBottom: '5px',
  display: 'flex',
  justifyContent: 'flex-start',
  padding: '8px',
  color: theme.palette.primary.main,
  '&.Mui-selected': {
    backgroundColor: theme.palette.primary.main,
    borderRadius: '3px',
    color: `${theme.palette.text.light} !important`,
  },
}));
const AntTabPanel = styled(TabPanel)(() => ({
  padding: '24px',
  paddingTop: '0px',
  width: '100%',
}));
const CustomTextField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-input': {
    padding: '10px !important',
  },
  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      borderColor: theme.palette.primary.main,
    },
  },
}));

const columns = [
  {
    heading: 'USER',
    accessor: 'user',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'TYPE',
    accessor: 'model_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'ROLE',
    accessor: 'role',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'EMAIL',
    accessor: 'description',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];
const AssociationColumns = [
  {
    heading: 'ASSOCIATION ID',
    accessor: 'associated_id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'ASSOCIATION NAME',
    accessor: 'association_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'ASSOCIATION TYPE',
    accessor: 'association_type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CREATED BY',
    accessor: 'created_at',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CREATED BY',
    accessor: 'created_by',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];
const ModelHistoryColumns = [
  {
    heading: 'MODEL ID',
    accessor: 'model_id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
  },
  {
    heading: 'CHANGE RECORD VERSION',
    accessor: 'record_version',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CHANGED DESC',
    accessor: 'changed_desc',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CHANGED BY',
    accessor: 'changed_by',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'UPDATED DATE',
    accessor: 'updated_date',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];
const historyData = [
  {
    model_id: 1,
    record_version: 12,
    changed_desc: 'changed Desc',
    changed_by: 'laxman',
    updated_date: '06/09/199',
  },
  {
    model_id: 2,
    record_version: 12,
    changed_desc: 'changed Desc',
    changed_by: 'laxman',
    updated_date: '06/09/199',
  },
  {
    model_id: 3,
    record_version: 12,
    changed_desc: 'changed Desc',
    changed_by: 'laxman',
    updated_date: '06/09/199',
  },
];

const SUMMARY_LABELS = {
  type: 'Type',
  assignedUser: 'Assigned User',
  model_name: 'Model Name',
  model_id: 'Model Id',
  created_at: 'Created At',
  updated_at: 'Updated At',
  created_by: 'Created By',
  updated_by: 'Updated By',
  description: 'Description',
};

// eslint-disable-next-line no-unused-vars
const RowLevelOnHoverOptions = ({
  containerSx,
  row,
  className,
  removeTeamMember,
  modelId,
  getTeamDetails,
}) => {
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          {row?.original?.role !== 'Primary Owner' ? (
            <IconButton
              size="small"
              title="Remove team member"
              onClick={() => {
                removeTeamMember({
                  entity_type: 'ModelInventory',
                  entity_id: modelId,
                  username: row?.original?.user,
                  role: row?.original?.role,
                }).then(() => {
                  getTeamDetails({
                    entityType: 'ModelInventory',
                    entityId: modelId,
                  });
                  SwalToast({
                    icon: 'success',
                    title: 'Team member removed successfully.',
                  });
                });
              }}
            >
              <DeleteIcon color="primary" />
            </IconButton>
          ) : null}
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  modelId: PropTypes.number.isRequired,
  removeTeamMember: PropTypes.func.isRequired,
  getTeamDetails: PropTypes.func.isRequired,
};
const RowLevelOnHoverAssociationOptions = ({
  containerSx,
  row,
  className,
  removeModelAssociation,
  modelId,
  getAssociationDetails,
}) => {
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            title="Delete Team Association"
            onClick={() => {
              removeModelAssociation({
                entity_type: 'ModelInventory',
                entity_id: modelId,
                associated_id: row?.original?.associated_id,
                association_type: row?.original?.association_type,
              }).then(() => {
                SwalToast({
                  icon: 'success',
                  title: 'Associated model removed successfully.',
                });
                getAssociationDetails({
                  entityType: 'ModelInventory',
                  entityId: modelId,
                });
              });
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverAssociationOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  removeModelAssociation: PropTypes.func.isRequired,
  getAssociationDetails: PropTypes.func.isRequired,
  modelId: PropTypes.number.isRequired,
};
const RowLevelOnHoverHistoryOptions = ({ containerSx, row, className }) => {
  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton size="small" title="Delete History" onClick={() => {}}>
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};
RowLevelOnHoverHistoryOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
};
const EditModelDetails = () => {
  const theme = useTheme();
  const { getCustomEntityTemplate } = useEntity();
  const { userData } = useSelector((state) => state.users);
  const {
    getAttributeDetails,
    getTeamDetails,
    teamDetails,
    getAllModelEntity,
    createModelThirdStep,
    getAssociationDetails,
    associationDetails,
    allModelList,
    createModelSecondStep,
    addSingleTeamMember,
    getAllUsers,
    sendForApproval,
    getAllRoles,
    removeTeamMember,
    removeModelAssociation,
  } = useModelInventory();
  const isMd = useMediaQuery(theme.breakpoints.down('md'));
  const [attributeDetails, setAttributeDetails] = useState([]);
  const [fromDetails, setFormDetails] = useState([]);
  const [AddMember, setAddMember] = useState(false);
  const [addAssociation, setAddAssociation] = useState(false);
  const [currentModel, setCurrentModel] = useState({});
  const [editModelDetails, setEditModelDetails] = useState(false);
  const [allUserList, setAllUserList] = useState([]);
  const [allUserRoles, setAllUserRoles] = useState([]);
  const [breadcrumbsMenu, setBreadcrumbsMenu] = useState([
    { id: 1, name: 'ModelInventory', path: '/model-inventory' },
  ]);
  const [value, setValue] = React.useState(1);
  const [searchParams] = useSearchParams();
  React.useMemo(() => {
    if (searchParams.get('modelId') && breadcrumbsMenu?.length < 2) {
      setBreadcrumbsMenu((old) => [
        ...old,
        { id: 2, name: searchParams.get('modelId') },
      ]);
      getAllModelEntity({ entityType: 'ModelInventory' }).then((res) => {
        if (res) {
          setCurrentModel(
            res?.data?.modelEntity?.filter(
              (model) => model?.model_id === Number(searchParams.get('modelId'))
            )[0]
          );
        }
      });
    }
    getAllUsers().then((res) => {
      if (res) {
        setAllUserList(res?.data);
      }
    });
    getAllRoles().then((res) => {
      if (res) {
        setAllUserRoles(res?.data);
      }
    });
  }, [searchParams]);
  useEffect(() => {
    if (currentModel?.type)
      getCustomEntityTemplate({
        entityName: currentModel?.type,
      }).then((resp) => {
        if (resp) {
          setFormDetails(resp?.data?.Entity?.[currentModel?.type]?.sections);
        }
      });
  }, [currentModel]);
  useEffect(() => {
    getAttributeDetails({
      entityType: 'ModelInventory',
      entityId: searchParams.get('modelId'),
    }).then((res) => {
      if (res) {
        setAttributeDetails(res?.data?.data);
      }
    });
    if (searchParams.get('modelId')) {
      getTeamDetails({
        entityType: 'ModelInventory',
        entityId: searchParams.get('modelId'),
      });
      getAssociationDetails({
        entityType: 'ModelInventory',
        entityId: searchParams.get('modelId'),
      });
    }
  }, [searchParams]);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const SendModelForNextStage = (modelId, status) => {
    sendForApproval({
      entity_id: modelId,
      entity_type: 'ModelInventory',
      approved: status,
    }).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: `Model ${status ? 'approved' : 'rejected'} Successfully.`,
        });
      }
    });
  };

  return (
    <Box>
      <Grid container xs={12}>
        <Grid
          container
          item
          xs={12}
          display="flex"
          justifyContent="space-between"
        >
          <Box>
            <Breadcrumb BreadcrumbsMen={breadcrumbsMenu} />
          </Box>
        </Grid>
        <Grid
          container
          item
          xs={12}
          sx={{ height: !isMd ? 'calc(100vh - 199px)' : 'auto' }}
        >
          <Grid item container xs={12} sx={{}} md={2} mt={1}>
            <Tabs
              value={value}
              onChange={handleChange}
              orientation={isMd ? 'horizontal' : 'vertical'}
              variant="scrollable"
              sx={() => {
                return {
                  border: 'none',
                  width: '99%',
                  '& .MuiTabs-indicator ': {
                    display: 'none',
                  },
                };
              }}
            >
              <Typography mt={1} mb={2} mr={1}>
                Actions
              </Typography>
              <AntTab label="Summary" />
              <AntTab label="Details" />
              <AntTab label="Preview" />
              <AntTab label="Association" />
              <AntTab label="Team" />
              <AntTab label="Notes" />
              <AntTab label="History" />
            </Tabs>
            <Divider
              sx={{ backgroundColor: (_theme) => _theme.palette.other.grey1 }}
              light
              orientation={isMd ? 'horizontal' : 'vertical'}
            />
          </Grid>

          <Grid item container xs={12} md={10}>
            <Grid item xs={12}>
              <AntTabPanel height="100%" value={value} index={1} sx={{}}>
                <Grid
                  item
                  container
                  display="flex"
                  flexDirection="column"
                  justifyContent="space-between"
                  xs={12}
                >
                  <Grid item container xs={12}>
                    <Grid mt={1} item xs={12} spacing={2} display="flex">
                      <Typography component="h1" variant="h3">
                        {`Status : ${currentModel.status}`}
                      </Typography>
                    </Grid>
                    {Object?.keys(currentModel || {})?.map((attribute, i) => {
                      return (
                        <Grid
                          mt={1}
                          item
                          xs={12}
                          sm={6}
                          md={4}
                          mb={2}
                          spacing={2}
                          display="flex"
                          // eslint-disable-next-line react/no-array-index-key
                          key={i}
                        >
                          {SUMMARY_LABELS[attribute] ? (
                            <>
                              <Typography component="div" variant="h4">
                                {`${SUMMARY_LABELS[attribute]} :`}
                              </Typography>
                              <Typography ml={2} variant="h5">
                                {currentModel[attribute]}
                              </Typography>
                            </>
                          ) : null}
                        </Grid>
                      );
                    })}
                  </Grid>
                  <Grid item sx={{}} xs={12}>
                    {userData?.username === currentModel?.assignedUser ? (
                      <Stack
                        mt={10}
                        direction="row"
                        display="flex"
                        position="fixed"
                        bottom={25}
                        right={25}
                        justifyContent="flex-end"
                        spacing={3}
                      >
                        <Button variant="outlined">DELETE</Button>

                        <Button
                          variant="outlined"
                          onClick={() => {
                            setEditModelDetails(true);
                          }}
                        >
                          EDIT
                        </Button>
                        {currentModel.status !== 'Draft' ? (
                          <>
                            <Button
                              variant="outlined"
                              onClick={() => {
                                SendModelForNextStage(
                                  currentModel?.model_id,
                                  false
                                );
                              }}
                            >
                              REJECT
                            </Button>
                            <Button
                              variant="outlined"
                              onClick={() => {
                                SendModelForNextStage(
                                  currentModel?.model_id,
                                  true
                                );
                              }}
                            >
                              Approve
                            </Button>
                          </>
                        ) : (
                          <Button
                            variant="outlined"
                            onClick={() => {
                              SendModelForNextStage(
                                currentModel?.model_id,
                                true
                              );
                            }}
                          >
                            SEND FOR APPROVAL
                          </Button>
                        )}
                        <Button variant="contained">SYNC WITH NIMBUS</Button>
                      </Stack>
                    ) : null}
                  </Grid>
                </Grid>
              </AntTabPanel>
              <AntTabPanel
                value={value}
                index={2}
                sx={{ padding: '24px', width: '100%' }}
              >
                <Grid container item xs={12} width="100%">
                  {Object?.keys(attributeDetails || {})?.map(
                    (section, index) => {
                      return (
                        <Grid item xs={12} width="100%" key={section}>
                          <Typography variant="h3">{section}</Typography>
                          <Divider
                            sx={{
                              backgroundColor: (_theme) =>
                                _theme.palette.other.grey1,
                            }}
                            light
                            orientation="horizontal"
                          />
                          <Grid item container xs={12}>
                            {Object?.keys(attributeDetails[section] || {})?.map(
                              (attribute, i) => {
                                return (
                                  <Grid
                                    mt={1}
                                    item
                                    xs={12}
                                    sm={6}
                                    md={4}
                                    spacing={2}
                                    display="flex"
                                    // eslint-disable-next-line react/no-array-index-key
                                    key={i}
                                  >
                                    <Typography
                                      component="div"
                                      variant="subtitle1"
                                    >{`${fromDetails[index]?.attributes[i]?.label} :`}</Typography>
                                    <Typography ml={2} variant="subtitle">
                                      {attributeDetails[section]?.[attribute]}
                                    </Typography>
                                  </Grid>
                                );
                              }
                            )}
                          </Grid>
                        </Grid>
                      );
                    }
                  )}
                </Grid>
              </AntTabPanel>
              <AntTabPanel value={value} index={3} sx={{}}>
                Preview Development in progress .....
              </AntTabPanel>
              <AntTabPanel value={value} index={4} sx={{}}>
                <Grid container item xs={12} spacing={4}>
                  <Grid item xs={12} display="flex" columnGap={2}>
                    <Grid item xs={7} md={10} flexGrow>
                      <CustomTextField
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton>
                                <SearchIcon />
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                        sx={{}}
                        placeholder="Search filter"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={5}
                      md={2}
                      display="flex"
                      justifyContent="flex-end"
                    >
                      <Button
                        variant="contained"
                        onClick={() => {
                          setAddAssociation(!addAssociation);
                        }}
                        sx={{ whiteSpace: 'nowrap' }}
                      >
                        Add Association
                      </Button>
                    </Grid>
                  </Grid>
                  <Grid item xs={12}>
                    <ReactMuiTableListView
                      data={
                        associationDetails?.Association?.length > 0
                          ? associationDetails?.Association
                          : []
                      }
                      columns={AssociationColumns}
                      rowLevelOnHoverOptions={({
                        containerSx,
                        row,
                        className,
                      }) => {
                        return (
                          <RowLevelOnHoverAssociationOptions
                            containerSx={containerSx}
                            row={row}
                            className={className}
                            removeModelAssociation={removeModelAssociation}
                            modelId={Number(searchParams.get('modelId'))}
                            getAssociationDetails={getAssociationDetails}
                          />
                        );
                      }}
                      getHeaderProps={() => ({
                        style: {
                          display: 'flex',
                          alignItems: 'center',
                        },
                      })}
                      getRowProps={() => ({
                        style: {
                          position: 'relative',
                        },
                      })}
                      enableRowSelection={false}
                      pageCount={associationDetails?.Association?.length}
                      enablePagination={true}
                      initialPageSize={10}
                      rowsPerPageOptions={[5, 10, 15]}
                    />
                  </Grid>
                </Grid>
              </AntTabPanel>
              <AntTabPanel value={value} index={5} sx={{}}>
                <Grid container item xs={12} spacing={4}>
                  <Grid item xs={12} display="flex" columnGap={2}>
                    <Grid item xs={7} md={10} flexGrow>
                      <CustomTextField
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">
                              <IconButton>
                                <SearchIcon />
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                        sx={{}}
                        placeholder="Search filter"
                      />
                    </Grid>
                    <Grid
                      item
                      xs={5}
                      md={2}
                      display="flex"
                      justifyContent="flex-end"
                    >
                      <Button
                        variant="contained"
                        onClick={() => {
                          setAddMember(!AddMember);
                        }}
                        sx={{ whiteSpace: 'nowrap' }}
                      >
                        Add Member
                      </Button>
                    </Grid>
                  </Grid>
                  <Grid item xs={12}>
                    <ReactMuiTableListView
                      data={
                        teamDetails?.team_member?.length
                          ? teamDetails?.team_member
                          : []
                      }
                      columns={columns}
                      rowLevelOnHoverOptions={({
                        containerSx,
                        row,
                        className,
                      }) => {
                        return (
                          <RowLevelOnHoverOptions
                            containerSx={containerSx}
                            row={row}
                            className={className}
                            removeTeamMember={removeTeamMember}
                            modelId={Number(searchParams.get('modelId'))}
                            getTeamDetails={getTeamDetails}
                          />
                        );
                      }}
                      getHeaderProps={() => ({
                        style: {
                          display: 'flex',
                          alignItems: 'center',
                        },
                      })}
                      getRowProps={() => ({
                        style: {
                          position: 'relative',
                        },
                      })}
                      enableRowSelection={false}
                      pageCount={teamDetails?.team_member?.length}
                      enablePagination={true}
                      initialPageSize={10}
                      rowsPerPageOptions={[5, 10, 15]}
                    />
                  </Grid>
                </Grid>
              </AntTabPanel>
              <TabPanel value={value} index={6} sx={{ padding: '24px' }}>
                Notes Development in progress ....
              </TabPanel>
              <TabPanel value={value} index={7} sx={{ padding: '24px' }}>
                <Grid item container xs={12} rowSpacing={2}>
                  <Grid item xs={12} md={10}>
                    <Typography variant="h4">Model History</Typography>
                  </Grid>
                  <Grid item xs={12} md={10}>
                    <Divider
                      sx={{
                        backgroundColor: (_theme) => _theme.palette.other.grey1,
                      }}
                      light
                      orientation="horizontal"
                    />
                  </Grid>
                  <Grid item container xs={12} md={10}>
                    <Grid item xs={12} md={10} display="flex">
                      <Grid item xs={12} md={5} display="flex">
                        <Typography variant="subtitle1">Model ID</Typography>
                        <Typography variant="subtitle">: 12</Typography>
                      </Grid>
                      <Grid xs={12} md={5} display="flex">
                        <Typography variant="subtitle1">Model Name </Typography>
                        <Typography variant="subtitle"> : 12</Typography>
                      </Grid>
                    </Grid>
                  </Grid>
                  <Grid item xs={12}>
                    <ReactMuiTableListView
                      data={historyData?.length > 0 ? historyData : []}
                      columns={ModelHistoryColumns}
                      rowLevelOnHoverOptions={({
                        containerSx,
                        row,
                        className,
                      }) => {
                        return (
                          <RowLevelOnHoverHistoryOptions
                            containerSx={containerSx}
                            row={row}
                            className={className}
                          />
                        );
                      }}
                      getHeaderProps={() => ({
                        style: {
                          display: 'flex',
                          alignItems: 'center',
                        },
                      })}
                      getRowProps={() => ({
                        style: {
                          position: 'relative',
                        },
                      })}
                      enableRowSelection={false}
                      pageCount={historyData?.length}
                      enablePagination={true}
                      initialPageSize={10}
                      rowsPerPageOptions={[5, 10, 15]}
                    />
                  </Grid>
                </Grid>
              </TabPanel>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <AddTeamMember
        open={AddMember}
        handleClose={() => {
          setAddMember(false);
        }}
        entityId={Number(searchParams.get('modelId'))}
        addSingleTeamMember={addSingleTeamMember}
        allUserList={allUserList}
        allUserRoles={allUserRoles}
      />
      <AddAssociationModal
        open={addAssociation}
        handleClose={() => {
          setAddAssociation(false);
        }}
        getAllModelEntity={getAllModelEntity}
        createModelThirdStep={createModelThirdStep}
        entityId={Number(searchParams.get('modelId'))}
      />
      <EditModelAttributesDetails
        open={editModelDetails}
        attributeDetails={attributeDetails}
        handleClose={() => {
          setEditModelDetails(!editModelDetails);
        }}
        createModelSecondStep={createModelSecondStep}
        entityId={Number(searchParams.get('modelId'))}
        fromDetails={fromDetails}
      />
    </Box>
  );
};

export default EditModelDetails;
