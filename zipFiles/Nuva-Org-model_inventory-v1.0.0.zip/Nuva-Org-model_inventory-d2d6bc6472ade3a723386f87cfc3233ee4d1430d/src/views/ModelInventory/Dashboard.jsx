/* eslint-disable react/no-array-index-key */
/* eslint-disable react/no-unstable-nested-components */
import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import {
  Box,
  Grid,
  Typography,
  Card,
  CardContent,
  IconButton,
  Tabs,
  Tab,
  Slide,
} from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import { useNavigate } from 'react-router-dom';
import { ReactMuiTableColumnHeaderTextEllipsis } from 'solytics-frontend';
import { styled } from '@mui/material/styles';

import SwalToast from '../../components/Common/SwalTost';
import ReactMuiTableListView from '../../components/Common/ReactMuiTableListView';
import Breadcrumb from '../../components/Common/Breadcrumb';
import useModelInventory from '../../hooks/ModelInventory/useModelInventory';
import useDashboard from '../../hooks/ModelInventory/useDashboard';
import { TabPanel } from '../../components/Common/Tabs';
import AllNetworks from '../../components/ModelInventory/Dashboard/AllNetworks';
import SearchTextField from '../../components/Common/SearchTextField';
import DeleteModal from '../../components/Common/Modals/DeleteModal';

const MuiTabPanel = styled(TabPanel)(() => ({
  padding: '0px',
  paddingTop: '0px',
  width: '100%',
}));

const MuiTab = styled(Tab)(({ theme }) => ({
  minHeight: '25px',
  marginBottom: '5px',
  display: 'flex',
  justifyContent: 'flex-start',
  padding: '8px',
  '&.Mui-selected': {
    borderRadius: '3px',
    color: `${theme.palette.primary.main} !important`,
  },
}));
const columns = [
  {
    heading: 'ID',
    accessor: 'model_id',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 100,
    Cell: ({ row }) => row?.original?.model_id ?? row?.original?.association_id,
  },
  {
    heading: 'NAME',
    accessor: 'model_name',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
    Cell: ({ row }) =>
      row?.original?.model_name ?? row?.original?.association_name,
  },
  {
    heading: 'STATUS',
    accessor: 'status',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 150,
  },
  {
    heading: 'TYPE',
    accessor: 'type',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CREATED BY',
    accessor: 'created_by',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'ASSIGNED TO',
    accessor: 'assignedUser',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'CREATED DATE',
    accessor: 'created_at',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
  {
    heading: 'UPDATED DATE',
    accessor: 'updated_at',
    Header: ReactMuiTableColumnHeaderTextEllipsis,
    width: 200,
  },
];

const RowLevelOnHoverOptions = ({
  containerSx,
  row,
  className,
  deleteModel,
}) => {
  const history = useNavigate();

  return (
    <Box
      component="td"
      id="pageRow"
      sx={{
        ...containerSx,
        width: '100%',
        paddingTop: '3px',
        position: 'absolute',
        zIndex: 1000,
      }}
      className={className}
    >
      <Box
        sx={{
          display: 'flex',
        }}
      >
        <Box
          sx={(theme) => {
            return {
              flex: 1,
              backgroundImage: theme.palette.other.gradient1,
              opacity: 0.5,
            };
          }}
        />
        <Box
          sx={(theme) => {
            return {
              display: 'flex',
              pr: '20px',
              gap: '8px',
              padding: '1px',
              backgroundImage: theme.palette.other.gradient2,
            };
          }}
        >
          <IconButton
            size="small"
            onClick={() => {
              if (row?.original?.model_id) {
                history({
                  pathname: `/model-inventory/${row?.original?.model_id}`,
                });
              } else {
                history({
                  pathname: `/model-association/${row?.original?.association_id}`,
                });
              }
            }}
            title="View model details"
          >
            <VisibilityIcon color="primary" />
          </IconButton>
          <IconButton
            size="small"
            title="Delete model"
            onClick={() => {
              if (row?.original?.model_id) {
                deleteModel('ModelInventory', row?.original?.model_id);
              } else {
                deleteModel('ModelAssociation', row?.original?.association_id);
              }
            }}
          >
            <DeleteIcon color="primary" />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};

RowLevelOnHoverOptions.propTypes = {
  containerSx: PropTypes.oneOfType([PropTypes.object]).isRequired,
  row: PropTypes.oneOfType([PropTypes.object]).isRequired,
  className: PropTypes.string.isRequired,
  deleteModel: PropTypes.func.isRequired,
};

const Dashboard = () => {
  const BreadcrumbsMenu = [{ id: 1, name: 'Dashboard' }];
  const [ActiveFilter, setActiveFilter] = useState({});
  const [filters, setFilters] = useState([]);
  const [filterDataList, setFilterDataList] = useState([]);
  const [tabValue, setTabValue] = useState(0);
  const [searchTerm, setSearchTerm] = useState();
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedEntityForDelete, setSelectedEntityForDelete] = useState({});
  const history = useNavigate();

  const { getFilter, getFilterList } = useDashboard();

  const fetchFilterDataList = useCallback(
    (data) => {
      if (data?.filterName) {
        getFilterList({ filterName: data?.filterName }).then((res) => {
          setFilterDataList(res?.data);
        });
      }
    },
    [ActiveFilter]
  );

  useEffect(() => {
    getFilter().then((res) => {
      setFilters(res?.data);
      setActiveFilter(res?.data[0] || {});
      fetchFilterDataList(res?.data[0]);
    });
  }, []);

  const { deleteModelEntity } = useModelInventory();

  const deleteModel = (entityType, entityId = 0) => {
    setSelectedEntityForDelete({ entityType, entityId });
    setIsDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
  };

  const deleteConfirm = () => {
    deleteModelEntity({ ...selectedEntityForDelete }).then((res) => {
      if (res) {
        SwalToast({
          icon: 'success',
          title: 'Model deleted successfully.',
        });
        fetchFilterDataList(ActiveFilter);
        closeDeleteModal();
      }
    });
  };

  const CountCard = ({
    minWidth = 170,
    variant = 'outlined',
    Active,
    filter,
  }) => {
    return (
      <Card
        variant={variant}
        sx={(theme) => {
          return {
            backgroundColor: Active
              ? theme.palette.primary.main
              : theme.palette.primary.contrastText,
            height: 80,
            border: `1px solid ${theme.palette.primary.main}`,
          };
        }}
        onClick={() => {
          setActiveFilter(filter);
          fetchFilterDataList(filter);
        }}
      >
        <CardContent sx={{ width: minWidth, cursor: 'pointer' }}>
          <Box display="flex" alignItems="center" flexDirection="column">
            <Typography
              align="center"
              variant="h2"
              fontWeight="bold"
              sx={(theme) => {
                return {
                  color: Active
                    ? theme.palette.text.light
                    : theme.palette.primary.main,
                };
              }}
            >
              {filter?.count}
            </Typography>
            <Typography
              align="center"
              sx={(theme) => {
                return {
                  color: Active
                    ? theme.palette.text.light
                    : theme.palette.primary.main,
                  width: minWidth - 32,
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                };
              }}
              fontWeight="bold"
              title={filter?.filterName}
            >
              {filter?.filterName}
            </Typography>
          </Box>
        </CardContent>
      </Card>
    );
  };
  CountCard.propTypes = {
    Active: PropTypes.bool.isRequired,
    minWidth: PropTypes.string.isRequired,
    variant: PropTypes.string.isRequired,
    filter: PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.object]))
      .isRequired,
  };
  const handleChange = (event, newValue) => {
    setTabValue(newValue);
  };
  return (
    <Grid container>
      <Grid item xs={12} display="flex" justifyContent="space-between" mb={2}>
        <Box>
          <Breadcrumb BreadcrumbsMen={BreadcrumbsMenu} />
        </Box>
        <Box pr={1} overflow="auto">
          <Tabs
            value={tabValue}
            onChange={handleChange}
            variant="scrollable"
            sx={() => {
              return {
                border: 'none',
                '& .MuiTabs-indicator ': {
                  display: 'none',
                },
              };
            }}
          >
            <MuiTab title="Filter View" label="Filters" />
            <MuiTab title="Dashboard View" label="Dashboard" />
            <MuiTab title="Network" label="Network" />
          </Tabs>
        </Box>
      </Grid>

      <Grid item xs={12}>
        <MuiTabPanel value={tabValue} index={0}>
          <>
            <Box
              display="flex"
              sx={{ overflowX: 'scroll' }}
              flexDirection="row"
            >
              {filters?.map((filter, index) => {
                return (
                  <Box
                    display="flex"
                    alignItems="center"
                    m={2}
                    key={index}
                    flexWrap="wrap"
                  >
                    <CountCard
                      filter={filter}
                      Active={ActiveFilter?.filterName === filter?.filterName}
                      setActiveFilter={setActiveFilter}
                    />
                  </Box>
                );
              })}
              <Box display="flex" alignItems="center">
                <Card
                  variant="contained"
                  m={2}
                  sx={(theme) => {
                    return {
                      height: 77,
                      borderStyle: 'solid',
                      borderWidth: 2,
                      borderColor: theme.palette.primary.main,
                    };
                  }}
                >
                  <CardContent sx={{ minWidth: 170 }}>
                    <Box
                      display="flex"
                      alignItems="center"
                      flexDirection="column"
                      sx={{ cursor: 'pointer' }}
                      onClick={() => {
                        history({
                          pathname: '/model-inventory',
                          search: `?filter=true`,
                        });
                      }}
                    >
                      <AddCircleOutlineIcon
                        sx={{
                          width: '30px',
                          height: '25px',
                          color: (theme) => theme.palette.primary.main,
                        }}
                      />
                      <Typography
                        align="center"
                        fontWeight="bold"
                        mt={1}
                        sx={{
                          color: (theme) => theme.palette.primary.main,
                        }}
                      >
                        Add Filter
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Box>
            </Box>
            {filterDataList?.length > 0 ? (
              <Box mt={3}>
                <SearchTextField
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search"
                />
              </Box>
            ) : null}
            <Box
              sx={{
                overflow: 'scroll',
                height: `calc(100vh - 450px)`,
                width: '100%',
              }}
              mt={2}
            >
              {filterDataList?.length > 0 ? (
                <Slide direction="left" timeout={1000} mountOnEnter in={true}>
                  <Box>
                    <ReactMuiTableListView
                      data={filterDataList}
                      columns={columns}
                      // eslint-disable-next-line react/no-unstable-nested-components
                      rowLevelOnHoverOptions={({
                        containerSx,
                        row,
                        className,
                      }) => {
                        return (
                          <RowLevelOnHoverOptions
                            containerSx={containerSx}
                            row={row}
                            className={className}
                            deleteModel={deleteModel}
                          />
                        );
                      }}
                      getHeaderProps={() => ({
                        style: {
                          display: 'flex',
                          alignItems: 'center',
                        },
                      })}
                      getRowProps={() => ({
                        style: {
                          position: 'relative',
                        },
                      })}
                      enableRowSelection={false}
                      pageCount={filterDataList?.length}
                      enablePagination={true}
                      initialPageSize={10}
                      initialGlobalFilter={searchTerm}
                      rowsPerPageOptions={[5, 7, 10, 15]}
                    />
                  </Box>
                </Slide>
              ) : (
                <Box
                  display="flex"
                  sx={{ height: 'calc(100vh  - 500px)' }}
                  flexGrow={1}
                  alignItems="center"
                  flexDirection="column"
                  justifyContent="center"
                >
                  <Typography variant="subtitle1">
                    No data result found.
                  </Typography>
                </Box>
              )}
            </Box>
          </>
        </MuiTabPanel>
        <MuiTabPanel value={tabValue} index={1}>
          <iframe
            style={{
              background: '#FFFF !important',
              border: 'none',
              width: '100%',
              height: `calc(100vh - 250px)`,
            }}
            width="100%"
            title="dashboard"
            src="http://kibana-eks.sams-solytics.com/app/dashboards#/view/cbf36260-cc62-11ed-a49d-99a474748437?embed=true&_g=(filters%3A!()%2CrefreshInterval%3A(pause%3A!t%2Cvalue%3A0)%2Ctime%3A(from%3Anow-15m%2Cto%3Anow))"
          />
        </MuiTabPanel>
        <MuiTabPanel value={tabValue} index={2}>
          <AllNetworks />
        </MuiTabPanel>
      </Grid>
      <DeleteModal
        open={isDeleteModalOpen}
        handleClose={closeDeleteModal}
        deleteConfirm={deleteConfirm}
        alertLabelText="Do you want to delete this model?"
      />
    </Grid>
  );
};

export default Dashboard;
