import React from 'react';
import { Box, Stack } from '@mui/material';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';

import AppHeader from '../../components/AppHeader/AppHeader';
import SidebarConfig from '../../components/Sidebar/SidebarConfig';
import TopNavBar from '../../components/AppHeader/TopNavBar';
import useAuth from '../../hooks/Auth/useAuth';
import useEntity from '../../hooks/Configuration/useEntity';

const Layout = () => {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { getNotification, notificationList, clearAllNotification } = useAuth();
  const { customEntityList } = useEntity();
  const [menus, setMenus] = React.useState(SidebarConfig);
  React.useEffect(() => {
    if (pathname === '/') {
      navigate('/dashboard');
    }
    const copyOfMenu = [...menus];
    copyOfMenu[1].children = [
      {
        name: 'All Association',
        route: '/model-association',
        key: 'modelAssociation',
      },
    ];
    customEntityList().then(
      (resp) => {
        if (resp?.data) {
          resp?.data
            ?.filter((item) => item?.entity_type === 'ModelAssociation')
            ?.forEach((association) => {
              copyOfMenu[1].children?.push({
                name: association?.entity_name,
                route: `/model-association?templateName=${association?.entity_name}`,
                key: 'modelAssociation',
              });
            });

          setMenus([...copyOfMenu]);
        }
      },
      () => {
        // single route
        setMenus([...copyOfMenu]);
      }
    );
  }, []);

  return (
    <Stack direction="column">
      <Box
        position="fixed"
        width="100%"
        zIndex={(theme) => theme.zIndex.appBar}
      >
        <AppHeader
          getNotification={getNotification}
          notificationList={notificationList}
          clearAllNotification={clearAllNotification}
        />
        <TopNavBar SidebarConfig={SidebarConfig} />
      </Box>

      <Box
        mt={15}
        sx={(theme) => {
          return {
            background: theme.palette.primary.contrastText,
          };
        }}
      >
        <Box
          sx={(_theme) => {
            return {
              minHeight: '300px',
              border: `1px solid ${_theme.palette.primary.light}`,
              height: `calc(100vh - 152px)`,
              background: _theme.palette.secondary.contrastText,
              overflow: 'auto',
            };
          }}
          m={2}
          p={2}
        >
          <Outlet />
        </Box>
      </Box>
    </Stack>
  );
};

export default Layout;
