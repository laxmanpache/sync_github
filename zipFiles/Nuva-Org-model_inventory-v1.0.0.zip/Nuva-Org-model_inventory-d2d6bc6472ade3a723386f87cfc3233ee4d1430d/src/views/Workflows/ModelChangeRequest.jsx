import React from 'react';

const ModelChangeRequest = () => {
  return <div>ModelChangeRequest</div>;
};

export default ModelChangeRequest;
