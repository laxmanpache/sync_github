import React from 'react';
import Test from '../../components/Test';

const ModelValidation = () => {
  return (
    <div>
      <Test />
    </div>
  );
};

export default ModelValidation;
