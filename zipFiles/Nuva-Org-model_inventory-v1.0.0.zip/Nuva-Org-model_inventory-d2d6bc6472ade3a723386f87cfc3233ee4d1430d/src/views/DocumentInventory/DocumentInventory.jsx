import React from 'react';

const DocumentInventory = () => {
  return <div>DocumentInventory</div>;
};

export default DocumentInventory;
