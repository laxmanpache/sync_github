import axios from 'axios';
import API_ENDPOINTS from '../../const/ApiEndPoints';
import useAuth from '../Auth/useAuth';

export default function useEntity() {
  const { getAllRoles } = useAuth();
  const createWorkflow = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.WF.CREATE_WORKFLOW}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  const getWorkflowList = () => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.WF.GET_WORKFLOW_LIST}`
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const compileWorkflow = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.WF.COMPILE_FLOW}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const updateWorkflow = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.WF.UPDATE_FLOW}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getSingleWorkflow = (body) => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.WF.GET_SINGLE_WORKFLOW}`,
        { params: body }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  const fetchAllStates = (workflow = 'Default') => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.WF.GET_ALL_STATES}`,
        { params: { workflowType: workflow } }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  return {
    createWorkflow,
    getWorkflowList,
    compileWorkflow,
    updateWorkflow,
    getSingleWorkflow,
    getAllRoles,
    fetchAllStates,
  };
}
