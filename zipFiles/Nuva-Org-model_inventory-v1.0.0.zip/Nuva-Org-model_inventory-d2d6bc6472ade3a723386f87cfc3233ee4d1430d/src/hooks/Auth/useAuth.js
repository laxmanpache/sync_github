import React from 'react';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { loginSuccess } from '../../store/slices/UserSilcer';
import API_ENDPOINTS from '../../const/ApiEndPoints';

export default function useAuth() {
  const [notificationList, setNotificationList] = React.useState([]);
  const dispatch = useDispatch();
  const login = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.AUTH.LOGIN_USER}`,
        body
      )
      .then((res) => {
        dispatch(
          loginSuccess({
            token: res.data.tokens.access_token,
            refresh: res.data.tokens.refresh_token,
            user: res.data.user,
            profile: res.data.profile,
            remember: body.remember_me,
          })
        );
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getAllUsers = () => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.AUTH.GET_ALL_USER}`
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getAllRoles = () => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.AUTH.GET_ALL_ROLES}`
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getNotification = () => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.AUTH.GET_NOTIFICATION}`
      )
      .then((res) => {
        setNotificationList(res?.data);
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const clearAllNotification = () => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.AUTH.CLEAR_NOTIFICATION}`
      )
      .then((res) => {
        setNotificationList(res?.data || []);
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  return {
    login,
    getAllUsers,
    getAllRoles,
    getNotification,
    notificationList,
    clearAllNotification,
  };
}
