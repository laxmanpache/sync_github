import { useState } from 'react';
import axios from 'axios';
import API_ENDPOINTS from '../../const/ApiEndPoints';

export default function useRules() {
  const [allRules, setAllRules] = useState([]);

  const fetchRules = (body) => {
    return axios
      .get(`${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.RR.RULES}`, {
        params: body,
      })
      .then((res) => {
        setAllRules(res?.data);
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const createRule = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.RR.RULES}`,
        body
      )
      .then((res) => {
        fetchRules();
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  const updateRule = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.RR.RULES}`,
        body,
        { params: { ruleId: body.id } }
      )
      .then((res) => {
        fetchRules();
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  const deleteRule = (body) => {
    return axios
      .delete(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.RR.RULES}`,
        { params: { ruleId: body.id } }
      )
      .then((res) => {
        fetchRules();
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  return { allRules, fetchRules, updateRule, createRule, deleteRule };
}
