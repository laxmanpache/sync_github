import { useState } from 'react';
import axios from 'axios';
import API_ENDPOINTS from '../../const/ApiEndPoints';
import useAuth from '../Auth/useAuth';

export default function useModelInventory() {
  const [allModelList, setAllModelList] = useState([]);
  const [teamDetails, setTeamDetails] = useState([]);
  const [associationDetails, setAssociationDetails] = useState([]);
  const [documentsList, setDocumentsList] = useState([]);
  const { getAllUsers, getAllRoles } = useAuth();

  const getAllModelEntity = (body) => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.READ_ALL_MODEL_ENTITY}`,
        { params: body }
      )
      .then((res) => {
        setAllModelList(res?.data?.modelEntity);
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  // CREATE_MODEL_ENTITY_SECOND_STEP
  const createModelFirstStep = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.CREATE_MODEL_ENTITY_FIRST_STEP}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const createModelSecondStep = (body, parms) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.CREATE_MODEL_ENTITY_SECOND_STEP}`,
        body,
        { params: parms }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const createModelThirdStep = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.CREATE_MODEL_ENTITY_THIRD_STEP}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const createModelForthStep = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.CREATE_MODEL_ENTITY_FORTH_STEP}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getAttributeDetails = (body) => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.ATTRIBUTE_DETAILS}`,
        { params: body }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getTeamDetails = (body) => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.TEAM_DETAILS}`,
        { params: body }
      )
      .then((res) => {
        setTeamDetails(res?.data?.Team);
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getAssociationDetails = (body) => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.ASSOCIATION_DETAILS}`,
        { params: body }
      )
      .then((res) => {
        setAssociationDetails(res?.data);
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const addSingleTeamMember = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.ADD_SINGLE_TEAM_MEMBER}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const deleteModelEntity = (body) => {
    return axios
      .delete(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.DELETE_ENTITY}`,
        { params: body }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const sendForApproval = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.MODEL_APPROVE}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const removeTeamMember = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.REMOVE_TEAM_MEMBER}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const removeModelAssociation = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.REMOVE_MODEL_ASSOCIATION}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getSingleEntityDetails = (body) => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.GET_SINGLE_ENTITY}`,
        { params: body }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  const fetchDocumentsList = (body) => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.DOC.MODEL_DOCUMENTS}`,
        { params: body }
      )
      .then((res) => {
        setDocumentsList(res?.data);
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  const attachDocument = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.DOC.MODEL_DOCUMENTS}`,
        body,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      )
      .then((res) => {
        const data = JSON.parse(body?.data);
        fetchDocumentsList({
          entityType: data?.entity_type,
          entityId: data?.entity_id,
        });
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  const deleteAttchedDocument = (body) => {
    return axios
      .delete(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.DOC.MODEL_DOCUMENTS}`,
        {
          params: {
            documentID: body.documentId,
          },
        }
      )
      .then((res) => {
        fetchDocumentsList({
          entityType: body?.entityType,
          entityId: body?.entityId,
        });
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getHistory = (body) => {
    return axios
      .get(`${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.HISTORY}`, {
        params: body,
      })
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getAllNotes = (body) => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.GET_NOTES}`,
        {
          params: body,
        }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const addNote = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.ADD_NOTES}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const saveFilter = (body) =>
    axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.SAVE_FILTER}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });

  const deleteFilter = (body) => {
    return axios
      .delete(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.DELETE_FILTER}`,
        { params: body }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const editFilter = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.DELETE_FILTER}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getAllAlerts = (body) => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.GET_ALERTS}`,
        {
          params: body,
        }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const updateAlerts = (body) => {
    return axios
      .patch(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.GET_ALERTS}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const createAlerts = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.GET_ALERTS}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const deleteAlert = (body) => {
    return axios
      .delete(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.GET_ALERTS}`,
        { params: body }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const updateModelEntity = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.MI.UPDATE_MODEL}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getSearchList = (body) => {
    return axios
      .post(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.DB.FULL_SEARCH}`,
        body
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  return {
    getAllModelEntity,
    createModelFirstStep,
    createModelSecondStep,
    createModelThirdStep,
    createModelForthStep,
    setAllModelList,
    allModelList,
    getAttributeDetails,
    getTeamDetails,
    teamDetails,
    getAssociationDetails,
    associationDetails,
    addSingleTeamMember,
    getAllUsers,
    deleteModelEntity,
    sendForApproval,
    getAllRoles,
    removeTeamMember,
    removeModelAssociation,
    getSingleEntityDetails,
    fetchDocumentsList,
    documentsList,
    attachDocument,
    deleteAttchedDocument,
    getHistory,
    getAllNotes,
    addNote,
    saveFilter,
    deleteFilter,
    editFilter,
    getAllAlerts,
    deleteAlert,
    updateAlerts,
    createAlerts,
    updateModelEntity,
    getSearchList,
  };
}
