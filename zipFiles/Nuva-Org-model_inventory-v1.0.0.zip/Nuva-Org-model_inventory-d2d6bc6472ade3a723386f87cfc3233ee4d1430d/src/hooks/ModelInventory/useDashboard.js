import axios from 'axios';
import API_ENDPOINTS from '../../const/ApiEndPoints';

export default function useDashboard() {
  const getNodesEdges = () => {
    return axios
      .get(`${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.DB.GET_NODES}`)
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getFilter = () => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.DB.GET_FILTER}`
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
  const getFilterList = (body) => {
    return axios
      .get(
        `${API_ENDPOINTS.MODULE_BASE_URL.AUTH}${API_ENDPOINTS.DB.GET_FILTERED_DATA}`,
        {
          params: body,
        }
      )
      .then((res) => {
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  return {
    getFilter,
    getFilterList,
    getNodesEdges,
  };
}
